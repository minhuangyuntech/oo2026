from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QLabel, QPushButton,
)


class CounterWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("PyQt6 Counter")
        self.resize(380, 240)
        self.count = 0
        self.label = QLabel("Count: 0")
        self.label.setStyleSheet("font-size: 26px;")
        self.button = QPushButton("Add 1")
        self.button.clicked.connect(self.increment)
        layout = QVBoxLayout(self)
        layout.addWidget(self.label)
        layout.addWidget(self.button)

    def increment(self):
        self.count += 1
        self.label.setText(f"Count: {self.count}")


if __name__ == "__main__":
    app = QApplication([])
    window = CounterWindow()
    window.show()
    app.exec()
