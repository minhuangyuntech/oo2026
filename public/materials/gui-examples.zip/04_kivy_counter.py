from kivy.app import App
from kivy.core.window import Window
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label


class CounterApp(App):
    def build(self):
        Window.size = (380, 240)
        self.title = "Kivy Counter"
        self.count = 0
        self.label = Label(text="Count: 0", font_size=30)
        self.button = Button(text="Add 1", font_size=24)
        self.button.bind(on_press=self.increment)
        layout = BoxLayout(orientation="vertical", padding=20, spacing=16)
        layout.add_widget(self.label)
        layout.add_widget(self.button)
        return layout

    def increment(self, button):
        self.count += 1
        self.label.text = f"Count: {self.count}"


if __name__ == "__main__":
    CounterApp().run()
