import tkinter as tk
from tkinter import ttk


class CounterApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Tkinter Counter")
        self.geometry("380x240")
        self.count = 0
        self.label = ttk.Label(self, text="Count: 0", font=("Segoe UI", 20))
        self.label.pack(pady=28)
        self.button = ttk.Button(self, text="Add 1", command=self.increment)
        self.button.pack(ipadx=20, ipady=10)

    def increment(self):
        self.count += 1
        self.label.config(text=f"Count: {self.count}")


if __name__ == "__main__":
    CounterApp().mainloop()
