import wx


class CounterFrame(wx.Frame):
    def __init__(self):
        super().__init__(None, title="wxPython Counter", size=(400, 280))
        self.count = 0
        panel = wx.Panel(self)
        self.label = wx.StaticText(panel, label="Count: 0")
        self.label.SetFont(wx.Font(wx.FontInfo(20)))
        self.button = wx.Button(panel, label="Add 1")
        self.button.Bind(wx.EVT_BUTTON, self.increment)
        layout = wx.BoxSizer(wx.VERTICAL)
        layout.Add(self.label, 0, wx.ALL | wx.ALIGN_CENTER, 28)
        layout.Add(self.button, 0, wx.ALL | wx.ALIGN_CENTER, 12)
        panel.SetSizer(layout)

    def increment(self, event):
        self.count += 1
        self.label.SetLabel(f"Count: {self.count}")


if __name__ == "__main__":
    app = wx.App(False)
    frame = CounterFrame()
    frame.Show()
    app.MainLoop()
