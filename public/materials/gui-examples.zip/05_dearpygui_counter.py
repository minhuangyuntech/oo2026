import dearpygui.dearpygui as dpg


class CounterApp:
    def __init__(self):
        self.count = 0

    def increment(self, sender=None, app_data=None, user_data=None):
        self.count += 1
        dpg.set_value("count_text", f"Count: {self.count}")

    def build(self):
        dpg.create_context()
        dpg.create_viewport(title="Dear PyGui Counter", width=400, height=280)
        with dpg.window(tag="main_window"):
            dpg.add_spacer(height=25)
            dpg.add_text("Count: 0", tag="count_text")
            dpg.add_spacer(height=18)
            self.button = dpg.add_button(
                label="Add 1", callback=self.increment, width=160, height=45,
            )
        dpg.setup_dearpygui()
        dpg.show_viewport()
        dpg.set_primary_window("main_window", True)

    def run(self):
        self.build()
        try:
            dpg.start_dearpygui()
        finally:
            dpg.destroy_context()


if __name__ == "__main__":
    CounterApp().run()
