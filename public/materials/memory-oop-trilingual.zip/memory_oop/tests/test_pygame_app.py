"""SDL event tests. Safe to run without opening a desktop window."""
import importlib.util
import os
import unittest

os.environ['SDL_VIDEODRIVER'] = 'dummy'
os.environ['SDL_AUDIODRIVER'] = 'dummy'
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = '1'
HAS_PYGAME = importlib.util.find_spec('pygame') is not None
if HAS_PYGAME:
    import pygame
    from pygame_app import PygameApp, WIDTH, HEIGHT


@unittest.skipUnless(HAS_PYGAME, 'Install requirements.txt for Pygame tests')
class DesktopTest(unittest.TestCase):
    def setUp(self):
        self.app = PygameApp(sample=True)

    def tearDown(self):
        pygame.quit()

    def key(self, key, repeat=False):
        self.app.handle_event(pygame.event.Event(pygame.KEYDOWN, key=key, repeat=repeat))

    def click(self, index, button=1):
        x,y = self.app.card_rects[index].center
        viewport = self.app.viewport()
        pos = (viewport.x+x*viewport.w/WIDTH, viewport.y+y*viewport.h/HEIGHT)
        self.app.handle_event(pygame.event.Event(pygame.MOUSEBUTTONDOWN, pos=pos, button=button))

    def test_mouse_and_step_comparison_before_settlement(self):
        g = self.app.game
        self.click(0)
        self.assertIs(g.pending, g.board.cards[0])
        self.assertFalse(g.pending.face_up)
        self.key(pygame.K_n)
        self.click(1)
        self.key(pygame.K_n)
        self.key(pygame.K_n)
        self.assertTrue(g.result)
        self.assertFalse(g.first.matched)
        self.assertEqual((g.turns,g.matches), (1,0))
        self.key(pygame.K_n)
        self.assertEqual((g.turns,g.matches), (1,1))

    def test_normal_play_completes_all_pairs(self):
        self.key(pygame.K_m)
        g = self.app.game
        for a,b in [(0,1),(2,4),(3,5),(6,8),(7,10),(9,11)]:
            self.click(a); self.click(b)
            self.assertEqual(g.phase,'compare')
            self.key(pygame.K_SPACE)
        self.assertEqual((g.phase,g.turns,g.matches),('won',6,6))
        self.key(pygame.K_SPACE)
        self.assertEqual(g.turns,6)

    def test_mismatch_keeps_the_same_cards(self):
        self.key(pygame.K_F2)
        g = self.app.game
        cards = g.board.cards[:]
        self.click(2); self.key(pygame.K_n)
        self.click(3); self.key(pygame.K_n)
        self.key(pygame.K_n)
        self.assertFalse(g.result)
        self.key(pygame.K_n)
        self.assertFalse(cards[2].face_up)
        self.assertEqual(g.matches,0)
        self.assertTrue(all(a is b for a,b in zip(cards,g.board.cards)))

    def test_inspection_does_not_reveal(self):
        self.click(8,button=3)
        self.assertEqual(self.app.selected,8)
        self.key(pygame.K_RIGHT)
        self.assertEqual(self.app.selected,9)
        self.assertTrue(all(not c.face_up for c in self.app.game.board.cards))
        self.assertIsNone(self.app.game.pending)
        self.key(pygame.K_RETURN)
        self.assertIs(self.app.game.pending,self.app.game.board.cards[9])

    def test_language_labels_and_mode_preserve_references(self):
        g = self.app.game
        self.click(0)
        card = g.pending
        self.key(pygame.K_l)
        self.assertFalse(self.app.labels)
        for key,lang in [(pygame.K_2,'en'),(pygame.K_3,'ja'),(pygame.K_1,'zh')]:
            self.key(key)
            self.assertEqual(self.app.lang,lang)
            self.assertIs(self.app.game,g)
            self.assertIs(g.pending,card)
        self.key(pygame.K_m)
        self.key(pygame.K_SPACE)
        self.assertIs(g.first,card)
        self.assertTrue(card.face_up)

    def test_resize_and_letterbox_hit_testing(self):
        for size in [(900,900),(1280,400)]:
            self.app.window=pygame.display.set_mode(size,pygame.RESIZABLE)
            self.app.reset('match')
            self.app.click((0,0))
            self.assertIsNone(self.app.game.pending)
            self.click(1)
            self.assertIs(self.app.game.pending,self.app.game.board.cards[1])

    def test_drawing_and_repeated_keys_do_not_advance(self):
        self.click(0)
        for _ in range(3):
            self.app.draw(); self.app.present()
        self.key(pygame.K_n,repeat=True)
        self.assertEqual(self.app.game.phase,'first')
        self.assertFalse(self.app.game.pending.face_up)

    def test_reset_constructs_new_objects(self):
        self.click(0); self.key(pygame.K_n)
        old=self.app.game.first
        self.key(pygame.K_r)
        self.assertIsNot(old,self.app.game.board.cards[0])
        self.assertTrue(old.face_up)
        self.assertFalse(self.app.game.board.cards[0].face_up)

    def test_three_languages_fit_canvas(self):
        original=self.app.text
        def checked(value,pos,size=20,color='#17373C'):
            rect=original(value,pos,size,color)
            self.assertLessEqual(rect.right,WIDTH,(self.app.lang,value,rect))
            self.assertLessEqual(rect.bottom,HEIGHT,(self.app.lang,value,rect))
            return rect
        self.app.text=checked
        for lang in ('zh','en','ja'):
            self.app.set_language(lang)
            self.app.draw()
        self.assertTrue(all(self.app.fonts[18].metrics(c)[0] is not None for c in '翻牌配對実験室日本語'))

    def test_quit_event_exits_the_loop(self):
        pygame.event.post(pygame.event.Event(pygame.QUIT))
        self.app.run()
        self.assertFalse(self.app.running)
        self.assertFalse(pygame.display.get_init())


if __name__=='__main__':
    unittest.main()
