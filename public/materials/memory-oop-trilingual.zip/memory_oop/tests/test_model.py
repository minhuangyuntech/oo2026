import unittest
from collections import Counter
from model import Board, Card, Game

class ModelTest(unittest.TestCase):
    def test_board(self):
        b = Board()
        self.assertEqual(len(set(map(id, b.cards))), 12)
        self.assertEqual(sorted(Counter(c.pair_id for c in b.cards).values()), [2]*6)

    def test_queue_reference(self):
        g = Game(sample=True)
        self.assertFalse(g.step())
        self.assertFalse(g.queue('invalid'))
        self.assertTrue(g.queue('C01'))
        self.assertIs(g.pending, g.board.cards[0])
        self.assertFalse(g.pending.face_up)
        self.assertFalse(g.queue('C02'))
        g.step()
        self.assertIs(g.first, g.board.cards[0])
        self.assertFalse(g.queue('C01'))

    def test_match_steps(self):
        g = Game(sample=True)
        g.play('C01'); g.play('C02')
        self.assertIsNot(g.first, g.second)
        self.assertEqual(g.first.pair_id, g.second.pair_id)
        self.assertEqual(g.phase, 'compare')
        g.step()
        self.assertTrue(g.result)
        self.assertFalse(g.first.matched)
        self.assertEqual(g.matches, 0)
        g.step()
        self.assertEqual((g.turns, g.matches), (1, 1))
        self.assertIsNone(g.first)
        self.assertTrue(g.board.cards[0].matched)

    def test_mismatch_identity(self):
        g = Game(sample=True)
        old = g.board.get('C03')
        g.play('C03'); g.play('C04'); g.step()
        self.assertFalse(g.result)
        self.assertTrue(old.face_up)
        g.step()
        self.assertFalse(old.face_up)
        self.assertIs(g.board.get('C03'), old)
        self.assertIsNone(g.second)

    def test_guards_and_completion(self):
        g = Game(sample=True)
        g.compare(); g.settle()
        for a,b in [('C01','C02'),('C03','C05'),('C04','C06'),('C07','C09'),('C08','C11'),('C10','C12')]:
            g.play(a); g.play(b)
            self.assertFalse(g.queue('C12'))
            g.finish_turn()
        self.assertEqual((g.phase, g.turns, g.matches), ('won', 6, 6))
        self.assertFalse(g.step())
        g.finish_turn()
        self.assertEqual(g.turns, 6)
        c = g.board.cards[0]
        c.hide()
        self.assertTrue(c.face_up)
        self.assertFalse(c.reveal())

    def test_new_game(self):
        old = Game(sample=True)
        old.play('C01')
        ref = old.first
        new = Game(sample=True)
        self.assertIsNot(ref, new.board.cards[0])
        self.assertTrue(ref.face_up)
        self.assertFalse(new.board.cards[0].face_up)

if __name__ == '__main__':
    unittest.main()
