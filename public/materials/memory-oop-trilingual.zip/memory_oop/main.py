"""Always-manual observation console: python main.py --lang zh --sample."""
import argparse
from model import Game

TEXT = {
 'zh': ('翻牌物件實驗室', '觀察指令：pick C01、step、confirm、inspect C01、new、sample、quit', '無法執行此操作。請先選取可翻的牌，或完成目前回合。', '比較次數', '已配對', '請輸入有效指令'),
 'en': ('Card Object Lab', 'Observation commands: pick C01, step, confirm, inspect C01, new, sample, quit', 'Action unavailable. Choose a covered card or finish this turn.', 'Comparisons', 'Pairs matched', 'Enter a valid command'),
 'ja': ('カード・オブジェクト実験室', '観察コマンド：pick C01、step、confirm、inspect C01、new、sample、quit', '操作できません。裏向きのカードを選ぶか、手番を完了してください。', '比較回数', '一致したペア', '有効なコマンドを入力してください')
}

def show(game, lang):
    t = TEXT[lang]
    for start in range(0, 12, 4):
        print('  '.join(f'{c.name}: {c.pair_id if c.face_up else "?":6}{" *" if c.matched else "  "}'
                        for c in game.board.cards[start:start+4]))
    print(f'{t[3]}: {game.turns} | {t[4]}: {game.matches}/6')
    print('phase =', game.phase, '| result =', game.result)
    print(' | '.join(f'{key} = {getattr(game,key).name if getattr(game,key) else None}'
                     for key in ('first', 'second', 'pending')))

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--lang', choices=TEXT, default='zh')
    parser.add_argument('--sample', action='store_true')
    args = parser.parse_args()
    t = TEXT[args.lang]
    game = Game(sample=args.sample)
    print(t[0], '\n', t[1])
    while True:
        show(game, args.lang)
        try:
            parts = input('> ').strip().split()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not parts:
            continue
        cmd = parts[0].lower()
        if cmd == 'quit': break
        if cmd == 'new': game = Game()
        elif cmd == 'sample': game = Game(sample=True)
        elif cmd == 'pick' and len(parts) == 2:
            if not game.queue(parts[1].upper()): print(t[2])
        elif cmd == 'step':
            if not game.step(): print(t[2])
        elif cmd == 'confirm': game.finish_turn()
        elif cmd == 'inspect' and len(parts) == 2:
            card = game.board.get(parts[1].upper())
            print(vars(card) if card else t[2])
        else: print(t[5], '\n', t[1])

if __name__ == '__main__':
    main()
