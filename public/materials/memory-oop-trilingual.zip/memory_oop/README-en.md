# Card matching and object state

The example has three classes. Card holds one card's state. Board holds 12 cards. Game coordinates selection, comparison, and settlement.

## Play in a browser

[Online game](https://minhuangyuntech.github.io/oo2026/en/memory/play/) · [Online lesson](https://minhuangyuntech.github.io/oo2026/en/memory/)

Normal play: choose two cards, then confirm the turn. Step mode: select a card to store a pending reference, then use Next step or N to reveal, compare, and settle separately. L toggles object labels. Tab moves focus; Enter or Space activates buttons. Touch controls also work.

The match example uses C01 and C02; the mismatch uses C03 and C04. Loading an example creates a new game. Switching languages preserves the current state. Reloading the page restarts the game. The inspector selector only changes which card you inspect. Step mode exposes pair_id even for covered cards.

## Run the Pygame desktop version

Use Python 3.12. Extract the ZIP and open a terminal in `memory_oop`:

```sh
python -m pip install -r requirements.txt
python pygame_app.py --lang en
python pygame_app.py --lang en --sample
python -m unittest discover -s tests -v
```

Installing Pygame 2.6.1 initially requires internet. Play offline after setup. `--sample` opens a fixed board in step mode. On systems that use `python3`, replace `python` in each command.

Left-click or Enter selects a card. Right-click or arrow keys only change the inspected card. Use N or Next step to advance one stage in step mode. In normal play, select two cards, then press Space or Confirm turn. M toggles mode; L toggles labels; R starts a new game; F1 / F2 load match / mismatch examples; 1 / 2 / 3 select Chinese / English / Japanese; Esc exits. Changing languages preserves the board.

`PygameApp` holds a `Game` and handles the window, input, and drawing; `model.py` owns the rules. Step mode reveals the first card, reveals the second, compares, then settles. After a True comparison, matched is still False until the next settlement step. The displayed `is` expression compares real Python object references.

The bundled font supports Chinese and Japanese without installing a system font. See `assets/ATTRIBUTION.txt` and `assets/OFL.txt`. The window is resizable; pointer coordinates map back to the logical canvas.

## Run the console version

The original model and console program need no extra packages:

```sh
python main.py --lang en --sample
```

Enter `pick C01`, `step`, `pick C02`, `step`, `step`, and `step` to complete a match. `inspect C01` prints the object's attributes. `confirm` compares and settles together. `sample` creates a fixed board, `new` creates a shuffled game, and `quit` exits.

## Source files

- `model.py`: complete Python model. first, second, and pending refer to existing Cards in Board.
- `pygame_app.py`: PygameApp window, input, and rendering.
- `pygame_text.py`: trilingual UI text.
- `tests/test_pygame_app.py`: desktop input and rendering tests.
- `main.py`: console interface in Chinese, English, and Japanese.
- `tests/test_model.py`: tests for matching, stepping, references, and reset.
- `browser/engine.ts`: the actual TypeScript model used by the course website.
- `docs/lesson-en.html`: 27 topics, diagrams, and code for offline reading.

Comparison checks whether pair_id values are equal. Cards with equal pictures remain separate objects. A mismatch hides the existing cards. Board still holds those objects. A new game creates a new Board and new Cards.
