# Card matching and object state

The example has three classes. Card holds one card's state. Board holds 12 cards. Game coordinates selection, comparison, and settlement.

## Play in a browser

[Online game](https://minhuangyuntech.github.io/oo2026/en/memory/play/) · [Online lesson](https://minhuangyuntech.github.io/oo2026/en/memory/)

Normal play: choose two cards, then confirm the turn. Step mode: select a card to store a pending reference, then use Next step or N to reveal, compare, and settle separately. L toggles object labels. Tab moves focus; Enter or Space activates buttons. Touch controls also work.

The match example uses C01 and C02; the mismatch uses C03 and C04. Loading an example creates a new game. Switching languages preserves the current state. Reloading the page restarts the game. The inspector selector only changes which card you inspect. Step mode exposes pair_id even for covered cards.

## Run Python

Install Python 3.12 or later. No additional packages are required. Extract the ZIP and open a terminal in memory_oop:

```sh
python main.py --lang en --sample
python -m unittest discover -s tests -v
```

The Python example is a console observation program. The browser implements the same rules in TypeScript and needs no Python installation.

Enter `pick C01`, `step`, `pick C02`, `step`, `step`, and `step` to complete a match. `inspect C01` prints the object's attributes. `confirm` compares and settles together. `sample` creates a fixed board, `new` creates a shuffled game, and `quit` exits.

## Source files

- `model.py`: complete Python model. first, second, and pending refer to existing Cards in Board.
- `main.py`: console interface in Chinese, English, and Japanese.
- `tests/test_model.py`: tests for matching, stepping, references, and reset.
- `browser/engine.ts`: the actual TypeScript model used by the course website.
- `docs/lesson-en.html`: 18 topics, diagrams, and code for offline reading.

Comparison checks whether pair_id values are equal. Cards with equal pictures remain separate objects. A mismatch hides the existing cards. Board still holds those objects. A new game creates a new Board and new Cards.
