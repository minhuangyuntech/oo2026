# 翻牌配對與物件狀態

這個範例使用 Card、Board、Game 三個類別。Card 保存一張牌的狀態，Board 保存 12 張牌，Game 管理選牌、比較與結算。

## 直接在瀏覽器遊玩

[線上遊戲](https://minhuangyuntech.github.io/oo2026/memory/play/) · [線上教材](https://minhuangyuntech.github.io/oo2026/memory/)

一般遊玩：選兩張牌，再按「確認這一回合」。單步觀察：選牌加入 pending，再按「下一步」或 N，逐一執行翻牌、比較、結算。L 切換物件標籤。Tab 切換焦點，Enter 或空白鍵啟動按鈕。手機可直接點選。

固定成功範例使用 C01、C02；失敗範例使用 C03、C04。載入範例會建立新一局。切換語言保留目前狀態，重新整理網頁會重新開始。觀察選單只更換檢視對象，單步模式可讀取蓋牌的 pair_id。

## 執行 Pygame 視窗版

使用 Python 3.12。在解壓縮後的 `memory_oop` 資料夾開啟終端機：

```sh
python -m pip install -r requirements.txt
python pygame_app.py --lang zh
python pygame_app.py --lang zh --sample
python -m unittest discover -s tests -v
```

首次安裝 Pygame 2.6.1 需要網路，之後可離線遊玩。`--sample` 開啟固定棋盤與單步觀察。部分系統使用 `python3` 指令，請將上述的 `python` 一併替換。

左鍵或 Enter 選牌；右鍵或方向鍵只切換檢視對象。單步模式按 N 或「下一步」前進一個階段。一般模式選兩張後按 Space 或「確認回合」。M 切換模式、L 切換物件標籤、R 建立新遊戲、F1 / F2 載入成功／失敗範例、1 / 2 / 3 切換中／英／日、Esc 離開。語言切換保留目前棋盤。

`PygameApp` 持有 `Game`，負責視窗、輸入與繪圖；`model.py` 負責規則。觀察模式依序執行「翻第一張 → 翻第二張 → 比較 → 結算」。比較結果為 True 時，matched 仍為 False；下一步結算後才變成 True。畫面中的 `is` 比較實際的 Python 物件參照。

隨附中日文字型，不需另行安裝字型；來源與授權見 `assets/ATTRIBUTION.txt`、`assets/OFL.txt`。視窗可縮放，點選座標會轉換回邏輯畫布。

## 執行終端機版

原有的模型與終端機程式不需要額外套件：

```sh
python main.py --lang zh --sample
```

依序輸入 `pick C01`、`step`、`pick C02`、`step`、`step`、`step`，即可完成一次成功配對。`inspect C01` 顯示物件屬性。`confirm` 一次完成比較與結算，`sample` 建立固定棋盤，`new` 建立洗牌後的新遊戲，`quit` 結束。

## 閱讀程式

- `model.py`：完整 Python 模型。`first`、`second`、`pending` 參照 Board 中既有的 Card。
- `pygame_app.py`：PygameApp 視窗、輸入與畫面。
- `pygame_text.py`：三語介面文字。
- `tests/test_pygame_app.py`：桌面操作與繪圖測試。
- `main.py`：中英日終端機介面。
- `tests/test_model.py`：配對、單步、參照與重設的測試。
- `browser/engine.ts`：課程網頁使用的 TypeScript 模型，供對照閱讀。
- `docs/lesson-zh.html`：27 個主題、類別圖、物件圖與程式碼，可離線閱讀。

比較時檢查 pair_id 是否相等。兩張相同圖案的牌仍是不同物件。結算失敗只將牌蓋回，Board 仍保存原本的物件。建立新遊戲會建立新的 Board 與 Card。
