# 翻牌配對與物件狀態

這個範例使用 Card、Board、Game 三個類別。Card 保存一張牌的狀態，Board 保存 12 張牌，Game 管理選牌、比較與結算。

## 直接在瀏覽器遊玩

[線上遊戲](https://minhuangyuntech.github.io/oo2026/memory/play/) · [線上教材](https://minhuangyuntech.github.io/oo2026/memory/)

一般遊玩：選兩張牌，再按「確認這一回合」。單步觀察：選牌加入 pending，再按「下一步」或 N，逐一執行翻牌、比較、結算。L 切換物件標籤。Tab 切換焦點，Enter 或空白鍵啟動按鈕。手機可直接點選。

固定成功範例使用 C01、C02；失敗範例使用 C03、C04。載入範例會建立新一局。切換語言保留目前狀態，重新整理網頁會重新開始。觀察選單只更換檢視對象，單步模式可讀取蓋牌的 pair_id。

## 執行 Python

安裝 Python 3.12 或更新版本，不需要額外套件。解壓縮後，在 memory_oop 資料夾開啟終端機：

```sh
python main.py --lang zh --sample
python -m unittest discover -s tests -v
```

Python 版是終端機觀察程式。網頁版以 TypeScript 實作相同規則，瀏覽器不需要安裝 Python。

依序輸入 `pick C01`、`step`、`pick C02`、`step`、`step`、`step`，即可完成一次成功配對。`inspect C01` 顯示物件屬性。`confirm` 一次完成比較與結算，`sample` 建立固定棋盤，`new` 建立洗牌後的新遊戲，`quit` 結束。

## 閱讀程式

- `model.py`：完整 Python 模型。`first`、`second`、`pending` 參照 Board 中既有的 Card。
- `main.py`：中英日終端機介面。
- `tests/test_model.py`：配對、單步、參照與重設的測試。
- `browser/engine.ts`：課程網頁使用的 TypeScript 模型，供對照閱讀。
- `docs/lesson-zh.html`：18 個主題、類別圖、物件圖與程式碼，可離線閱讀。

比較時檢查 pair_id 是否相等。兩張相同圖案的牌仍是不同物件。結算失敗只將牌蓋回，Board 仍保存原本的物件。建立新遊戲會建立新的 Board 與 Card。
