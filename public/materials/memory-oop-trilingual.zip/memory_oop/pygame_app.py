"""A Pygame view/controller for the unchanged Card, Board, and Game model.

Run: python pygame_app.py --lang zh
The screen is a logical 1280 x 800 surface. Resizing only scales the view.
"""
import argparse
import math
from pathlib import Path

import pygame

from model import Game
from pygame_text import TEXT

WIDTH, HEIGHT = 1280, 800
BG, INK, MUTED = '#F4F5F0', '#17373C', '#637777'
GREEN, PURPLE, LINE = '#16695F', '#8260AE', '#D5DDD6'
WHITE, BACK, FACE = '#FFFFFF', '#183E43', '#FAF7EF'


class PygameApp:
    def __init__(self, lang='zh', sample=False):
        pygame.display.init()
        pygame.font.init()
        info = pygame.display.Info()
        scale = min(1, (info.current_w - 60) / WIDTH,
                    (info.current_h - 100) / HEIGHT)
        size = (max(640, int(WIDTH * scale)), max(400, int(HEIGHT * scale)))
        self.window = pygame.display.set_mode(size, pygame.RESIZABLE)
        self.screen = pygame.Surface((WIDTH, HEIGHT))
        self.clock = pygame.time.Clock()
        self.game = Game(sample=sample)
        self.lang = lang
        self.observe = sample
        self.labels = True
        self.selected = 0
        self.sample = sample
        self.running = True
        font = str(Path(__file__).parent / 'assets/NotoSansCJKtc-Regular.otf')
        self.fonts = {size: pygame.font.Font(font, size)
                      for size in (16, 18, 20, 22, 28, 34)}
        self.card_rects = [pygame.Rect(34 + (i % 4) * 194,
                                      280 + (i // 4) * 133, 180, 119)
                           for i in range(12)]
        self.buttons = {
            'zh': pygame.Rect(947, 29, 90, 38),
            'en': pygame.Rect(1043, 29, 90, 38),
            'ja': pygame.Rect(1139, 29, 107, 38),
            'normal': pygame.Rect(34, 133, 160, 40),
            'observe': pygame.Rect(204, 133, 160, 40),
            'labels': pygame.Rect(374, 133, 200, 40),
            'new': pygame.Rect(584, 133, 198, 40),
            'advance': pygame.Rect(34, 223, 410, 42),
            'match': pygame.Rect(34, 695, 365, 40),
            'miss': pygame.Rect(413, 695, 365, 40),
        }
        self.set_language(lang)

    @property
    def t(self):
        return TEXT[self.lang]

    def set_language(self, lang):
        self.lang = lang
        pygame.display.set_caption(self.t['title'] + ' | Pygame OOP')

    def reset(self, example=None):
        self.game = Game(sample=example is not None)
        self.sample = example is not None
        self.selected = 2 if example == 'miss' else 0
        if example:
            self.observe = True

    def pick(self, index):
        self.selected = index
        card = self.game.board.cards[index]
        if self.observe:
            self.game.queue(card.name)
        else:
            self.game.play(card.name)

    def advance(self):
        if self.observe or self.game.pending:
            self.game.step()
        else:
            self.game.finish_turn()

    def viewport(self):
        w, h = self.window.get_size()
        scale = min(w / WIDTH, h / HEIGHT)
        size = (max(1, int(WIDTH * scale)), max(1, int(HEIGHT * scale)))
        return pygame.Rect((w - size[0]) // 2, (h - size[1]) // 2, *size)

    def logical_point(self, pos):
        rect = self.viewport()
        if not rect.collidepoint(pos):
            return None
        return ((pos[0] - rect.x) * WIDTH / rect.w,
                (pos[1] - rect.y) * HEIGHT / rect.h)

    def click_card(self, pos, inspect_only=False):
        for index, rect in enumerate(self.card_rects):
            if rect.collidepoint(pos):
                if inspect_only:
                    self.selected = index
                else:
                    self.pick(index)
                return True
        return False

    def click(self, pos, button=1):
        point = self.logical_point(pos)
        if point is None:
            return
        if button == 3:
            self.click_card(point, inspect_only=True)
            return
        if button != 1:
            return
        for name, rect in self.buttons.items():
            if rect.collidepoint(point):
                if name in TEXT:
                    self.set_language(name)
                elif name in ('normal', 'observe'):
                    self.observe = name == 'observe'
                elif name == 'labels':
                    self.labels = not self.labels
                elif name == 'new':
                    self.reset()
                elif name in ('match', 'miss'):
                    self.reset(name)
                elif name == 'advance':
                    self.advance()
                return
        self.click_card(point)

    def handle_event(self, event):
        if event.type == pygame.QUIT:
            self.running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            self.click(event.pos, event.button)
        elif event.type == pygame.KEYDOWN:
            if getattr(event, 'repeat', False):
                return
            self.handle_key(event.key)

    def handle_key(self, key):
        if key == pygame.K_ESCAPE:
            self.running = False
        elif key in (pygame.K_1, pygame.K_2, pygame.K_3):
            self.set_language({pygame.K_1: 'zh', pygame.K_2: 'en', pygame.K_3: 'ja'}[key])
        elif key == pygame.K_m:
            self.observe = not self.observe
        elif key == pygame.K_l:
            self.labels = not self.labels
        elif key == pygame.K_r:
            self.reset()
        elif key in (pygame.K_F1, pygame.K_F2):
            self.reset('match' if key == pygame.K_F1 else 'miss')
        elif key == pygame.K_n and self.observe:
            self.advance()
        elif key == pygame.K_SPACE:
            self.advance()
        elif key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            self.pick(self.selected)
        elif key in (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_UP, pygame.K_DOWN):
            delta = {pygame.K_LEFT: -1, pygame.K_RIGHT: 1,
                     pygame.K_UP: -4, pygame.K_DOWN: 4}[key]
            self.selected = (self.selected + delta) % 12

    def text(self, value, pos, size=20, color=INK):
        image = self.fonts[size].render(str(value), True, color)
        self.screen.blit(image, pos)
        return image.get_rect(topleft=pos)

    def button(self, name, label, active=False, enabled=True):
        rect = self.buttons[name]
        color = GREEN if active else WHITE
        pygame.draw.rect(self.screen, color if enabled else LINE, rect, border_radius=8)
        pygame.draw.rect(self.screen, GREEN if active else LINE, rect, 1, border_radius=8)
        image = self.fonts[18].render(label, True, WHITE if active else INK)
        self.screen.blit(image, image.get_rect(center=rect.center))

    def draw_symbol(self, pair_id, center):
        x, y = center
        color = {'moon': PURPLE, 'leaf': GREEN, 'sun': '#B58128',
                 'star': '#9B6632', 'gem': '#407A98', 'flower': '#A05583'}[pair_id]
        if pair_id == 'moon':
            pygame.draw.circle(self.screen, color, (x, y), 21)
            pygame.draw.circle(self.screen, FACE, (x + 11, y - 6), 19)
        elif pair_id == 'leaf':
            pygame.draw.ellipse(self.screen, color, (x - 15, y - 23, 30, 44), 3)
            pygame.draw.line(self.screen, color, (x - 10, y + 25), (x + 8, y - 14), 3)
        elif pair_id == 'sun':
            pygame.draw.circle(self.screen, color, (x, y), 14)
            for i in range(8):
                angle = i * math.pi / 4
                points = [(x + int(r * math.cos(angle)), y + int(r * math.sin(angle))) for r in (20, 27)]
                pygame.draw.line(self.screen, color, *points, 3)
        elif pair_id == 'star':
            points = [(x + int((25 if i % 2 == 0 else 11) * math.cos(i * math.pi / 5 - math.pi / 2)),
                       y + int((25 if i % 2 == 0 else 11) * math.sin(i * math.pi / 5 - math.pi / 2))) for i in range(10)]
            pygame.draw.polygon(self.screen, color, points)
        elif pair_id == 'gem':
            pygame.draw.polygon(self.screen, color, [(x, y - 25), (x + 23, y), (x, y + 25), (x - 23, y)])
        else:
            for i in range(6):
                angle = i * math.pi / 3
                pygame.draw.circle(self.screen, color, (x + int(17 * math.cos(angle)), y + int(17 * math.sin(angle))), 10)
            pygame.draw.circle(self.screen, FACE, (x, y), 8)

    def draw_card(self, card, rect, selected=False):
        color = FACE if card.face_up else BACK
        pygame.draw.rect(self.screen, color, rect, border_radius=10)
        if selected:
            pygame.draw.rect(self.screen, PURPLE, rect.inflate(6, 6), 3, border_radius=12)
        if card.face_up:
            self.draw_symbol(card.pair_id, (rect.centerx, rect.y + 37))
            label = self.t['pairs'][card.pair_id]
        else:
            self.text('?', (rect.centerx - 9, rect.y + 8), 34, '#A5C8B3')
            label = 'CARD'
        image = self.fonts[16].render(label, True, INK if card.face_up else WHITE)
        self.screen.blit(image, image.get_rect(midtop=(rect.centerx, rect.y + 63)))
        if self.labels:
            self.text(f'{card.name}: Card', (rect.x + 16, rect.y + 91), 16,
                      INK if card.face_up else WHITE)
        if card.matched:
            self.text('OK', (rect.right - 32, rect.y + 4), 16, GREEN)
        if self.game.pending is card:
            pygame.draw.circle(self.screen, '#E5B951', (rect.right - 15, rect.y + 15), 6)

    def draw_inspector(self):
        card = self.game.board.cards[self.selected]
        x = 840
        pygame.draw.rect(self.screen, '#E8EEE6', (818, 133, 428, 602), border_radius=12)
        self.text(self.t['inspector'], (x, 149), 22)
        self.text(self.t['inspect_note'], (x, 186), 16, MUTED)
        self.text(f'{card.name}: Card', (x, 226), 28)
        pair = card.pair_id if self.observe or card.face_up else self.t['secret']
        for y, key, value in [(276, 'pair_id', pair), (313, 'face_up', card.face_up), (350, 'matched', card.matched)]:
            self.text(key, (x, y), 18)
            self.text(value, (1035, y), 18, GREEN)
        self.text(self.t['refs'], (x, 404), 20)
        for i, key in enumerate(('first', 'second', 'pending')):
            ref = getattr(self.game, key)
            self.text(f'game.{key}', (x, 445 + 34 * i), 18)
            self.text(ref.name if ref else 'None', (1145, 445 + 34 * i), 18, GREEN)
        self.draw_identity(card)
        self.text(f'phase = {self.game.phase!r}', (x, 644), 18)
        self.text(f'result = {self.game.result}', (x, 677), 18)

    def draw_identity(self, card):
        for key in ('first', 'second', 'pending'):
            if getattr(self.game, key) is card:
                self.text(f'game.{key} is', (840, 560), 18, GREEN)
                self.text(f'game.board.cards[{self.selected}]', (840, 586), 18, GREEN)
                self.text('True · ' + self.t['same'], (840, 612), 16, GREEN)
                return
        self.text(self.t['no_ref'], (840, 572), 16, MUTED)

    def action_label(self):
        if self.game.pending:
            return self.t['reveal'].format(name=self.game.pending.name)
        return {'compare': self.t['compare'], 'resolve': self.t['keep'] if self.game.result else self.t['hide'],
                'won': self.t['won']}.get(self.game.phase, self.t['wait'])

    def draw(self):
        self.screen.fill(BG)
        self.text(self.t['title'], (34, 20), 34)
        self.text(self.t['subtitle'], (36, 76), 18, MUTED)
        for lang, label in [('zh', '中文'), ('en', 'English'), ('ja', '日本語')]:
            self.button(lang, label, active=self.lang == lang)
        self.text(self.t['score'].format(matches=self.game.matches, turns=self.game.turns), (848, 80), 20, GREEN)
        self.button('normal', self.t['normal'], active=not self.observe)
        self.button('observe', self.t['observe'], active=self.observe)
        self.button('labels', ('ON · ' if self.labels else 'OFF · ') + self.t['labels'])
        self.button('new', self.t['new'] + ' · R')
        self.text(self.t['step_note'] if self.observe else self.t['play_note'], (34, 187), 18)
        label = self.t['step'] + ': ' + self.action_label() if self.observe else self.t['confirm']
        if self.game.pending and not self.observe:
            label = self.action_label()
        self.button('advance', label, active=self.game.can_step, enabled=self.game.can_step)
        self.text(self.t['phases'][self.game.phase], (474, 230), 20, GREEN)
        for i, card in enumerate(self.game.board.cards):
            self.draw_card(card, self.card_rects[i], selected=i == self.selected)
        self.text(self.t['won'] if self.game.phase == 'won' else self.t['fixed' if self.sample else 'random'], (34, 665), 18, GREEN)
        self.button('match', self.t['match'] + ' · F1')
        self.button('miss', self.t['miss'] + ' · F2')
        self.draw_inspector()
        self.text(self.t['keys'], (34, 744), 16, MUTED)
        self.text(self.t['examples'], (34, 773), 16, MUTED)

    def present(self):
        rect = self.viewport()
        self.window.fill('#182F34')
        image = pygame.transform.smoothscale(self.screen, rect.size)
        self.window.blit(image, rect)

    def run(self):
        while self.running:
            for event in pygame.event.get():
                self.handle_event(event)
            self.draw()
            self.present()
            pygame.display.flip()
            self.clock.tick(60)
        pygame.quit()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lang', choices=TEXT, default='zh')
    parser.add_argument('--sample', action='store_true')
    args = parser.parse_args()
    PygameApp(args.lang, args.sample).run()


if __name__ == '__main__':
    main()
