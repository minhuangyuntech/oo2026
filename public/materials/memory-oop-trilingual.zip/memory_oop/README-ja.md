# 神経衰弱とオブジェクトの状態

三つのクラスを使います。Card は一枚の状態を持ち、Board は 12 枚を保持し、Game は選択・比較・確定を管理します。

## ブラウザーで遊ぶ

[オンラインゲーム](https://minhuangyuntech.github.io/oo2026/ja/memory/play/) · [オンライン教材](https://minhuangyuntech.github.io/oo2026/ja/memory/)

通常プレイでは二枚選んで手番を確定します。コマ送りでは、カードを選んで pending に参照を保存し、「次のステップ」または N でめくる・比較・確定を一段階ずつ進めます。L はオブジェクト名の表示切替です。Tab で移動し、Enter または Space でボタンを操作できます。タッチ操作にも対応しています。

一致の例は C01 と C02、不一致の例は C03 と C04 です。例の読み込みは新しいゲームを作ります。言語を切り替えても状態は保たれますが、ページを再読み込みすると最初からになります。観察用の選択欄は観察対象だけを変更します。コマ送りでは裏向きのカードの pair_id も表示します。

## Pygame デスクトップ版の実行

Python 3.12 を使います。ZIP を展開し、`memory_oop` フォルダーでターミナルを開きます。

```sh
python -m pip install -r requirements.txt
python pygame_app.py --lang ja
python pygame_app.py --lang ja --sample
python -m unittest discover -s tests -v
```

Pygame 2.6.1 の初回インストールはネット接続が必要です。導入後はオフラインで遊べます。`--sample` は固定盤面をコマ送りで開きます。`python3` を使う環境では、各コマンドの `python` を置き換えてください。

左クリックまたは Enter で選択。右クリックと方向キーは観察対象だけを変更します。コマ送りでは N または「次のステップ」で一段階進みます。通常プレイは二枚選んで Space または「手番を確定」。M はモード、L は名前表示、R は新しいゲーム、F1 / F2 は一致／不一致の例、1 / 2 / 3 は中／英／日の切替、Esc は終了です。言語を変えても盤面は保持されます。

`PygameApp` が `Game` を持ち、ウィンドウ・入力・描画を担当します。ルールは `model.py` が担当します。コマ送りは「一枚目をめくる → 二枚目をめくる → 比較 → 確定」です。比較結果が True でも matched は False のままで、次の確定で True になります。画面の `is` は実際の Python オブジェクトの参照を比較します。

中日文字に対応するフォントを同梱し、システムへの追加導入は不要です。出典とライセンスは `assets/ATTRIBUTION.txt` と `assets/OFL.txt` にあります。サイズ変更後のクリック座標は論理画面に変換されます。

## ターミナル版の実行

元のモデルとターミナル版には追加パッケージが不要です。

```sh
python main.py --lang ja --sample
```

`pick C01`、`step`、`pick C02`、`step`、`step`、`step` の順に入力すると一組が一致します。`inspect C01` は属性を表示します。`confirm` は比較と確定をまとめて実行します。`sample` は固定の盤面、`new` はシャッフルしたゲームを作り、`quit` で終了します。

## ファイル構成

- `model.py`：Python モデル全体。first、second、pending は Board 内の既存の Card を参照します。
- `pygame_app.py`：PygameApp のウィンドウ、入力、描画。
- `pygame_text.py`：三言語の画面テキスト。
- `tests/test_pygame_app.py`：操作と描画のテスト。
- `main.py`：中英日のターミナル表示。
- `tests/test_model.py`：一致、コマ送り、参照、リセットのテスト。
- `browser/engine.ts`：授業サイトで使う TypeScript モデル。
- `docs/lesson-ja.html`：27 のトピック、クラス図、オブジェクト図、コード。オフラインで読めます。

比較では pair_id の値の一致を調べます。同じ絵のカードも別々のオブジェクトです。不一致なら既存のカードを裏返し、Board は同じ実体を保持します。新しいゲームは新しい Board と Card を生成します。
