# 神経衰弱とオブジェクトの状態

三つのクラスを使います。Card は一枚の状態を持ち、Board は 12 枚を保持し、Game は選択・比較・確定を管理します。

## ブラウザーで遊ぶ

[オンラインゲーム](https://minhuangyuntech.github.io/oo2026/ja/memory/play/) · [オンライン教材](https://minhuangyuntech.github.io/oo2026/ja/memory/)

通常プレイでは二枚選んで手番を確定します。コマ送りでは、カードを選んで pending に参照を保存し、「次のステップ」または N でめくる・比較・確定を一段階ずつ進めます。L はオブジェクト名の表示切替です。Tab で移動し、Enter または Space でボタンを操作できます。タッチ操作にも対応しています。

一致の例は C01 と C02、不一致の例は C03 と C04 です。例の読み込みは新しいゲームを作ります。言語を切り替えても状態は保たれますが、ページを再読み込みすると最初からになります。観察用の選択欄は観察対象だけを変更します。コマ送りでは裏向きのカードの pair_id も表示します。

## Python の実行

Python 3.12 以降を使います。追加パッケージは不要です。ZIP を展開し、memory_oop フォルダーでターミナルを開きます。

```sh
python main.py --lang ja --sample
python -m unittest discover -s tests -v
```

Python 版はターミナルで状態を観察するプログラムです。ウェブ版は同じルールを TypeScript で実装しており、Python のインストールは不要です。

`pick C01`、`step`、`pick C02`、`step`、`step`、`step` の順に入力すると一組が一致します。`inspect C01` は属性を表示します。`confirm` は比較と確定をまとめて実行します。`sample` は固定の盤面、`new` はシャッフルしたゲームを作り、`quit` で終了します。

## ファイル構成

- `model.py`：Python モデル全体。first、second、pending は Board 内の既存の Card を参照します。
- `main.py`：中英日のターミナル表示。
- `tests/test_model.py`：一致、コマ送り、参照、リセットのテスト。
- `browser/engine.ts`：授業サイトで使う TypeScript モデル。
- `docs/lesson-ja.html`：18 のトピック、クラス図、オブジェクト図、コード。オフラインで読めます。

比較では pair_id の値の一致を調べます。同じ絵のカードも別々のオブジェクトです。不一致なら既存のカードを裏返し、Board は同じ実体を保持します。新しいゲームは新しい Board と Card を生成します。
