"""Card-matching model. No UI, timer, or third-party dependency."""
from random import shuffle

SAMPLE = ['moon', 'moon', 'leaf', 'sun', 'leaf', 'sun',
          'star', 'gem', 'star', 'flower', 'gem', 'flower']


class Card:
    def __init__(self, name, pair_id):
        self.name = name
        self.pair_id = pair_id
        self.face_up = False
        self.matched = False

    def reveal(self):
        if self.face_up or self.matched:
            return False
        self.face_up = True
        return True

    def hide(self):
        if not self.matched:
            self.face_up = False

    def mark_matched(self):
        self.face_up = True
        self.matched = True


class Board:
    def __init__(self, sample=False):
        pairs = SAMPLE.copy()
        if not sample:
            shuffle(pairs)
        self.cards = [Card(f'C{i+1:02}', pair)
                      for i, pair in enumerate(pairs)]

    def get(self, name):
        return next((c for c in self.cards if c.name == name), None)

    @property
    def complete(self):
        return all(c.matched for c in self.cards)


class Game:
    def __init__(self, sample=False):
        self.board = Board(sample)
        self.first = None
        self.second = None
        self.pending = None
        self.phase = 'first'
        self.result = None
        self.turns = 0
        self.matches = 0

    def queue(self, name):
        if self.phase not in ('first', 'second') or self.pending:
            return False
        card = self.board.get(name)
        if card is None or card.face_up or card.matched:
            return False
        self.pending = card
        return True

    @property
    def can_step(self):
        return self.pending is not None or self.phase in ('compare', 'resolve')

    def step(self):
        if self.pending and self.phase in ('first', 'second'):
            card = self.pending
            self.pending = None
            card.reveal()
            if self.phase == 'first':
                self.first = card
                self.phase = 'second'
            else:
                self.second = card
                self.phase = 'compare'
            return True
        if self.phase == 'compare':
            self.compare()
            return True
        if self.phase == 'resolve':
            self.settle()
            return True
        return False

    def compare(self):
        if self.phase != 'compare' or not (self.first and self.second):
            return
        self.result = self.first.pair_id == self.second.pair_id
        self.turns += 1
        self.phase = 'resolve'

    def settle(self):
        if self.phase != 'resolve' or not (self.first and self.second):
            return
        if self.result:
            self.first.mark_matched()
            self.second.mark_matched()
            self.matches += 1
        else:
            self.first.hide()
            self.second.hide()
        self.first = self.second = None
        self.result = None
        self.phase = 'won' if self.board.complete else 'first'

    def play(self, name):
        if not self.queue(name):
            return False
        return self.step()

    def finish_turn(self):
        if self.phase == 'compare':
            self.compare()
        if self.phase == 'resolve':
            self.settle()
