-- 第 21 頁　CREATE TABLE 定義一筆紀錄的形狀
CREATE TABLE log (
    code TEXT NOT NULL PRIMARY KEY,
    reader TEXT NOT NULL,
    title TEXT NOT NULL,
    minutes INTEGER NOT NULL CHECK (minutes >= 0)
);

-- 第 22 頁　INSERT INTO 把三次閱讀寫進表裡
INSERT INTO log (code, reader, title, minutes)
VALUES
    ('R01', 'U1', '海邊散步', 25),
    ('R02', 'U2', '城市地圖', 40),
    ('R03', 'U1', '森林日記', 15);

-- 第 23 頁　SELECT 選欄位，FROM 選資料表
SELECT title, minutes
FROM log
ORDER BY code;

-- 第 24 頁　WHERE 決定哪些列可以留下
SELECT code, title
FROM log
WHERE reader = 'U1' AND minutes >= 25;

-- 第 25 頁　ORDER BY 與 LIMIT 找出前兩名
SELECT title, minutes
FROM log
ORDER BY minutes DESC, code ASC
LIMIT 2;

-- 第 26 頁　COUNT、SUM 與 AVG 把多列算成一列
SELECT COUNT(*) AS sessions,
       SUM(minutes) AS total,
       ROUND(AVG(minutes), 1) AS average
FROM log;

-- 第 27 頁　GROUP BY 分組，HAVING 篩選整組
SELECT reader, COUNT(*) AS sessions, SUM(minutes) AS total
FROM log
GROUP BY reader
HAVING COUNT(*) >= 2;

-- 第 28 頁　JOIN 用共同的讀者代號找回姓名
CREATE TABLE readers (id TEXT NOT NULL PRIMARY KEY, name TEXT NOT NULL);
INSERT INTO readers VALUES ('U1', '小安'), ('U2', '小禾');
SELECT r.name, l.title
FROM log AS l
JOIN readers AS r ON r.id = l.reader
ORDER BY l.code;

-- 第 29 頁　UPDATE 修改既有紀錄
SELECT code, minutes FROM log WHERE code = 'R01';
UPDATE log
SET minutes = minutes + 10
WHERE code = 'R01';
SELECT code, minutes FROM log WHERE code = 'R01';

-- 第 30 頁　BEGIN 與 ROLLBACK：先試刪，再復原
BEGIN;
DELETE FROM log WHERE code = 'R03';
SELECT COUNT(*) FROM log;
ROLLBACK;
SELECT COUNT(*) FROM log;

-- 第 31 頁　DELETE 與 COMMIT：確認後保留刪除
SELECT title FROM log WHERE code = 'R03';
BEGIN;
DELETE FROM log WHERE code = 'R03';
COMMIT;
SELECT COUNT(*), SUM(minutes) FROM log;
