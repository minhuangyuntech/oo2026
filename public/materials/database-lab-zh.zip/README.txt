Python 讀書紀錄實作

將本壓縮檔解開到 reading_lab，在該資料夾開啟終端機。依投影片第 18 頁建立並啟用 .venv。

SQL 指令練習（第 20–32 頁）
python run_sql_lab.py

編輯 sql_basics.sql 可修改查詢。每條敘述以分號結束，下一條另起一行；每次執行從新的記憶體資料庫開始。

SQLite（不需額外安裝套件）
python sqlite_lab.py

MongoDB（個人電腦上安裝並啟動 Docker 後，第一次建立服務）
docker run -d --name reading-mongo -p 127.0.0.1:27017:27017 -v reading-data:/data/db mongo:8.0
docker ps
python -m pip install "pymongo>=4,<5"
python -c "import pymongo; print(pymongo.version)"
python mongo_lab.py

兩支程式都從三筆紀錄開始，最後留下兩筆、合計 75 分鐘。
重新執行前，將 SQLite 檔名 reading_01.db 或 MongoDB 集合 readings_01 改為未使用的名稱。
已有練習容器時使用 docker start reading-mongo，課後用 docker stop reading-mongo。
若使用其他 MongoDB 服務，將 MONGODB_URI 環境變數設為自己的連線字串。
