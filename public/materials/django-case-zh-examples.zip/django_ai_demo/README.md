# Django 網站實作案例：AI 服務

這是依投影片第 89–127 頁整理的獨立專案，不會覆蓋 mblog 部落格。

Python 3.13/3.14, Django 5.2 LTS.

先建立虛擬環境並安裝 requirements.txt，再執行以下命令。mock 測試不需要金鑰，不會呼叫雲端服務。

```sh
python manage.py check
python run_mock_tests.py
python manage.py runserver 127.0.0.1:8000
```

http://127.0.0.1:8000/ai/

使用 Ollama 前請依第 97 頁安裝、下載模型並啟動。雲端服務需要自己的金鑰與可用額度；將 .env.example 複製為 .env 後設定，勿提交 .env。範例僅供本機執行，公開部署前請完成第 126 頁的準備。
