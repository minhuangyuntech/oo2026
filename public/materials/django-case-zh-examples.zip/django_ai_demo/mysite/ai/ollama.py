from django.conf import settings
from .common import AIError, chat_messages, checked_text

def build_payload(prompt):
    model = settings.OLLAMA_MODEL
    if model not in settings.OLLAMA_ALLOWED_MODELS:
        raise AIError("config", "OLLAMA_MODEL 不在本機教學模型白名單內。")
    return {
        "model": model, "messages": chat_messages(prompt),
        "stream": False, "options": {"num_predict": 600},
    }

import requests
OLLAMA_URL = "http://127.0.0.1:11434/api/chat"

def send_local_request(payload):
    with requests.Session() as session:
        session.trust_env = False  # 不經系統代理、不讀取 netrc 憑證。
        response = session.post(
            OLLAMA_URL, json=payload,
            timeout=(3.05, 120), allow_redirects=False,
        )
        response.raise_for_status()
        if response.status_code != 200:
            raise AIError("http", "Ollama 回傳非預期 HTTP 狀態。")
        return response.json()

def request_ollama(payload):
    try:
        return send_local_request(payload)
    except requests.exceptions.Timeout:
        raise AIError("timeout", "Ollama 等候逾時，請檢查模型或稍後再試。") from None
    except requests.exceptions.ConnectionError:
        raise AIError("connection", "無法連線 Ollama，請確認本機服務已啟動。") from None
    except requests.exceptions.HTTPError:
        raise AIError("http", "Ollama HTTP 錯誤，請確認模型已下載與服務狀態。") from None
    except requests.exceptions.JSONDecodeError:
        raise AIError("json", "Ollama 回覆不是有效 JSON。") from None
    except requests.exceptions.RequestException:
        raise AIError("transport", "Ollama 傳輸失敗，請稍後再試。") from None

def extract_content(data):
    if not isinstance(data, dict) or data.get("error"):
        raise AIError("format", "Ollama 回覆格式不正確或包含錯誤。")
    message = data.get("message")
    if not isinstance(message, dict) or data.get("done") is not True:
        raise AIError("format", "Ollama 未回傳完整訊息。")
    if data.get("done_reason") == "length":
        raise AIError("incomplete", "回覆達到長度上限，請縮小問題範圍後再試。")
    return checked_text(message.get("content"))

class OllamaProvider:
    def generate(self, prompt):
        payload = build_payload(prompt)
        data = request_ollama(payload)
        return extract_content(data)
