import openai
from .common import AIError, require_key

def make_client(api_key, name, base_url):
    return openai.OpenAI(
        api_key=require_key(api_key, name), base_url=base_url,
        timeout=120.0, max_retries=0,
    )

def sdk_error(exc):
    if isinstance(exc, openai.APITimeoutError):
        return AIError("timeout", "雲端服務等候逾時，請稍後再試。")
    if isinstance(exc, openai.APIConnectionError):
        return AIError("connection", "無法連線雲端服務，請檢查網路。")
    status = getattr(exc, "status_code", None)
    if status in (401, 403):
        return AIError("auth", "請檢查 API key 與帳號的模型使用權限。")
    if status == 429:
        return AIError("rate_limit", "已達速率或額度限制，請檢查方案並稍後再試。")
    if status == 404:
        return AIError("model", "找不到指定模型，請核對模型 ID 與可用權限。")
    return AIError("api", "雲端 API 回覆錯誤，請檢查服務狀態或設定。")

def sdk_call(operation):
    try:
        return operation()
    except openai.OpenAIError as exc:
        raise sdk_error(exc) from None
    except ValueError:
        raise AIError("json", "雲端服務回覆無法解析，請稍後再試。") from None
