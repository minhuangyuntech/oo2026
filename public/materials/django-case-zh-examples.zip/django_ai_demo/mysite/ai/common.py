class AIError(Exception):
    def __init__(self, code, message):
        self.code = code
        super().__init__(message)

def checked_text(value):
    if not isinstance(value, str) or not value.strip():
        raise AIError("empty", "服務未回傳可顯示的文字，請換個問題或稍後再試。")
    if len(value) > 20000:
        raise AIError("too_long", "回覆過長，請縮小問題範圍後再試。")
    return value.strip()

SYSTEM_PROMPT = "請用繁體中文簡短回答。若不確定，請明說不確定。"

def chat_messages(prompt):
    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": prompt},
    ]

def require_key(value, provider_name):
    if not isinstance(value, str) or not value.strip():
        raise AIError("config", f"尚未設定 {provider_name} 的伺服器端 API key。")
    return value.strip()
