from django import forms

PROVIDER_CHOICES = [
    ("ollama", "Ollama（本機）"),
    ("openai", "OpenAI API（雲端）"),
    ("nvidia", "NVIDIA hosted API（雲端）"),
]

class PromptForm(forms.Form):
    provider = forms.ChoiceField(label="服務來源", choices=PROVIDER_CHOICES)
    prompt = forms.CharField(
        label="你的問題", max_length=2000, strip=True,
        widget=forms.Textarea(attrs={"rows": 6, "maxlength": 2000}),
        help_text="最多 2,000 字元；雲端選項會將內容送至該服務。",
        error_messages={
            "required": "請先輸入問題，不能只輸入空白。",
            "max_length": "問題不可超過 2,000 字元。",
        },
    )
