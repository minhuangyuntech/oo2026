# 第 15 頁：相同狀態與相同身分
# Python 3.12+

class Student:
    def __init__(self, name):
        self.name = name

a = Student("Amy")
b = Student("Amy")
alias = a

print(a.name == b.name)
print(a is b)
print(a == b)
print(alias is a)
