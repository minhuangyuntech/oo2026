# 第 9 頁：第一個 Student 類別
# Python 3.12+

class Student:
    def __init__(self, student_id, name):
        self.student_id = student_id
        self.name = name

    def rename(self, new_name):
        self.name = new_name

amy = Student("B11501", "Amy")
amy.rename("Amy Chen")
print(amy.student_id, amy.name)
