# 第 14 頁：兩個實體，各自保存狀態
# Python 3.12+

class Student:
    def __init__(self, name):
        self.name = name
        self.courses = []

amy = Student("Amy")
bob = Student("Bob")
amy.courses.append("Python")

print(amy.courses)
print(bob.courses)
print(amy.courses is bob.courses)
