# 第三週 Python 範例

主題：類別、物件與物件模型。

使用 Python 3.12 或更新版本。不需安裝第三方套件。

每個 slide_XX.py 都是獨立範例，XX 對應簡報頁碼。檔案內各自定義類別，因此不需按順序執行，也不應直接拼接所有檔案。

執行方式，例如：

```sh
python slide_09.py
```

第 33、34 頁的檔案已包含前頁使用的完整 BankAccount 定義。第 33 頁簡報上方是類別內方法的節錄，請使用本附檔執行完整示例。

「錯誤案例」用來展示共享、遮蔽或驗證限制的實際行為，並非待完成作業。

## 範例清單與預期輸出

### slide_07.py：Python 中的型別與物件

```text
Student
True
type
True
```

### slide_09.py：第一個 Student 類別

```text
B11501 Amy Chen
```

### slide_11.py：__new__ 與 __init__ 的執行順序

```text
new
init
Book
```

### slide_12.py：self 與繫結方法

```text
5
True
```

### slide_13.py：區域變數與 self 屬性

```text
Amy
Ann
False
```

### slide_14.py：兩個實體，各自保存狀態

```text
['Python']
[]
False
```

### slide_15.py：相同狀態與相同身分

```text
True
False
False
True
```

### slide_16.py：共用參照與重新綁定

```text
Ann
Ann Bob
False
```

### slide_17.py：觀察實體的 __dict__

```text
{'name': 'Amy'}
False
True
YunTech
```

### slide_19.py：類別屬性作為共同預設值

```text
YunTech YunTech
New Campus New Campus
```

### slide_20.py：實體屬性遮蔽類別屬性

```text
Exchange YunTech
YunTech
YunTech
```

### slide_21.py：錯誤案例：共用可變類別屬性

```text
['Python']
True
```

### slide_22.py：修正：每個實體建立自己的容器

```text
['Python'] []
```

### slide_23.py：類別屬性統計建立次數

```text
2
2
```

### slide_24.py：self.count += 1 的遮蔽陷阱

```text
0
1 1
{'count': 1}
```

### slide_26.py：classmethod 與替代建構子

```text
B11501 Amy
```

### slide_27.py：含引號的 CSV 欄位

```text
Chen, Amy
```

### slide_28.py：cls 保留衍生類別的建立能力

```text
GraduateStudent
```

### slide_29.py：staticmethod 與純工具操作

```text
Amy Chen
Bob
```

### slide_32.py：BankAccount：建立時驗證資料

```text
Amy 100
```

### slide_33.py：BankAccount：方法維持狀態規則

```text
rejected
120
```

### slide_34.py：公有屬性與規則的邊界

```text
-999
```

### slide_35.py：__repr__ 提供可讀的物件表示

```text
Student('B11501', 'Amy')
```

### slide_36.py：外部可變資料的歸屬

```text
['Python', 'Java']
['Python']
```

### slide_37.py：網站範例：Student 的完整串接

```text
Amy YunTech 2
```

