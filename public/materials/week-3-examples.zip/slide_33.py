# 第 33 頁：BankAccount：方法維持狀態規則
# Python 3.12+

class BankAccount:
    def __init__(self, owner: str, balance: int = 0):
        if not isinstance(owner, str) or not owner.strip():
            raise ValueError("owner required")
        if type(balance) is not int or balance < 0:
            raise ValueError("invalid balance")
        self.owner = owner.strip()
        self.balance = balance

    def deposit(self, amount: int) -> None:
        if type(amount) is not int or amount <= 0:
            raise ValueError("positive integer required")
        self.balance += amount

account = BankAccount("Amy", 100)
account.deposit(20)
try:
    account.deposit(-5)
except ValueError:
    print("rejected")
print(account.balance)
