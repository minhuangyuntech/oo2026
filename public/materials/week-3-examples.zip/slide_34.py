# 第 34 頁：公有屬性與規則的邊界
# Python 3.12+

class BankAccount:
    def __init__(self, owner: str, balance: int = 0):
        if not isinstance(owner, str) or not owner.strip():
            raise ValueError("owner required")
        if type(balance) is not int or balance < 0:
            raise ValueError("invalid balance")
        self.owner = owner.strip()
        self.balance = balance

    def deposit(self, amount: int) -> None:
        if type(amount) is not int or amount <= 0:
            raise ValueError("positive integer required")
        self.balance += amount

# BankAccount from the previous slide
account = BankAccount("Amy", 100)
account.balance = -999

print(account.balance)
