# 第 37 頁：網站範例：Student 的完整串接
# Python 3.12+

class Student:
    school = "YunTech"
    count = 0

    def __init__(self, student_id: str, name: str):
        self.student_id = student_id
        self.name = name
        Student.count += 1

    @classmethod
    def from_csv(cls, row: str) -> "Student":
        student_id, name = row.split(",")
        return cls(student_id.strip(), name.strip())

amy = Student.from_csv("B11301, Amy")
bob = Student("B11302", "Bob")
print(amy.name, amy.school, Student.count)
