# 第 35 頁：__repr__ 提供可讀的物件表示
# Python 3.12+

class Student:
    def __init__(self, student_id, name):
        self.student_id = student_id
        self.name = name

    def __repr__(self):
        return (
            f"Student({self.student_id!r}, "
            f"{self.name!r})"
        )

amy = Student("B11501", "Amy")
print(repr(amy))
