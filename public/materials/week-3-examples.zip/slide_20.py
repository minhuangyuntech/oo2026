# 第 20 頁：實體屬性遮蔽類別屬性
# Python 3.12+

class Student:
    school = "YunTech"

a = Student()
b = Student()
a.school = "Exchange"

print(a.school, b.school)
print(Student.school)
del a.school
print(a.school)
