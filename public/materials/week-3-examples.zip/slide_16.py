# 第 16 頁：共用參照與重新綁定
# Python 3.12+

class Student:
    def __init__(self, name):
        self.name = name

a = Student("Amy")
b = a
b.name = "Ann"
print(a.name)

b = Student("Bob")
print(a.name, b.name)
print(a is b)
