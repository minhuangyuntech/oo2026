# 第 23 頁：類別屬性統計建立次數
# Python 3.12+

class Student:
    count = 0

    def __init__(self, name):
        self.name = name
        Student.count += 1

a = Student("Amy")
b = Student("Bob")
print(Student.count)
del a
print(Student.count)
