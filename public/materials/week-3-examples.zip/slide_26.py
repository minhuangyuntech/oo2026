# 第 26 頁：classmethod 與替代建構子
# Python 3.12+

class Student:
    def __init__(self, student_id, name):
        self.student_id = student_id
        self.name = name

    @classmethod
    def from_csv(cls, row):
        student_id, name = row.split(",")
        return cls(student_id.strip(), name.strip())

amy = Student.from_csv("B11501, Amy")
print(amy.student_id, amy.name)
