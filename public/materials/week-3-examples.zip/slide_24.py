# 第 24 頁：self.count += 1 的遮蔽陷阱
# Python 3.12+

class Student:
    count = 0

    def __init__(self):
        self.count += 1

a = Student()
b = Student()

print(Student.count)
print(a.count, b.count)
print(vars(a))
