# 第 19 頁：類別屬性作為共同預設值
# Python 3.12+

class Student:
    school = "YunTech"

a = Student()
b = Student()

print(a.school, b.school)
Student.school = "New Campus"
print(a.school, b.school)
