# 第 27 頁：含引號的 CSV 欄位
# Python 3.12+

import csv

class Student:
    def __init__(self, student_id, name):
        self.student_id = student_id
        self.name = name

    @classmethod
    def from_csv(cls, row):
        fields = next(csv.reader([row]))
        student_id, name = fields
        return cls(student_id.strip(), name.strip())

s = Student.from_csv('B11501,"Chen, Amy"')
print(s.name)
