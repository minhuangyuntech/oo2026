# 第 36 頁：外部可變資料的歸屬
# Python 3.12+

class Student:
    def __init__(self, name, courses=None):
        self.name = name
        self.courses = (
            [] if courses is None else list(courses)
        )

source = ["Python"]
amy = Student("Amy", source)
source.append("Java")
print(source)
print(amy.courses)
