# 第 32 頁：BankAccount：建立時驗證資料
# Python 3.12+

class BankAccount:
    def __init__(self, owner: str, balance: int = 0):
        if not isinstance(owner, str) or not owner.strip():
            raise ValueError("owner required")
        if type(balance) is not int or balance < 0:
            raise ValueError("invalid balance")
        self.owner = owner.strip()
        self.balance = balance

account = BankAccount("Amy", 100)
print(account.owner, account.balance)
