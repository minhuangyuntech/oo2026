# 第 7 頁：Python 中的型別與物件
# Python 3.12+

class Student:
    pass

amy = Student()

print(type(amy).__name__)
print(isinstance(amy, Student))
print(type(Student).__name__)
print(isinstance(Student, type))
