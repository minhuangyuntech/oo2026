# 第 28 頁：cls 保留衍生類別的建立能力
# Python 3.12+

class Student:
    def __init__(self, name):
        self.name = name

    @classmethod
    def from_name(cls, name):
        return cls(name)

class GraduateStudent(Student):
    pass

s = GraduateStudent.from_name("Amy")
print(type(s).__name__)
