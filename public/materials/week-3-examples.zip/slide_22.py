# 第 22 頁：修正：每個實體建立自己的容器
# Python 3.12+

class Student:
    def __init__(self, name):
        self.name = name
        self.courses = []

    def enroll(self, course):
        self.courses.append(course)

a = Student("Amy")
b = Student("Bob")
a.enroll("Python")
print(a.courses, b.courses)
