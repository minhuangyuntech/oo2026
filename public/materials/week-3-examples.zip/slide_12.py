# 第 12 頁：self 與繫結方法
# Python 3.12+

class Counter:
    def __init__(self):
        self.value = 0

    def add(self, amount):
        self.value += amount

c = Counter()
c.add(2)
Counter.add(c, 3)
print(c.value)
print(c.add.__self__ is c)
