# 第 17 頁：觀察實體的 __dict__
# Python 3.12+

class Student:
    school = "YunTech"

    def __init__(self, name):
        self.name = name

amy = Student("Amy")
print(vars(amy))
print("school" in vars(amy))
print("school" in vars(Student))
print(amy.school)
