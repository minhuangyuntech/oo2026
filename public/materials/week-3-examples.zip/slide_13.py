# 第 13 頁：區域變數與 self 屬性
# Python 3.12+

class Student:
    def __init__(self, name):
        self.name = name

    def rename(self, name):
        old_name = self.name
        self.name = name
        return old_name

amy = Student("Amy")
print(amy.rename("Ann"))
print(amy.name)
print(hasattr(amy, "old_name"))
