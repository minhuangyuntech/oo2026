# 第 11 頁：__new__ 與 __init__ 的執行順序
# Python 3.12+

class Item:
    def __new__(cls, name):
        print("new")
        return super().__new__(cls)

    def __init__(self, name):
        print("init")
        self.name = name

item = Item("Book")
print(item.name)
