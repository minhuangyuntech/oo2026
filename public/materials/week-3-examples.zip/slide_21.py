# 第 21 頁：錯誤案例：共用可變類別屬性
# Python 3.12+

class Student:
    courses = []

    def __init__(self, name):
        self.name = name

a = Student("Amy")
b = Student("Bob")
a.courses.append("Python")

print(b.courses)
print(a.courses is b.courses)
