# 第 29 頁：staticmethod 與純工具操作
# Python 3.12+

class Student:
    @staticmethod
    def normalize_name(name):
        return " ".join(name.split())

print(Student.normalize_name("  Amy   Chen  "))

s = Student()
print(s.normalize_name("  Bob  "))
