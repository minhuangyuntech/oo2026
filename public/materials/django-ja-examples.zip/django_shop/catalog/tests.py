from decimal import Decimal
from django.test import Client, TestCase
from django.urls import reverse
from .forms import ProductForm
from .models import Product


class CatalogTests(TestCase):
    def setUp(self):
        self.product = Product.objects.create(name="Keyboard", price=Decimal("1290"), stock=8)

    def test_list_renders_product(self):
        response = self.client.get(reverse("catalog:product_list"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Keyboard")
        self.assertTemplateUsed(response, "catalog/product_list.html")

    def test_missing_product_returns_404(self):
        self.assertEqual(self.client.get(reverse("catalog:product_detail", args=[999])).status_code, 404)

    def test_property_reflects_stock(self):
        self.assertTrue(self.product.in_stock)
        self.product.stock = 0
        self.assertFalse(self.product.in_stock)

    def test_negative_price_is_invalid(self):
        form = ProductForm(data={"name": "Bad", "price": "-1", "stock": "1"})
        self.assertFalse(form.is_valid())
        self.assertIn("price", form.errors)

    def test_valid_post_saves_and_redirects(self):
        response = self.client.post(reverse("catalog:product_create"), {"name": "Mouse", "price": "590", "stock": "4"})
        self.assertRedirects(response, reverse("catalog:product_list"))
        self.assertTrue(Product.objects.filter(name="Mouse").exists())

    def test_invalid_post_does_not_save(self):
        response = self.client.post(reverse("catalog:product_create"), {"name": "Bad", "price": "-1", "stock": "1"})
        self.assertEqual(response.status_code, 200)
        self.assertFalse(Product.objects.filter(name="Bad").exists())

    def test_csrf_required(self):
        client = Client(enforce_csrf_checks=True)
        response = client.post(reverse("catalog:product_create"), {"name": "NoToken", "price": "1", "stock": "1"})
        self.assertEqual(response.status_code, 403)

    def test_hello_route(self):
        self.assertContains(self.client.get(reverse("catalog:hello")), "Hello, Django!")
