from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_http_methods
from .forms import ProductForm
from .models import Product


def hello(request):
    return HttpResponse("Hello, Django!")


def product_list(request):
    products = Product.objects.order_by("name")
    return render(request, "catalog/product_list.html", {"products": products})


def product_detail(request, pk):
    product = get_object_or_404(Product, pk=pk)
    return render(request, "catalog/product_detail.html", {"product": product})


@require_http_methods(["GET", "POST"])
def product_create(request):
    if request.method == "POST":
        form = ProductForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("catalog:product_list")
    else:
        form = ProductForm()
    return render(request, "catalog/product_form.html", {"form": form})
