# Django 入門サンプル：商品カタログ

`Django_Website_Setup_and_Project_Files_JA-v3.pptx` の付属プロジェクトです。Python 3.12、Django 5.2 を使用します。

## 完成版の起動（Windows PowerShell）

manage.py があるこのフォルダーで実行します。

```powershell
python -m venv .venv
.\.venv\Scripts\python -m pip install -r requirements.txt
.\.venv\Scripts\python manage.py migrate
.\.venv\Scripts\python manage.py runserver
```

ブラウザーで http://127.0.0.1:8000/products/ を開きます。停止するときは Ctrl+C を押します。

完成済みのプロジェクトです。startproject や startapp の再実行は不要です。移行ファイルが付属するため、初回は migrate だけを実行します。
データベース、仮想環境、共通アカウント、利用者データは含みません。最初は一覧が空なので、`/products/new/` で商品を登録します。

macOS / Linux：`python3 -m venv .venv` で環境を作成し、上記のコマンドでは `.venv/bin/python` を使います。

## 管理画面とテスト

```powershell
.\.venv\Scripts\python manage.py createsuperuser
.\.venv\Scripts\python manage.py test catalog
.\.venv\Scripts\python manage.py check
```

管理画面：`http://127.0.0.1:8000/admin/`。管理者のパスワードは各自で設定します。

## URL

| URL | 機能 |
|---|---|
| `/products/hello/` | 最小限の文字列レスポンス |
| `/products/` | 商品一覧 |
| `/products/new/` | 商品登録フォーム |
| `/products/1/` | 主キー 1 の商品詳細。存在しなければ 404 |
| `/admin/` | Django 管理画面 |

ルート `/` は未定義のため 404 を返します。

## 各ファイルの用途

* 印は、自動生成後に編集したファイルを表します。

| 場所 | 作成元 | 用途 |
|---|---|---|
| `manage.py` | startproject | 管理コマンドを実行し、Django 設定を選択 |
| `config/__init__.py` | startproject | 設定パッケージの目印 |
| `config/settings.py` | startproject* | app、DB、テンプレート、ミドルウェア、言語、タイムゾーンの設定 |
| `config/urls.py` | startproject* | catalog と admin に接続するルート URL 設定 |
| `config/wsgi.py` | startproject | WSGI サーバーの入口 |
| `config/asgi.py` | startproject | ASGI サーバーの入口 |
| `catalog/__init__.py` | startapp | app パッケージの目印 |
| `catalog/apps.py` | startapp | CatalogConfig 設定クラス |
| `catalog/models.py` | startapp* | Product の項目、in_stock プロパティ、文字列表現 |
| `catalog/views.py` | startapp* | 文字列応答、商品一覧、詳細、登録処理 |
| `catalog/admin.py` | startapp* | Product の登録、一覧項目、検索設定 |
| `catalog/tests.py` | startapp* | 8 項目の動作テスト |
| `catalog/migrations/__init__.py` | startapp | 移行パッケージの目印 |
| `catalog/migrations/0001_initial.py` | makemigrations | Product テーブルを作成する変更の記述 |
| `catalog/urls.py` | 手動で追加 | app の URL と名前空間 |
| `catalog/forms.py` | 手動で追加 | ProductForm の項目、ラベル、検証 |
| `catalog/templates/catalog/base.html` | 手動で追加 | 共通 HTML、CSS、ナビゲーション、フッター |
| `catalog/templates/catalog/product_list.html` | 手動で追加 | 商品一覧と在庫状況 |
| `catalog/templates/catalog/product_detail.html` | 手動で追加 | 1 件の商品の詳細 |
| `catalog/templates/catalog/product_form.html` | 手動で追加 | POST フォーム、CSRF token、検証メッセージ |
| `catalog/static/catalog/site.css` | 手動で追加 | レイアウト、フォント、配色 |
| `requirements.txt` | 手動で追加 | Django のバージョン範囲 |
| `.gitignore` | 手動で追加 | ローカル環境、キャッシュ、DB の除外 |
| `README.md` | 手動で追加 | 実行手順とファイル一覧 |

実行時に `.venv/`、`__pycache__/`、`db.sqlite3` が生成されます。これらは ZIP に含みません。

## サンプルの範囲

ローカル授業用のサイトです。`DEBUG=True` と固定の教材用 SECRET_KEY は本番環境に適しません。
商品登録ページにはログイン制限がありません。公開前に認証と権限管理を追加してください。
ModelForm は価格を検証します。ORM で直接保存する場合は、適切な検証と必要な DB 制約を別途設けます。
アップロード機能、.env ローダー、本番用のデプロイ設定は含みません。
画面言語は日本語です。元の例と同じくタイムゾーンは Asia/Taipei、通貨は NT$ のままです。
