# 成績簿測試範例（Python 程式測試：原理與方法）

用一個成績簿類別 `GradeBook` 練習 unittest 與 pytest。主程式只用標準函式庫，測試需要 pytest。

## 環境準備

```bash
python -m venv .venv
# Windows PowerShell
.venv\Scripts\Activate.ps1
# macOS / Linux
source .venv/bin/activate

pip install -r requirements.txt
```

## 執行

以下指令都在這個資料夾執行。

```bash
python -m demo.mini_runner                          # 迷你測試執行器：1 passed, 1 failed, 1 error
python -m unittest discover -s tests_unittest -v    # unittest 版本：6 個測試
pytest -v                                           # pytest 版本：21 個測試
pytest tests_unittest                               # pytest 也能執行 unittest 的測試
```

## 檔案導覽

| 路徑 | 內容 |
|---|---|
| `gradebook.py` | `GradeBook` 類別與 `letter_grade()` |
| `demo/mini_runner.py` | 迷你測試執行器：收集、執行、回報 |
| `demo/sample_tests.py` | 給迷你執行器的測試（刻意包含一個失敗、一個錯誤） |
| `tests_unittest/` | unittest 寫法：`TestCase`、`setUp`、`assertRaises`、`subTest` |
| `tests/conftest.py` | pytest 共用的 fixture `book` |
| `tests/test_gradebook.py` | pytest 寫法：fixture、`pytest.raises`、`pytest.approx`、`tmp_path` |
| `tests/test_letter_grade.py` | `@pytest.mark.parametrize` 測試每個邊界 |
| `exercises/boundaries/` | 課堂練習：用邊界值找出 `grading.py` 的錯誤 |
| `pyproject.toml` | pytest 設定：`pythonpath`、`testpaths` |

## 課堂練習

```bash
pytest exercises/boundaries -v   # 一開始全部通過，但 grading.py 藏了一個錯誤
```

在 `test_grading.py` 補上邊界值測試，看到紅燈後再修正 `grading.py`。修正前不要改規格，也不要刪測試。
