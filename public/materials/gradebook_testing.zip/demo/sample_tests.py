"""給迷你執行器用的測試：一個通過、一個失敗、一個錯誤。"""

from gradebook import GradeBook


def test_average_of_two_scores():
    book = GradeBook()                 # Arrange 準備
    book.add("A001", 80)
    book.add("A002", 90)
    result = book.average()            # Act 執行
    assert result == 85                # Assert 驗證


def test_passed_list():
    book = GradeBook()
    book.add("A001", 59)
    book.add("A002", 60)
    assert book.passed() == ["A001", "A002"], "預期 59 分也及格"


def test_score_of_unknown_student():
    book = GradeBook()
    assert book.score_of("Z999") == 0
