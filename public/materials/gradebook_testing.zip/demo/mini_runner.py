"""迷你測試執行器：示範測試框架做的三件事——收集、執行、回報。

在專案資料夾執行：python -m demo.mini_runner
"""

import inspect

from demo import sample_tests


def collect(module):
    """收集：找出名稱以 test_ 開頭的函式。"""
    return [(name, func) for name, func in inspect.getmembers(module, inspect.isfunction)
            if name.startswith("test_")]


def run(tests):
    """執行並回報：每個測試各自執行，一個失敗不影響下一個。"""
    results = {"passed": 0, "failed": 0, "error": 0}
    for name, func in tests:
        try:
            func()
        except AssertionError as exc:
            results["failed"] += 1
            print(f"FAIL  {name}：{exc}")
        except Exception as exc:
            results["error"] += 1
            print(f"ERROR {name}：{type(exc).__name__} {exc}")
        else:
            results["passed"] += 1
            print(f"PASS  {name}")
    print(", ".join(f"{count} {kind}" for kind, count in results.items()))


if __name__ == "__main__":
    run(collect(sample_tests))
