"""放在 tests/ 的共用 fixture，所有測試檔都能直接使用。"""

import pytest

from gradebook import GradeBook


@pytest.fixture
def book() -> GradeBook:
    """兩位學生的成績簿；每個測試都拿到一個新的。"""
    gradebook = GradeBook()
    gradebook.add("A001", 80)
    gradebook.add("A002", 90)
    return gradebook
