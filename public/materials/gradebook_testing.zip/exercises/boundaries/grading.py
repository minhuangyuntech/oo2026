"""練習：這個 letter_grade 藏了一個邊界錯誤。

規格：90 以上 A、80 以上 B、70 以上 C、60 以上 D，其餘 F；
0～100 以外的分數要拋出 ValueError。
"""


def letter_grade(score: int) -> str:
    if not 0 <= score <= 100:
        raise ValueError(f"分數必須介於 0 到 100：{score}")
    if score >= 90:
        return "A"
    if score > 80:
        return "B"
    if score >= 70:
        return "C"
    if score >= 60:
        return "D"
    return "F"
