"""練習：用 parametrize 補上邊界值測試，找出 grading.py 的錯誤。

1. 執行 pytest exercises/boundaries -v，目前的測試全部通過。
2. 把 test_boundaries 的資料補齊：每個等第的上下界，以及 -1、101。
3. 看到紅燈後，修正 grading.py，讓所有測試通過。
"""

import pytest

from grading import letter_grade


def test_typical_scores() -> None:
    assert letter_grade(95) == "A"
    assert letter_grade(85) == "B"
    assert letter_grade(75) == "C"
    assert letter_grade(65) == "D"
    assert letter_grade(30) == "F"


@pytest.mark.parametrize(
    "score, expected",
    [
        (100, "A"),
        # TODO：補上其他邊界值
    ],
)
def test_boundaries(score: int, expected: str) -> None:
    assert letter_grade(score) == expected
