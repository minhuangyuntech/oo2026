"""成績簿：Python 測試教材的範例類別。

GradeBook 保存每位學生的一筆分數，負責檢查分數是否有效、計算平均、
列出及格名單，並能存成 CSV 或從 CSV 讀回。
"""

import csv
from pathlib import Path

PASSING_SCORE = 60


def letter_grade(score: int) -> str:
    """把 0～100 的分數換成等第：90 以上 A、80 以上 B、70 以上 C、60 以上 D，其餘 F。"""
    if not 0 <= score <= 100:
        raise ValueError(f"分數必須介於 0 到 100：{score}")
    if score >= 90:
        return "A"
    if score >= 80:
        return "B"
    if score >= 70:
        return "C"
    if score >= 60:
        return "D"
    return "F"


class GradeBook:
    def __init__(self) -> None:
        self._scores: dict[str, int] = {}

    def add(self, student_id: str, score: int) -> None:
        if not student_id:
            raise ValueError("學號不可空白")
        if not 0 <= score <= 100:
            raise ValueError(f"分數必須介於 0 到 100：{score}")
        if student_id in self._scores:
            raise ValueError(f"{student_id} 已經有成績")
        self._scores[student_id] = score

    def score_of(self, student_id: str) -> int:
        return self._scores[student_id]

    def __len__(self) -> int:
        return len(self._scores)

    def average(self) -> float:
        if not self._scores:
            raise ValueError("成績簿沒有任何成績")
        return sum(self._scores.values()) / len(self._scores)

    def passed(self) -> list[str]:
        """回傳及格（60 分以上）的學號，依學號排序。"""
        return sorted(sid for sid, score in self._scores.items() if score >= PASSING_SCORE)

    def save_csv(self, path: Path) -> None:
        with path.open("w", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)
            writer.writerow(["student_id", "score"])
            for sid, score in sorted(self._scores.items()):
                writer.writerow([sid, score])

    @classmethod
    def load_csv(cls, path: Path) -> "GradeBook":
        book = cls()
        with path.open(newline="", encoding="utf-8") as file:
            for row in csv.DictReader(file):
                book.add(row["student_id"], int(row["score"]))
        return book
