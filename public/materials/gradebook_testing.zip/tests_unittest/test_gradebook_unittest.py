"""用標準函式庫 unittest 測試 GradeBook。

在專案資料夾執行：python -m unittest discover -s tests_unittest -v
"""

import unittest

from gradebook import GradeBook, letter_grade


class TestGradeBook(unittest.TestCase):
    def setUp(self) -> None:
        # 每個測試方法執行前都會重新建立，測試之間互不影響
        self.book = GradeBook()
        self.book.add("A001", 80)
        self.book.add("A002", 90)

    def test_average(self) -> None:
        self.assertEqual(self.book.average(), 85)

    def test_add_increases_count(self) -> None:
        self.book.add("A003", 70)
        self.assertEqual(len(self.book), 3)

    def test_passed_is_sorted(self) -> None:
        self.book.add("A000", 59)
        self.assertEqual(self.book.passed(), ["A001", "A002"])

    def test_score_out_of_range(self) -> None:
        with self.assertRaises(ValueError):
            self.book.add("A003", 101)

    def test_duplicate_student(self) -> None:
        with self.assertRaisesRegex(ValueError, "已經有成績"):
            self.book.add("A001", 70)


class TestLetterGrade(unittest.TestCase):
    def test_boundaries(self) -> None:
        cases = [(100, "A"), (90, "A"), (89, "B"), (80, "B"), (60, "D"), (59, "F"), (0, "F")]
        for score, expected in cases:
            with self.subTest(score=score):
                self.assertEqual(letter_grade(score), expected)


if __name__ == "__main__":
    unittest.main()
