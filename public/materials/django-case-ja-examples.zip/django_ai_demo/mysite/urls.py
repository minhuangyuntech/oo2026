from django.urls import path
from . import views

app_name = "mysite"
urlpatterns = [path("", views.ai_chat, name="ai")]