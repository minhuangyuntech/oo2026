from django.shortcuts import render
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_http_methods
from .ai.common import AIError
from .ai.registry import get_provider
from .forms import PromptForm

@never_cache
@require_http_methods(["GET", "POST"])
def ai_chat(request):
    form = PromptForm(request.POST if request.method == "POST" else None)
    answer = ""
    if request.method == "POST" and form.is_valid():
        try:
            provider = get_provider(form.cleaned_data["provider"])
            answer = provider.generate(form.cleaned_data["prompt"])
        except AIError as exc:
            form.add_error(None, str(exc))
    return render(request, "mysite/ai_chat.html", {
        "form": form, "answer": answer,
    })
