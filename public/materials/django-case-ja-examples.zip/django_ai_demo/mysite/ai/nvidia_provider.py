from django.conf import settings
from .common import AIError, chat_messages, checked_text

def create_completion(client, prompt):
    return client.chat.completions.create(
        model=settings.NVIDIA_MODEL, messages=chat_messages(prompt),
        max_tokens=600, stream=False,
        extra_body={"chat_template_kwargs": {"enable_thinking": False}},
    )

from .sdk_common import make_client, sdk_call
NVIDIA_BASE_URL = "https://integrate.api.nvidia.com/v1"

def completion_text(completion):
    choices = getattr(completion, "choices", None)
    if not isinstance(choices, list) or not choices:
        raise AIError("format", "NVIDIA 有効な choices が返されませんでした。")
    if getattr(choices[0], "finish_reason", None) == "length":
        raise AIError("incomplete", "回答が長さの上限に達しました。質問の範囲を絞って再試行してください。")
    message = getattr(choices[0], "message", None)
    return checked_text(getattr(message, "content", None))

class NvidiaProvider:
    def generate(self, prompt):
        with make_client(settings.NVIDIA_API_KEY, "NVIDIA", NVIDIA_BASE_URL) as client:
            completion = sdk_call(lambda: create_completion(client, prompt))
        return completion_text(completion)
