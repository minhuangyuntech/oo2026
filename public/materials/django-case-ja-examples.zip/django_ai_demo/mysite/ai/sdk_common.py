import openai
from .common import AIError, require_key

def make_client(api_key, name, base_url):
    return openai.OpenAI(
        api_key=require_key(api_key, name), base_url=base_url,
        timeout=120.0, max_retries=0,
    )

def sdk_error(exc):
    if isinstance(exc, openai.APITimeoutError):
        return AIError("timeout", "クラウドサービスがタイムアウトしました。後で再試行してください。")
    if isinstance(exc, openai.APIConnectionError):
        return AIError("connection", "クラウドサービスに接続できません。ネットワークを確認してください。")
    status = getattr(exc, "status_code", None)
    if status in (401, 403):
        return AIError("auth", "API キーとモデルの利用権限を確認してください。")
    if status == 429:
        return AIError("rate_limit", "速度または利用枠の上限です。プランを確認し、後で再試行してください。")
    if status == 404:
        return AIError("model", "モデルが見つかりません。ID と権限を確認してください。")
    return AIError("api", "クラウド API エラーです。サービス状態と設定を確認してください。")

def sdk_call(operation):
    try:
        return operation()
    except openai.OpenAIError as exc:
        raise sdk_error(exc) from None
    except ValueError:
        raise AIError("json", "クラウドの応答を解析できません。後で再試行してください。") from None
