class AIError(Exception):
    def __init__(self, code, message):
        self.code = code
        super().__init__(message)

def checked_text(value):
    if not isinstance(value, str) or not value.strip():
        raise AIError("empty", "表示できる文字列がありません。質問を変えるか、後で再試行してください。")
    if len(value) > 20000:
        raise AIError("too_long", "回答が長すぎます。質問の範囲を絞って再試行してください。")
    return value.strip()

SYSTEM_PROMPT = "日本語で簡潔に答えてください。不確かな場合は、その旨を明示してください。"

def chat_messages(prompt):
    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": prompt},
    ]

def require_key(value, provider_name):
    if not isinstance(value, str) or not value.strip():
        raise AIError("config", f"未設定： {provider_name} のサーバー側 API キー。")
    return value.strip()
