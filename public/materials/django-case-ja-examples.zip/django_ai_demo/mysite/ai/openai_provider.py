from django.conf import settings
from .common import AIError, SYSTEM_PROMPT, checked_text

def create_response(client, prompt):
    return client.responses.create(
        model=settings.OPENAI_MODEL,
        instructions=SYSTEM_PROMPT, input=prompt,
        reasoning={"effort": "none"}, max_output_tokens=600,
        store=False, stream=False,
    )

def response_text(response):
    if getattr(response, "status", None) != "completed":
        raise AIError("incomplete", "回答が未完了です。質問の範囲を絞って再試行してください。")
    return checked_text(getattr(response, "output_text", None))

from .sdk_common import make_client, sdk_call
OPENAI_BASE_URL = "https://api.openai.com/v1"

class OpenAIProvider:
    def generate(self, prompt):
        with make_client(settings.OPENAI_API_KEY, "OpenAI", OPENAI_BASE_URL) as client:
            response = sdk_call(lambda: create_response(client, prompt))
        return response_text(response)
