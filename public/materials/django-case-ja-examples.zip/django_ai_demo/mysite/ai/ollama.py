from django.conf import settings
from .common import AIError, chat_messages, checked_text

def build_payload(prompt):
    model = settings.OLLAMA_MODEL
    if model not in settings.OLLAMA_ALLOWED_MODELS:
        raise AIError("config", "OLLAMA_MODEL はローカルモデルの許可リストにありません。")
    return {
        "model": model, "messages": chat_messages(prompt),
        "stream": False, "options": {"num_predict": 600},
    }

import requests
OLLAMA_URL = "http://127.0.0.1:11434/api/chat"

def send_local_request(payload):
    with requests.Session() as session:
        session.trust_env = False  # システムプロキシや netrc の認証情報を使わない。
        response = session.post(
            OLLAMA_URL, json=payload,
            timeout=(3.05, 120), allow_redirects=False,
        )
        response.raise_for_status()
        if response.status_code != 200:
            raise AIError("http", "Ollama が予期しない HTTP ステータスを返しました。")
        return response.json()

def request_ollama(payload):
    try:
        return send_local_request(payload)
    except requests.exceptions.Timeout:
        raise AIError("timeout", "Ollama タイムアウトしました。モデルを確認するか、後で再試行してください。") from None
    except requests.exceptions.ConnectionError:
        raise AIError("connection", "Ollama に接続できません。ローカルサービスの起動を確認してください。") from None
    except requests.exceptions.HTTPError:
        raise AIError("http", "Ollama HTTP エラー。モデルの取得状況とサービスを確認してください。") from None
    except requests.exceptions.JSONDecodeError:
        raise AIError("json", "Ollama 応答が有効な JSON ではありません。") from None
    except requests.exceptions.RequestException:
        raise AIError("transport", "Ollama 通信に失敗しました。後で再試行してください。") from None

def extract_content(data):
    if not isinstance(data, dict) or data.get("error"):
        raise AIError("format", "Ollama 応答形式が不正、またはエラーを含みます。")
    message = data.get("message")
    if not isinstance(message, dict) or data.get("done") is not True:
        raise AIError("format", "Ollama 完全なメッセージが返されませんでした。")
    if data.get("done_reason") == "length":
        raise AIError("incomplete", "回答が長さの上限に達しました。質問の範囲を絞って再試行してください。")
    return checked_text(message.get("content"))

class OllamaProvider:
    def generate(self, prompt):
        payload = build_payload(prompt)
        data = request_ollama(payload)
        return extract_content(data)
