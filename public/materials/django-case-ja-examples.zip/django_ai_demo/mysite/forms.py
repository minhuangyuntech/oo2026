from django import forms

PROVIDER_CHOICES = [
    ("ollama", "Ollama（ローカル）"),
    ("openai", "OpenAI API（クラウド）"),
    ("nvidia", "NVIDIA hosted API（クラウド）"),
]

class PromptForm(forms.Form):
    provider = forms.ChoiceField(label="サービス", choices=PROVIDER_CHOICES)
    prompt = forms.CharField(
        label="質問", max_length=2000, strip=True,
        widget=forms.Textarea(attrs={"rows": 6, "maxlength": 2000}),
        help_text="最大 2,000 文字。クラウド選択時は内容をそのサービスへ送信します。",
        error_messages={
            "required": "空白だけでなく、質問を入力してください。",
            "max_length": "質問の上限は 2,000 文字です。",
        },
    )
