# Django Web サイト実装例：AI サービス

89〜127 枚目から整理した独立プロジェクトです。mblog ブログとは別に配置してください。

Python 3.13/3.14, Django 5.2 LTS.

仮想環境を作成して requirements.txt をインストールし、以下を実行します。mock テストにキーは不要で、クラウドを呼び出しません。

```sh
python manage.py check
python run_mock_tests.py
python manage.py runserver 127.0.0.1:8000
```

http://127.0.0.1:8000/ai/

Ollama は 97 枚目に従って導入・モデル取得・起動を行います。クラウド利用には自分のキーと利用枠が必要です。.env.example を .env にコピーして設定し、.env は Git に登録しません。本例はローカル用です。公開前に 126 枚目の準備を行ってください。
