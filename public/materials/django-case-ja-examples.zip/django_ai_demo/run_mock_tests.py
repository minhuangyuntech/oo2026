"""Run offline tests with all outbound sockets blocked."""
import os,sys
from unittest.mock import patch
os.environ["OPENAI_API_KEY"] = ""
os.environ["NVIDIA_API_KEY"] = ""
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "mblog.settings")
import django
django.setup()
from django.test.runner import DiscoverRunner
if __name__ == "__main__":
    with patch("socket.socket.connect", side_effect=AssertionError("Network disabled in offline tests")):
        failures = DiscoverRunner(verbosity=2).run_tests(["mysite"])
    sys.exit(bool(failures))
