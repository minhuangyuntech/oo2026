from django.conf import settings
from .common import AIError, chat_messages, checked_text

def build_payload(prompt):
    model = settings.OLLAMA_MODEL
    if model not in settings.OLLAMA_ALLOWED_MODELS:
        raise AIError("config", "OLLAMA_MODEL is not in the local model allowlist.")
    return {
        "model": model, "messages": chat_messages(prompt),
        "stream": False, "options": {"num_predict": 600},
    }

import requests
OLLAMA_URL = "http://127.0.0.1:11434/api/chat"

def send_local_request(payload):
    with requests.Session() as session:
        session.trust_env = False  # Do not use system proxies or netrc credentials.
        response = session.post(
            OLLAMA_URL, json=payload,
            timeout=(3.05, 120), allow_redirects=False,
        )
        response.raise_for_status()
        if response.status_code != 200:
            raise AIError("http", "Ollama returned an unexpected HTTP status.")
        return response.json()

def request_ollama(payload):
    try:
        return send_local_request(payload)
    except requests.exceptions.Timeout:
        raise AIError("timeout", "Ollama Timed out. Check the model or try again later.") from None
    except requests.exceptions.ConnectionError:
        raise AIError("connection", "Cannot connect to Ollama. Check that the local service is running.") from None
    except requests.exceptions.HTTPError:
        raise AIError("http", "Ollama HTTP error. Check the downloaded model and service status.") from None
    except requests.exceptions.JSONDecodeError:
        raise AIError("json", "Ollama The reply is not valid JSON.") from None
    except requests.exceptions.RequestException:
        raise AIError("transport", "Ollama Transport failed. Please try again later.") from None

def extract_content(data):
    if not isinstance(data, dict) or data.get("error"):
        raise AIError("format", "Ollama The reply is malformed or contains an error.")
    message = data.get("message")
    if not isinstance(message, dict) or data.get("done") is not True:
        raise AIError("format", "Ollama No complete message was returned.")
    if data.get("done_reason") == "length":
        raise AIError("incomplete", "The reply reached its length limit. Narrow the question and retry.")
    return checked_text(message.get("content"))

class OllamaProvider:
    def generate(self, prompt):
        payload = build_payload(prompt)
        data = request_ollama(payload)
        return extract_content(data)
