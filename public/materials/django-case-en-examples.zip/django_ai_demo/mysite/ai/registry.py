from typing import Protocol
from .common import AIError
from .ollama import OllamaProvider
from .openai_provider import OpenAIProvider
from .nvidia_provider import NvidiaProvider

class TextProvider(Protocol):
    def generate(self, prompt: str) -> str: ...

PROVIDERS = {
    "ollama": OllamaProvider,
    "openai": OpenAIProvider,
    "nvidia": NvidiaProvider,
}

def get_provider(name) -> TextProvider:
    provider_class = PROVIDERS.get(name)
    if provider_class is None:
        raise AIError("provider", "Unsupported provider.")
    return provider_class()
