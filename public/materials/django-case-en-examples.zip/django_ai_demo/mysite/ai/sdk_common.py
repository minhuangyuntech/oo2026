import openai
from .common import AIError, require_key

def make_client(api_key, name, base_url):
    return openai.OpenAI(
        api_key=require_key(api_key, name), base_url=base_url,
        timeout=120.0, max_retries=0,
    )

def sdk_error(exc):
    if isinstance(exc, openai.APITimeoutError):
        return AIError("timeout", "The cloud service timed out. Try again later.")
    if isinstance(exc, openai.APIConnectionError):
        return AIError("connection", "Cannot reach the cloud service. Check your network.")
    status = getattr(exc, "status_code", None)
    if status in (401, 403):
        return AIError("auth", "Check the API key and account permissions for this model.")
    if status == 429:
        return AIError("rate_limit", "Rate or quota limit reached. Check your plan and retry later.")
    if status == 404:
        return AIError("model", "Model not found. Check its ID and your permissions.")
    return AIError("api", "Cloud API error. Check service status and settings.")

def sdk_call(operation):
    try:
        return operation()
    except openai.OpenAIError as exc:
        raise sdk_error(exc) from None
    except ValueError:
        raise AIError("json", "Cannot parse the cloud reply. Try again later.") from None
