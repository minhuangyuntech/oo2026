class AIError(Exception):
    def __init__(self, code, message):
        self.code = code
        super().__init__(message)

def checked_text(value):
    if not isinstance(value, str) or not value.strip():
        raise AIError("empty", "No displayable text was returned. Change the question or try later.")
    if len(value) > 20000:
        raise AIError("too_long", "The reply is too long. Narrow the question and retry.")
    return value.strip()

SYSTEM_PROMPT = "Answer briefly in English. If uncertain, say so."

def chat_messages(prompt):
    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": prompt},
    ]

def require_key(value, provider_name):
    if not isinstance(value, str) or not value.strip():
        raise AIError("config", f"Missing {provider_name}  server-side API key.")
    return value.strip()
