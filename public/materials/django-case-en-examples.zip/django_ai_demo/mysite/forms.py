from django import forms

PROVIDER_CHOICES = [
    ("ollama", "Ollama(local)"),
    ("openai", "OpenAI API(cloud)"),
    ("nvidia", "NVIDIA hosted API(cloud)"),
]

class PromptForm(forms.Form):
    provider = forms.ChoiceField(label="Provider", choices=PROVIDER_CHOICES)
    prompt = forms.CharField(
        label="Your question", max_length=2000, strip=True,
        widget=forms.Textarea(attrs={"rows": 6, "maxlength": 2000}),
        help_text="Up to 2,000  characters; cloud options send this content to the provider.",
        error_messages={
            "required": "Enter a question containing more than whitespace.",
            "max_length": "The question must not exceed 2,000  characters.",
        },
    )
