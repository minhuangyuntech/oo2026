# Django Website Case Studies: AI services

A standalone project assembled from slides 89–127. Keep it separate from your mblog blog.

Python 3.13/3.14, Django 5.2 LTS.

Create a virtual environment and install requirements.txt, then run these commands. Mock tests need no keys and make no cloud calls.

```sh
python manage.py check
python run_mock_tests.py
python manage.py runserver 127.0.0.1:8000
```

http://127.0.0.1:8000/ai/

Before using Ollama, install it, download the model, and start the service as shown on slide 97. Cloud providers need your own key and quota. Copy .env.example to .env, fill it locally, and never commit .env. This is a local example; complete slide 126 before public deployment.
