with open("lesson_note.txt", "w",
          encoding="utf-8") as file:
    file.write("OOP\n")
    print(file.closed)

print(file.closed)
