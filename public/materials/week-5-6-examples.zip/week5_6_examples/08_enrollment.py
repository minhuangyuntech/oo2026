class Student:
    def __init__(self, name):
        self.name = name

class Course:
    def __init__(self, title):
        self.title = title

class Enrollment:
    def __init__(self, student, course):
        if student is None or course is None:
            raise ValueError("required")
        self.student = student
        self.course = course
        self.score = None

    def set_score(self, score):
        if not 0 <= score <= 100:
            raise ValueError("score range")
        self.score = score

amy = Student("Amy")
bob = Student("Bob")
oop = Course("OOP")
first = Enrollment(amy, oop)
second = Enrollment(bob, oop)
first.set_score(90)
records = [first, second]
print(first.student.name, first.course.title, first.score)
print(second.student.name, second.score)
print(first.course is second.course)
print(len([record for record in records if record.student is amy]))
