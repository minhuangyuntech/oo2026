class Student:
    def __init__(self, name):
        self.name = name

class Enrollment:
    def __init__(self, student):
        self.student = student

    def show(self, printer):
        printer(self.student.name)

amy = Student("Amy")
enrollment = Enrollment(amy)
enrollment.show(print)
