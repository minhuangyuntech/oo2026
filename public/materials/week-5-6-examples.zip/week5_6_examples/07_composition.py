class Order:
    def __init__(self):
        self.lines = [{"qty": 1}]

order = Order()
saved = order.lines[0]
del order
print(saved["qty"])
