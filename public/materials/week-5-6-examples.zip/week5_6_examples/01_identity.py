a = [10, 20]
b = a
c = [10, 20]

print(a == c)
print(a is c)
print(a is b)
