def change(items):
    items.append("pen")

def replace(items):
    items = ["new"]

a = ["book"]
change(a)
replace(a)
print(a)
