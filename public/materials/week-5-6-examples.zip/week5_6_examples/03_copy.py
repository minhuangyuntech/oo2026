from copy import deepcopy

a = {"items": ["book"]}
b = a.copy()
c = deepcopy(a)

a["items"].append("pen")
print(b["items"])
print(c["items"])
print(a is b, a["items"] is b["items"])
