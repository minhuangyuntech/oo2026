# Django website starter: product catalog

Companion to `Django_Website_Setup_and_Project_Files_EN-v2.pptx`. Python 3.12 and Django 5.2.

## Run the complete example (Windows PowerShell)

Run these commands in this directory, which contains manage.py:

```powershell
python -m venv .venv
.\.venv\Scripts\python -m pip install -r requirements.txt
.\.venv\Scripts\python manage.py migrate
.\.venv\Scripts\python manage.py runserver
```

Open http://127.0.0.1:8000/products/ in your browser. Press Ctrl+C to stop the server.

This is a complete project. Do not run startproject or startapp again. The migration file is included, so the first run only needs migrate.
The ZIP excludes the database, virtual environment, shared credentials and user data. The list starts empty. Add your first product at `/products/new/`.

macOS / Linux: create the environment with `python3 -m venv .venv`, then use `.venv/bin/python` for the commands above.

## Admin and tests

```powershell
.\.venv\Scripts\python manage.py createsuperuser
.\.venv\Scripts\python manage.py test catalog
.\.venv\Scripts\python manage.py check
```

Admin URL: `http://127.0.0.1:8000/admin/`. Create your own local administrator password.

## Routes

| URL | Purpose |
|---|---|
| `/products/hello/` | Minimal text response |
| `/products/` | Product list |
| `/products/new/` | Product creation form |
| `/products/1/` | Product with primary key 1, or 404 if absent |
| `/admin/` | Django administration |

The root path `/` is undefined and returns 404.

## File index

An asterisk (*) means the generated file was subsequently edited.

| Location | Origin | Purpose |
|---|---|---|
| `manage.py` | startproject | Run management commands and select Django settings |
| `config/__init__.py` | startproject | Project package marker |
| `config/settings.py` | startproject* | Apps, database, templates, middleware, language and time zone |
| `config/urls.py` | startproject* | Root URL configuration for catalog and admin |
| `config/wsgi.py` | startproject | WSGI server entry point |
| `config/asgi.py` | startproject | ASGI server entry point |
| `catalog/__init__.py` | startapp | App package marker |
| `catalog/apps.py` | startapp | CatalogConfig configuration class |
| `catalog/models.py` | startapp* | Product fields, in_stock property and string representation |
| `catalog/views.py` | startapp* | Hello response, product list, detail and creation views |
| `catalog/admin.py` | startapp* | Register Product, display columns and enable search |
| `catalog/tests.py` | startapp* | Eight behavioral tests |
| `catalog/migrations/__init__.py` | startapp | Migration package marker |
| `catalog/migrations/0001_initial.py` | makemigrations | Instructions to create the Product table |
| `catalog/urls.py` | Added manually | App routes and namespace |
| `catalog/forms.py` | Added manually | ProductForm fields, labels and validation |
| `catalog/templates/catalog/base.html` | Added manually | Shared HTML structure, CSS, navigation and footer |
| `catalog/templates/catalog/product_list.html` | Added manually | Product list and stock availability |
| `catalog/templates/catalog/product_detail.html` | Added manually | Details of one product |
| `catalog/templates/catalog/product_form.html` | Added manually | POST form, CSRF token and validation messages |
| `catalog/static/catalog/site.css` | Added manually | Page layout, fonts and colors |
| `requirements.txt` | Added manually | Django version range |
| `.gitignore` | Added manually | Exclude local environments, caches and databases |
| `README.md` | Added manually | Run instructions and this file index |

Running the project creates `.venv/`, `__pycache__/` and `db.sqlite3`. They are not included in the ZIP.

## Scope

This is a local classroom example. `DEBUG=True` and its fixed classroom SECRET_KEY are unsuitable for production.
The product creation page does not require login. Add authentication and authorization before public deployment.
ModelForm validates prices. Direct ORM writes still need appropriate validation and, where required, database constraints.
The example has no uploads, .env loader or production deployment configuration.
The interface language is English. The time zone remains Asia/Taipei and prices remain in NT$, matching the source example.
