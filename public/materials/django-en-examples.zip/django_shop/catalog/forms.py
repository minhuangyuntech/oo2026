from django import forms
from .models import Product


class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ["name", "price", "stock"]
        labels = {"name": "Product name", "price": "Price", "stock": "Stock"}
