# 成績簿のテスト例（Python プログラムのテスト：原理と方法）

成績簿クラス `GradeBook` を使って unittest と pytest を練習します。本体は標準ライブラリのみを使い、テストには pytest が必要です。

## 環境の準備

```bash
python -m venv .venv
# Windows PowerShell
.venv\Scripts\Activate.ps1
# macOS / Linux
source .venv/bin/activate

pip install -r requirements.txt
```

## 実行

次のコマンドはすべてこのフォルダで実行します。

```bash
python -m demo.mini_runner                          # ミニテスト実行器：1 passed, 1 failed, 1 error
python -m unittest discover -s tests_unittest -v    # unittest 版：6 個のテスト
pytest -v                                           # pytest 版：21 個のテスト
pytest tests_unittest                               # pytest は unittest のテストも実行できる
```

## ファイル案内

| パス | 内容 |
|---|---|
| `gradebook.py` | `GradeBook` クラスと `letter_grade()` |
| `demo/mini_runner.py` | ミニテスト実行器：収集・実行・報告 |
| `demo/sample_tests.py` | ミニ実行器用のテスト（わざと 1 つ失敗、1 つエラー） |
| `tests_unittest/` | unittest の書き方：`TestCase`、`setUp`、`assertRaises`、`subTest` |
| `tests/conftest.py` | pytest の共通 fixture `book` |
| `tests/test_gradebook.py` | pytest の書き方：fixture、`pytest.raises`、`pytest.approx`、`tmp_path` |
| `tests/test_letter_grade.py` | `@pytest.mark.parametrize` で境界をすべてテスト |
| `exercises/boundaries/` | 授業の演習：境界値で `grading.py` のバグを見つける |
| `pyproject.toml` | pytest の設定：`pythonpath`、`testpaths` |

## 授業の演習

```bash
pytest exercises/boundaries -v   # 最初はすべて通るが、grading.py にはバグが隠れている
```

`test_grading.py` に境界値のテストを追加し、レッドになったら `grading.py` を修正します。テストを通すために仕様を変えたり、テストを消したりしてはいけません。
