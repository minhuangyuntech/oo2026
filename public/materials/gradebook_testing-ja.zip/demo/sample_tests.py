"""ミニ実行器用のテスト：1 つは成功、1 つは失敗、1 つはエラー。"""

from gradebook import GradeBook


def test_average_of_two_scores():
    book = GradeBook()                 # Arrange 準備
    book.add("A001", 80)
    book.add("A002", 90)
    result = book.average()            # Act 実行
    assert result == 85                # Assert 検証


def test_passed_list():
    book = GradeBook()
    book.add("A001", 59)
    book.add("A002", 60)
    assert book.passed() == ["A001", "A002"], "59 点も合格のはず"


def test_score_of_unknown_student():
    book = GradeBook()
    assert book.score_of("Z999") == 0
