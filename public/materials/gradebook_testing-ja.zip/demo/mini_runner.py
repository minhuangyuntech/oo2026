"""ミニテスト実行器：テストフレームワークの 3 つの仕事（収集・実行・報告）を示す。

プロジェクトのフォルダで実行：python -m demo.mini_runner
"""

import inspect

from demo import sample_tests


def collect(module):
    """収集：名前が test_ で始まる関数を見つける。"""
    return [(name, func) for name, func in inspect.getmembers(module, inspect.isfunction)
            if name.startswith("test_")]


def run(tests):
    """実行と報告：テストは 1 つずつ実行し、失敗しても次のテストに進む。"""
    results = {"passed": 0, "failed": 0, "error": 0}
    for name, func in tests:
        try:
            func()
        except AssertionError as exc:
            results["failed"] += 1
            print(f"FAIL  {name}：{exc}")
        except Exception as exc:
            results["error"] += 1
            print(f"ERROR {name}：{type(exc).__name__} {exc}")
        else:
            results["passed"] += 1
            print(f"PASS  {name}")
    print(", ".join(f"{count} {kind}" for kind, count in results.items()))


if __name__ == "__main__":
    run(collect(sample_tests))
