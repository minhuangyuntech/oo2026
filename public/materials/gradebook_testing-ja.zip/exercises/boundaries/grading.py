"""演習：この letter_grade には境界のバグが隠れています。

仕様：90 以上 A、80 以上 B、70 以上 C、60 以上 D、それ以外は F。
0〜100 以外の点数では ValueError を送出する。
"""


def letter_grade(score: int) -> str:
    if not 0 <= score <= 100:
        raise ValueError(f"点数は 0 から 100 の範囲で指定してください：{score}")
    if score >= 90:
        return "A"
    if score > 80:
        return "B"
    if score >= 70:
        return "C"
    if score >= 60:
        return "D"
    return "F"
