"""演習：parametrize で境界値のテストを追加し、grading.py のバグを見つける。

1. pytest exercises/boundaries -v を実行する。今のテストはすべて通る。
2. test_boundaries のデータを補う：各評価の上限と下限、そして -1 と 101。
3. レッドになったら grading.py を修正し、すべてのテストを通す。
"""

import pytest

from grading import letter_grade


def test_typical_scores() -> None:
    assert letter_grade(95) == "A"
    assert letter_grade(85) == "B"
    assert letter_grade(75) == "C"
    assert letter_grade(65) == "D"
    assert letter_grade(30) == "F"


@pytest.mark.parametrize(
    "score, expected",
    [
        (100, "A"),
        # TODO：ほかの境界値を追加する
    ],
)
def test_boundaries(score: int, expected: str) -> None:
    assert letter_grade(score) == expected
