"""tests/ に置いた共通の fixture。どのテストファイルからもそのまま使えます。"""

import pytest

from gradebook import GradeBook


@pytest.fixture
def book() -> GradeBook:
    """学生 2 人の成績簿。テストごとに新しいものを受け取ります。"""
    gradebook = GradeBook()
    gradebook.add("A001", 80)
    gradebook.add("A002", 90)
    return gradebook
