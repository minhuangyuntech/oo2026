"""parametrize で評価の境界をすべてテストする。"""

import pytest

from gradebook import letter_grade


@pytest.mark.parametrize(
    "score, expected",
    [(100, "A"), (90, "A"), (89, "B"), (80, "B"), (79, "C"),
     (70, "C"), (69, "D"), (60, "D"), (59, "F"), (0, "F")],
)
def test_letter_grade(score: int, expected: str) -> None:
    assert letter_grade(score) == expected


@pytest.mark.parametrize("score", [-1, 101])
def test_invalid_score(score: int) -> None:
    with pytest.raises(ValueError):
        letter_grade(score)
