"""pytest で GradeBook をテストする。プロジェクトのフォルダで実行：pytest -v"""

from pathlib import Path

import pytest

from gradebook import GradeBook


def test_average(book: GradeBook) -> None:
    assert book.average() == 85


def test_add_increases_count(book: GradeBook) -> None:
    book.add("A003", 70)
    assert len(book) == 3


def test_each_test_gets_a_new_book(book: GradeBook) -> None:
    assert len(book) == 2  # 前のテストで追加した A003 は残らない


def test_passed_is_sorted(book: GradeBook) -> None:
    book.add("A000", 59)
    assert book.passed() == ["A001", "A002"]


def test_average_of_three(book: GradeBook) -> None:
    book.add("A003", 86)
    assert book.average() == pytest.approx(85.33, abs=0.01)


def test_empty_book_has_no_average() -> None:
    with pytest.raises(ValueError, match="点数がありません"):
        GradeBook().average()


@pytest.mark.parametrize("score", [-1, 101])
def test_score_out_of_range(book: GradeBook, score: int) -> None:
    with pytest.raises(ValueError, match="0 から 100"):
        book.add("A003", score)


def test_csv_round_trip(book: GradeBook, tmp_path: Path) -> None:
    path = tmp_path / "scores.csv"
    book.save_csv(path)
    loaded = GradeBook.load_csv(path)
    assert loaded.score_of("A002") == 90
    assert len(loaded) == 2
