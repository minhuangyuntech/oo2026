"""標準ライブラリの unittest で GradeBook をテストする。

プロジェクトのフォルダで実行：python -m unittest discover -s tests_unittest -v
"""

import unittest

from gradebook import GradeBook, letter_grade


class TestGradeBook(unittest.TestCase):
    def setUp(self) -> None:
        # テストメソッドの実行前に毎回作り直すので、テスト同士は影響しない
        self.book = GradeBook()
        self.book.add("A001", 80)
        self.book.add("A002", 90)

    def test_average(self) -> None:
        self.assertEqual(self.book.average(), 85)

    def test_add_increases_count(self) -> None:
        self.book.add("A003", 70)
        self.assertEqual(len(self.book), 3)

    def test_passed_is_sorted(self) -> None:
        self.book.add("A000", 59)
        self.assertEqual(self.book.passed(), ["A001", "A002"])

    def test_score_out_of_range(self) -> None:
        with self.assertRaises(ValueError):
            self.book.add("A003", 101)

    def test_duplicate_student(self) -> None:
        with self.assertRaisesRegex(ValueError, "すでに点数があります"):
            self.book.add("A001", 70)


class TestLetterGrade(unittest.TestCase):
    def test_boundaries(self) -> None:
        cases = [(100, "A"), (90, "A"), (89, "B"), (80, "B"), (60, "D"), (59, "F"), (0, "F")]
        for score, expected in cases:
            with self.subTest(score=score):
                self.assertEqual(letter_grade(score), expected)


if __name__ == "__main__":
    unittest.main()
