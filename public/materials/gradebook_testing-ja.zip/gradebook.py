"""成績簿：Python テスト教材のサンプルクラス。

GradeBook は学生ごとに 1 つの点数を保持し、点数の検証、平均の計算、
合格者の一覧、CSV への保存と読み込みを担当します。
"""

import csv
from pathlib import Path

PASSING_SCORE = 60


def letter_grade(score: int) -> str:
    """0〜100 の点数を評価に変換する：90 以上 A、80 以上 B、70 以上 C、60 以上 D、それ以外は F。"""
    if not 0 <= score <= 100:
        raise ValueError(f"点数は 0 から 100 の範囲で指定してください：{score}")
    if score >= 90:
        return "A"
    if score >= 80:
        return "B"
    if score >= 70:
        return "C"
    if score >= 60:
        return "D"
    return "F"


class GradeBook:
    def __init__(self) -> None:
        self._scores: dict[str, int] = {}

    def add(self, student_id: str, score: int) -> None:
        if not student_id:
            raise ValueError("学籍番号を空にすることはできません")
        if not 0 <= score <= 100:
            raise ValueError(f"点数は 0 から 100 の範囲で指定してください：{score}")
        if student_id in self._scores:
            raise ValueError(f"{student_id} にはすでに点数があります")
        self._scores[student_id] = score

    def score_of(self, student_id: str) -> int:
        return self._scores[student_id]

    def __len__(self) -> int:
        return len(self._scores)

    def average(self) -> float:
        if not self._scores:
            raise ValueError("成績簿に点数がありません")
        return sum(self._scores.values()) / len(self._scores)

    def passed(self) -> list[str]:
        """合格（60 点以上）の学籍番号を学籍番号順で返す。"""
        return sorted(sid for sid, score in self._scores.items() if score >= PASSING_SCORE)

    def save_csv(self, path: Path) -> None:
        with path.open("w", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)
            writer.writerow(["student_id", "score"])
            for sid, score in sorted(self._scores.items()):
                writer.writerow([sid, score])

    @classmethod
    def load_csv(cls, path: Path) -> "GradeBook":
        book = cls()
        with path.open(newline="", encoding="utf-8") as file:
            for row in csv.DictReader(file):
                book.add(row["student_id"], int(row["score"]))
        return book
