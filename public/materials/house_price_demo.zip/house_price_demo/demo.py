"""輸入人民幣單價，查詢線上匯率，再顯示新臺幣每坪價格。"""

import argparse
from decimal import Decimal, InvalidOperation
import sys

from house_price import QuoteError, fetch_cny_sell_quote, twd_per_ping


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("price", nargs="?", help="人民幣元／平方公尺，例如 30000")
    args = parser.parse_args()
    raw_price = args.price
    if raw_price is None:
        raw_price = input("房屋單價（人民幣元／平方公尺）：")
    try:
        price = Decimal(raw_price.strip())
        if not price.is_finite() or price <= 0:
            raise ValueError
    except (ValueError, InvalidOperation):
        print("請輸入大於零的房屋單價，例如 30000 或 28500.50。", file=sys.stderr)
        return 2
    try:
        quote = fetch_cny_sell_quote()
    except QuoteError as error:
        print(error, file=sys.stderr)
        return 1
    result = twd_per_ping(price, quote.twd_per_cny)
    print(f"房屋單價　人民幣 {price:,.2f} 元／平方公尺")
    print(f"即期賣出　1 人民幣 = {quote.twd_per_cny:f} 新臺幣")
    print(f"臺銀掛牌　{quote.published_at:%Y-%m-%d %H:%M}（臺灣時間）")
    print(f"換算結果　新臺幣 {result:,.0f} 元／坪（{result / 10000:,.2f} 萬元／坪）")
    print("資料來源：臺灣銀行牌告匯率 https://rate.bot.com.tw/xrt")
    print("資料整理：匯率好工具 RateWise（https://app.haotool.org/ratewise/）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
