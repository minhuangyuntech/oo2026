# 房價單價換算

輸入中國大陸房屋的人民幣每平方公尺單價，程式會上網讀取臺灣銀行的即期賣出牌價，換算成新臺幣每坪及每坪萬元。即期賣出對應買方拿新臺幣向銀行買人民幣的估算情境。

在本目錄使用 Python 3.9 或更新版本執行以下指令。省略金額時，程式會提示輸入。

```shell
python demo.py 30000
```

每次執行都會向 RateWise 的公開資料端點取得目前發布的臺銀報價。輸出列出臺銀掛牌時間，資料的同步可能有延遲。查詢失敗時會顯示錯誤並結束。

## 從另一個程式匯入

```python
from decimal import Decimal
from house_price import fetch_cny_sell_quote, twd_per_ping

quote = fetch_cny_sell_quote()
price = twd_per_ping(Decimal("30000"), quote.twd_per_cny)
print(f"{price / 10000:.2f} 萬元／坪")
```

計算時，先將每平方公尺人民幣單價乘以每元人民幣需付的新臺幣，再除以 0.3025。因為一平方公尺等於 0.3025 坪，這樣就得到每一坪的新臺幣價格。[臺北市政府地政局面積換算](https://w3.land.gov.taipei/calareacnvr/)

`house_price/rates.py` 讀取臺銀報價，`house_price/__init__.py` 提供換算函式，`demo.py` 處理輸入與顯示。要在其他專案中匯入，可在虛擬環境中從本目錄執行 `python -m pip install -e .`。

資料來源為[臺灣銀行牌告匯率](https://rate.bot.com.tw/xrt)。資料整理：匯率好工具 RateWise（https://app.haotool.org/ratewise/）。[公開資料端點說明](https://app.haotool.org/ratewise/open-data/)


## 三語教材與發布準備

English: README-en.md · 日本語: README-ja.md

完整教材：https://minhuangyuntech.github.io/oo2026/pypi/

範例尚未上傳 PyPI 或 TestPyPI。發布前，請在 pyproject.toml 將專案名稱改成自己的未使用名稱（例如 oo2026-house-price-yourid，替換 yourid），並選定授權、加入 LICENSE。import 名稱仍為 house_price。
