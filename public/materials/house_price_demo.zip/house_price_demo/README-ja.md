# オンライン為替を使う住宅価格換算

Python 3.9 以降で実行できます。外部の実行時依存パッケージはありません。
ZIP を展開し、`house_price_demo` でターミナルを開きます。

```shell
python demo.py 30000
```

入力は 1 平方メートルあたりの人民元単価です。CLI のラベルは中国語で、
入力単価、台湾銀行の人民元即期売りレート（1 人民元あたりの台湾ドル）、
台湾時間の公示時刻、1 坪あたりの台湾ドル単価を表示します。
1 坪は約 3.3058 m² です。式：`人民元/m² × 台湾ドル/人民元 ÷ 0.3025`。

RateWise／HaoRate が同期した台湾銀行の最新取得可能なスナップショットを
使用し、公示時刻と出典を残します。銀行の直接 API やリアルタイムの取引価格
ではありません。同期に遅延があり得ます。入力不正や取得失敗時はエラーを返し、
仮の為替値では計算しません。

## モジュールとして使う

```python
from decimal import Decimal
from house_price import fetch_cny_sell_quote, twd_per_ping

quote = fetch_cny_sell_quote()
result = twd_per_ping(Decimal("30000"), quote.twd_per_cny)
print(f"1 坪あたり {result:,.0f} 台湾ドル")
print(quote.published_at)
```

通信なしで計算を検証する例：

```python
from decimal import Decimal
from house_price import twd_per_ping
assert twd_per_ping(Decimal("30250"), Decimal("4.5")) == Decimal("450000")
```

仮想環境を作成してから `python -m pip install -e .` で開発用に導入できます。
`house_price/__init__.py` が公開入口、`rates.py` が JSON の取得と検証、
`demo.py` が入力と表示を担当します。

## 自分の配布物を準備する

この例は PyPI／TestPyPI に公開していません。`pyproject.toml` の名前を
未使用の名前に変更します。例：`oo2026-house-price-yourid` の `yourid` を
自分の識別子に置き換えます。import 名は `house_price` のままです。
公開前にライセンスを選び、LICENSE を追加します。token、仮想環境、
個人データを含めないでください。`python -m build --outdir dist-0.1.0` と
`python -m twine check dist-0.1.0/*` でビルド・確認後、教材の TestPyPI 手順へ進みます。
オンライン教材とスライド：https://minhuangyuntech.github.io/oo2026/ja/pypi/

出典：
- 台湾銀行：https://rate.bot.com.tw/xrt
- RateWise／HaoRate：https://app.haotool.org/ratewise/open-data/
- 面積換算：https://w3.land.gov.taipei/calareacnvr/
