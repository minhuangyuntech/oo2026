"""讀取 RateWise 同步的臺灣銀行人民幣即期賣出報價。"""

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
import hashlib
import json
from urllib.request import urlopen


DATA_ROOT = "https://raw.githubusercontent.com/haotool/app/data/public/rates/v3/"
TAIPEI = timezone(timedelta(hours=8))


class QuoteError(Exception):
    """無法取得可用的人民幣報價。"""


@dataclass(frozen=True)
class Quote:
    twd_per_cny: Decimal
    published_at: datetime


def _download(path, expected_hash=None):
    with urlopen(DATA_ROOT + path, timeout=10) as response:
        content = response.read()
    if expected_hash and hashlib.sha256(content).hexdigest() != expected_hash:
        raise QuoteError("匯率資料的檢查碼不符，請稍後重試。")
    return json.loads(content)


def fetch_cny_sell_quote():
    """回傳以新臺幣購買 1 元人民幣的即期牌告價格與掛牌時間。"""
    try:
        pointer = _download("current.json")
        manifest_ref = pointer["manifest"]
        manifest = _download(manifest_ref["path"], manifest_ref["sha256"])
        bank = next(p for p in manifest["providers"] if p["providerId"] == "bot")
        if bank["checkStatus"] != "ok":
            raise QuoteError("來源目前無法確認臺銀報價，請稍後重試。")
        ref = bank["snapshot"]
        snapshot = _download(ref["path"], ref["sha256"])

        for row in snapshot["quotes"]:
            if (row["fromCurrency"], row["toCurrency"], row["status"]) != (
                "TWD", "CNY", "available"
            ):
                continue
            original = row["sourceQuote"]
            if original["originalSellField"] != "spot.sell":
                continue
            if (original["subjectCurrency"], original["priceCurrency"]) != ("CNY", "TWD"):
                continue
            price = Decimal(original["providerSellPrice"])
            units = Decimal(original["unitAmount"])
            if not all(value.is_finite() and value > 0 for value in (price, units)):
                raise QuoteError("來源傳回的賣出價或面額無效。")
            stamp = datetime.fromisoformat(original["sourcePublishedAt"].replace("Z", "+00:00"))
            if stamp.tzinfo is None:
                raise QuoteError("來源的掛牌時間缺少時區。")
            return Quote(price / units, stamp.astimezone(TAIPEI))
        raise QuoteError("報價表中找不到可用的人民幣即期賣出價。")
    except (OSError, ValueError, KeyError, TypeError, StopIteration, InvalidOperation) as error:
        raise QuoteError(f"線上查價失敗，請確認網路後重試（{error}）。") from error
