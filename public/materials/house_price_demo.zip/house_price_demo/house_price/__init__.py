"""跨單位房價換算。"""

from decimal import Decimal

from .rates import QuoteError, fetch_cny_sell_quote


PING_PER_SQM = Decimal("0.3025")


def twd_per_ping(cny_per_sqm, twd_per_cny):
    """將人民幣元／平方公尺換算為新臺幣元／坪。"""
    return cny_per_sqm * twd_per_cny / PING_PER_SQM
