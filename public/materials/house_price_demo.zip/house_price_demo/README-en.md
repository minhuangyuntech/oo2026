# House-price conversion with online exchange rates

Requires Python 3.9 or later; no third-party runtime dependencies.
Extract the ZIP and open a terminal in `house_price_demo`.

```shell
python demo.py 30000
```

The input is CNY per square metre. The CLI prints Chinese labels for the input,
the bank's CNY spot selling rate (TWD per CNY), the quote timestamp in Taiwan,
and the converted price in TWD per ping. A ping is approximately 3.3058 m².
Formula: `CNY/m² × TWD/CNY ÷ 0.3025 = TWD/ping`.

The program fetches the latest available Bank of Taiwan snapshot mirrored by
RateWise / HaoRate, preserving source time and attribution. This is not a direct
bank API or a live trading price. Mirror delays are possible. Invalid input and
lookup failures produce an error, not a fabricated fallback rate.

## Import the module

```python
from decimal import Decimal
from house_price import fetch_cny_sell_quote, twd_per_ping

quote = fetch_cny_sell_quote()
result = twd_per_ping(Decimal("30000"), quote.twd_per_cny)
print(f"TWD {result:,.0f} per ping")
print(quote.published_at)
```

For a deterministic offline check:

```python
from decimal import Decimal
from house_price import twd_per_ping
assert twd_per_ping(Decimal("30250"), Decimal("4.5")) == Decimal("450000")
```

Create a virtual environment before an editable install (`python -m pip install -e .`).
`house_price/__init__.py` exposes conversion and rate lookup, `rates.py` retrieves
and validates JSON, and `demo.py` handles input and output.

## Prepare your own release

This example has not been published to PyPI or TestPyPI. Replace the project name
in `pyproject.toml` with an available name such as `oo2026-house-price-yourid`,
where `yourid` is your own identifier. The import name remains `house_price`.
Choose a license and add its LICENSE file before publishing your own work.
Do not include tokens, virtual environments, or private files in a release.
Build and check with `python -m build --outdir dist-0.1.0` and
`python -m twine check dist-0.1.0/*`, then follow the course's TestPyPI workflow.
The complete tutorial and localized slides are at:
https://minhuangyuntech.github.io/oo2026/en/pypi/

Sources:
- Bank of Taiwan: https://rate.bot.com.tw/xrt
- RateWise / HaoRate data documentation: https://app.haotool.org/ratewise/open-data/
- Area conversion: https://w3.land.gov.taipei/calareacnvr/
