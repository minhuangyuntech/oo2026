# 第 8 週：多型、抽象化與介面

Python 3.12+。解壓縮後，在 `week8_examples` 資料夾開啟終端機：

```sh
python -m pip install -r requirements.txt
python demo_game.py --lang zh
```

Enter 開始；方向鍵或 WASD 移動；Space 射擊；P 暫停／繼續；暫停時 N 前進一影格；Tab 切換物件標籤；C 切換現有 StrategyEnemy 的直線／擺動策略；R 重新開始；Esc 結束。以 `--lang en` 或 `--lang ja` 啟動其他語言。

初始場景的 E01 是 Enemy，E02 是 WeavingEnemy，E03 是 StrategyEnemy。開始後按 P 暫停，再用 N 觀察位置變化；按 C 更換 E03 的 motion，物件身分與生命值保留。新產生的 StrategyEnemy 預設使用新的 Weave 實體。

| 檔案 | 內容 |
| --- | --- |
| actors.py、game.py、settings.py、view.py、i18n.py | 原射擊遊戲的模型、協調、繪圖與語言資源 |
| contracts.py | 抽象類別、Protocol、不同物件共用 tick_all |
| motion.py | Motion、Straight、Weave、Freeze |
| extension.py | WeavingEnemy 覆寫更新；StrategyEnemy 委派速度計算 |
| demo_game.py | 第 8 週遊戲入口，沿用原遊戲並替換生成規則 |
| typing_error.py | 刻意不符合 Updatable 的 BadClock |
| tests/test_week8.py | 介面、參照、移動、暫停與單步的 7 項測試 |

```sh
python contracts.py
python -m mypy --strict contracts.py motion.py
python -m mypy --strict typing_error.py
python -m unittest discover -s tests -v
```

`contracts.py` 印出 `40.0 0.5` 與 `True`。第三個命令應回報 1 項 assignment 型別錯誤，因為 BadClock.update 缺少 dt；直接執行 `typing_error.py` 則會發生 TypeError。它是用來比較靜態檢查與執行時檢查的錯誤範例。其餘型別檢查與 7 項測試應通過。

投影片程式碼是節錄，完整匯入與上下文請看上述檔案。`dt` 的單位為秒，策略回傳像素／秒的速度，再由 Actor.update 乘上 dt。

畫面沿用原遊戲的系統字型；Windows／macOS 使用現有中文字型，Linux 顯示中日文需安裝 Noto CJK 字型。按鍵 Tab 是下載版的標籤開關，線上版則使用 L。

線上原版：[射擊遊戲](https://minhuangyuntech.github.io/oo2026/pygame/play/)。第 8 週新增的敵人與策略收錄於本下載包。三語離線教材見 `docs/lesson-zh.html`、`lesson-en.html`、`lesson-ja.html`。
