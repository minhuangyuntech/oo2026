# Week 8: polymorphism, abstraction, and interfaces

Python 3.12+. Extract the ZIP, open a terminal in `week8_examples`, and run:

```sh
python -m pip install -r requirements.txt
python demo_game.py --lang en
```

Enter starts; arrows or WASD move; Space fires; P pauses/resumes; N advances one frame while paused; Tab toggles object labels; C switches existing StrategyEnemy objects between straight and weaving motion; R restarts; Esc exits. Use `--lang zh` or `--lang ja` for another language.

The initial E01 is an Enemy, E02 is a WeavingEnemy, and E03 is a StrategyEnemy. Start, press P, and use N to inspect position changes. Press C to replace E03's motion while keeping its identity and HP. Newly spawned StrategyEnemy objects start with their own Weave instance.

| File | Contents |
| --- | --- |
| actors.py, game.py, settings.py, view.py, i18n.py | Original shooter model, coordination, drawing, and translations |
| contracts.py | ABCs, Protocols, and tick_all for unrelated objects |
| motion.py | Motion, Straight, Weave, Freeze |
| extension.py | WeavingEnemy overrides update; StrategyEnemy delegates velocity |
| demo_game.py | Week 8 entry point with replacement spawn rules |
| typing_error.py | BadClock deliberately violates Updatable |
| tests/test_week8.py | Seven tests for contracts, identity, movement, pause, and stepping |

```sh
python contracts.py
python -m mypy --strict contracts.py motion.py
python -m mypy --strict typing_error.py
python -m unittest discover -s tests -v
```

`contracts.py` prints `40.0 0.5` and `True`. The third command should report one assignment error because BadClock.update lacks dt. Running `typing_error.py` directly raises TypeError. This deliberate error compares static checking with runtime behavior. The other type check and all seven tests should pass.

Slide code is excerpted; the files contain the complete imports and context. `dt` is in seconds. Strategies return velocity in pixels per second, and Actor.update multiplies it by dt.

The game uses the original system-font selection. Windows/macOS use their installed CJK fonts; Linux needs Noto CJK fonts to display Chinese/Japanese. The desktop label key is Tab; the browser uses L.

Original [browser shooter](https://minhuangyuntech.github.io/oo2026/en/pygame/play/). The new Week 8 enemies and strategies are in this download. Offline lessons: `docs/lesson-zh.html`, `lesson-en.html`, and `lesson-ja.html`.
