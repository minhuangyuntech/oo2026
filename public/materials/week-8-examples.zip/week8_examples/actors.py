"""三種畫面角色共用 Actor；各自保存狀態、處理自己的行為。"""

import pygame

from settings import (
    BULLET_SPEED, CORAL, MINT, PLAY_AREA, PLAYER_SPEED,
    PURPLE, SHOT_INTERVAL, WHITE, YELLOW,
)


class Actor(pygame.sprite.Sprite):
    """共同父類別：圖片、位置、碰撞範圍、名稱與移動。"""

    def __init__(self, name, position, size):
        super().__init__()
        self.name = name
        self.image = pygame.Surface(size, pygame.SRCALPHA)
        self.pos = pygame.Vector2(position)
        self.rect = self.image.get_rect(center=position)
        self.velocity = pygame.Vector2()

    def update(self, dt):
        self.pos += self.velocity * dt
        self.rect.center = (round(self.pos.x), round(self.pos.y))


class Player(Actor):
    """玩家知道如何移動、發射，以及扣除自己的生命。"""

    def __init__(self, position):
        super().__init__("player", position, (44, 48))
        self.hp = 3
        self.cooldown = 0.0
        self.invulnerable = 0.0
        pygame.draw.polygon(self.image, MINT, [(22, 0), (43, 42), (22, 33), (1, 42)])
        pygame.draw.polygon(self.image, "#153b45", [(22, 12), (29, 31), (15, 31)])
        pygame.draw.line(self.image, WHITE, (22, 4), (22, 12), 2)

    def set_direction(self, x, y):
        direction = pygame.Vector2(x, y)
        # 斜向移動也維持相同速度。
        if direction.length_squared() > 1:
            direction = direction.normalize()
        self.velocity = direction * PLAYER_SPEED

    def update(self, dt):
        super().update(dt)
        # 保留浮點座標，避免不同影格率造成四捨五入誤差。
        self.pos.x = max(PLAY_AREA.left + self.rect.width / 2, min(self.pos.x, PLAY_AREA.right - self.rect.width / 2))
        self.pos.y = max(PLAY_AREA.top + self.rect.height / 2, min(self.pos.y, PLAY_AREA.bottom - self.rect.height / 2))
        self.rect.center = (round(self.pos.x), round(self.pos.y))
        self.cooldown = max(0.0, self.cooldown - dt)
        self.invulnerable = max(0.0, self.invulnerable - dt)

    def shoot(self, name):
        if self.cooldown > 0 or self.hp == 0:
            return None
        self.cooldown = SHOT_INTERVAL
        # 建立物件：每次成功發射，都回傳一個新的 Bullet。
        return Bullet(name, self)

    def take_damage(self):
        if self.invulnerable > 0 or self.hp == 0:
            return False
        self.hp -= 1
        self.invulnerable = 0.8
        return True


class Enemy(Actor):
    """每個敵人有自己的速度、生命值；不必每種顏色都新增類別。"""

    def __init__(self, name, position, speed=80, hp=1):
        super().__init__(name, position, (44, 40))
        self.velocity.y = speed
        self.hp = hp
        self.max_hp = hp
        color = CORAL if hp == 1 else PURPLE
        pygame.draw.polygon(self.image, color, [(3, 3), (40, 3), (43, 25), (22, 39), (0, 25)])
        pygame.draw.rect(self.image, "#252a43", (8, 12, 28, 10), border_radius=4)
        pygame.draw.circle(self.image, WHITE, (15, 17), 3)
        pygame.draw.circle(self.image, WHITE, (29, 17), 3)

    def take_hit(self, damage):
        self.hp = max(0, self.hp - damage)
        if self.hp == 0:
            self.kill()
            return True
        return False

    # Enemy 沿用 Actor.update()：按自己的 velocity 往下移動。


class Bullet(Actor):
    """子彈保留發射者的參考；owner 與玩家是同一個物件。"""

    def __init__(self, name, owner):
        position = (owner.rect.centerx, owner.rect.top - 9)
        super().__init__(name, position, (8, 20))
        self.owner = owner
        self.damage = 1
        self.velocity.y = -BULLET_SPEED
        pygame.draw.rect(self.image, YELLOW, (0, 0, 8, 20), border_radius=4)
        pygame.draw.rect(self.image, WHITE, (3, 2, 2, 10), border_radius=1)

    def update(self, dt):
        super().update(dt)
        if self.rect.bottom < PLAY_AREA.top:
            # kill() 移除所有 Group 中的參考，不等於立刻銷毀 Python 物件。
            self.kill()
