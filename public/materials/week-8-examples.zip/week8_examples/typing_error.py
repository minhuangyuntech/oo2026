"""Intentional error: mypy rejects BadClock because update lacks dt."""
from contracts import BadClock, Updatable

bad: Updatable = BadClock()

if __name__ == '__main__':
    bad.update(0.5)  # Raises TypeError at runtime too.
