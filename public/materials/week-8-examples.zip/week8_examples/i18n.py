"""UI translations only; class identifiers and game rules are shared."""

import re

TEXT = {
    "星際物件實驗室": ("OOP Star Lab", "オブジェクト実験室"),
    "一個類別，多個物件；每個物件，各自運作。": ("One class. Independent objects.", "一つのクラス、独立した実体。"),
    "已暫停  ·  P 繼續 / N 前進一影格": ("Paused · P resume / N one frame", "一時停止 · P 再開 / N 1 フレーム"),
    "讓物件一起動起來": ("Objects in motion", "オブジェクトを動かそう"),
    "玩家移動、子彈前進、敵人下降。": ("Move, shoot, and watch the objects interact.", "自機が動き、弾が進み、敵が下降する。"),
    "任務完成": ("Mission complete", "ミッション完了"),
    "這回合結束": ("Round over", "ラウンド終了"),
    "Enter 開始  ·  Space 射擊  ·  方向鍵移動": ("Enter start · Space shoot · Arrows move", "Enter 開始 · Space 発射 · 矢印 移動"),
    "R 建立新的一局  ·  Esc 離開": ("R new round · Esc quit", "R 新しいラウンド · Esc 終了"),
    "把畫面對回物件": ("Screen to objects", "画面と実体"),
    "類別關係：三種角色都是 Actor": ("Three actor types inherit from Actor", "三種類の役者は Actor を継承"),
    "Game 管理群組，統一呼叫 update(dt)": ("Game manages groups and calls update(dt)", "Game が Group を管理し update(dt) を呼ぶ"),
    "目前物件與參考": ("Objects and references", "オブジェクトと参照"),
    "(空)": ("(empty)", "(空)"),
    "shoot() → 建立新的 Bullet": ("shoot() → new Bullet", "shoot() → 新しい Bullet"),
    "物件事件": ("Object events", "オブジェクトのイベント"),
    "Game 建立 1 個 Player、3 個 Enemy": ("Game: 1 Player, 3 Enemies", "Game: Player 1、Enemy 3"),
    "建立 B01、B02；兩者 owner 都是 player": ("B01 / B02: owner → player", "B01 / B02: owner → player"),
    "方向鍵 / WASD  移動     Space  射擊     P  暫停     N  單步": ("Arrows / WASD move     Space shoot     P pause     N step", "矢印 / WASD 移動     Space 発射     P 一時停止     N 1 フレーム"),
    "Tab  物件標籤     R  重新開始     Esc  離開": ("Tab object labels     R reset     Esc quit", "Tab 実体ラベル     R リセット     Esc 終了"),
}
PATTERNS = [
    (r"已獲得 (\d+) 分，成功守住防線。", ("Score {0}. The defense held!", "{0} 点で防衛に成功。")),
    (r"獲得 (\d+) 分。每個物件都有自己的狀態。", ("Score {0}. Each object has its own state.", "{0} 点。各実体は自分の状態を持つ。")),
    (r"目標 (\d+) 分；撞擊或漏接敵人會失去生命。", ("Target {0}; contact or missed enemies cost HP.", "目標 {0} 点。接触や敵の通過で HP が減る。")),
    (r"建立 (B\d+)；owner → player", ("Created {0}; owner → player", "{0} を生成；owner → player")),
    (r"(B\d+) → (E\d+)：擊破 \+10", ("{0} → {1}: defeated +10", "{0} → {1}: 撃破 +10")),
    (r"(B\d+) → (E\d+)：HP=(\d+)", ("{0} → {1}: HP={2}", "{0} → {1}: HP={2}")),
    (r"碰撞；player.hp = (\d+)", ("Collision; player.hp = {0}", "衝突；player.hp = {0}")),
    (r"漏接敵人；player.hp = (\d+)", ("Missed enemy; player.hp = {0}", "敵の通過；player.hp = {0}")),
]


def translate(value, lang):
    value = str(value)
    if lang == "zh":
        return value
    index = 0 if lang == "en" else 1
    if value in TEXT:
        return TEXT[value][index]
    for pattern, versions in PATTERNS:
        match = re.fullmatch(pattern, value)
        if match:
            return versions[index].format(*match.groups())
    return value
