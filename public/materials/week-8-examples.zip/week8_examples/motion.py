"""Movement strategies. Each enemy owns its own mutable Weave instance."""
from math import cos
from typing import Protocol


class Motion(Protocol):
    def velocity(self, dt: float) -> tuple[float, float]: ...


class Straight:
    def velocity(self, dt: float) -> tuple[float, float]:
        return (0.0, 80.0)


class Weave:
    def __init__(self) -> None:
        self.elapsed = 0.0

    def velocity(self, dt: float) -> tuple[float, float]:
        self.elapsed += dt
        return (100.0 * cos(3.0 * self.elapsed), 80.0)


class Freeze:
    def velocity(self, dt: float) -> tuple[float, float]:
        return (0.0, 0.0)
