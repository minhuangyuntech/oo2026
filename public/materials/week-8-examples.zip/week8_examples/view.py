"""畫面繪製集中在這裡；遊戲規則與角色行為仍在 Game 與 Actor 子類別。"""

from pathlib import Path
import pygame
from i18n import translate

from settings import (
    BG, CORAL, LINE, MINT, MUTED, PANEL, PLAY_AREA,
    PURPLE, TARGET_SCORE, WHITE, YELLOW,
)


def load_fonts(lang="zh"):
    candidates = [
        Path("C:/Windows/Fonts/YuGothM.ttc") if lang == "ja" else Path("C:/Windows/Fonts/msjh.ttc"),
        Path("C:/Windows/Fonts/msjh.ttc"),
        Path("/System/Library/Fonts/PingFang.ttc"),
        Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"),
    ]
    cjk = next((str(path) for path in candidates if path.exists()), None)
    if cjk is None:
        cjk = pygame.font.match_font("microsoftjhenghei,pingfangtc,notosanscjktc")
    mono = pygame.font.match_font("consolas,dejavusansmono")
    return {
        "small": pygame.font.Font(cjk, 15),
        "body": pygame.font.Font(cjk, 18),
        "subtitle": pygame.font.Font(cjk, 22),
        "title": pygame.font.Font(cjk, 32),
        "number": pygame.font.Font(mono, 34),
        "code": pygame.font.Font(mono, 17),
    }


def text(game, value, position, color=WHITE, size="body"):
    image = game.fonts[size].render(translate(value, game.lang), True, color)
    game.screen.blit(image, position)
    return image.get_rect(topleft=position)


def card(game, rect, color=PANEL, border=LINE):
    pygame.draw.rect(game.screen, color, rect, border_radius=12)
    pygame.draw.rect(game.screen, border, rect, width=1, border_radius=12)


def draw_field(game):
    screen = game.screen
    card(game, PLAY_AREA, "#0e1b2e")
    old_clip = screen.get_clip()
    screen.set_clip(PLAY_AREA.inflate(-2, -2))
    for row in range(12):
        for col in range(15):
            x, y = PLAY_AREA.left + 25 + col * 50, PLAY_AREA.top + 30 + row * 50
            pygame.draw.circle(screen, "#25364b", (x, y), 1)
    for x in range(PLAY_AREA.left + 12, PLAY_AREA.right - 10, 20):
        pygame.draw.line(screen, "#456178", (x, PLAY_AREA.bottom - 12), (x + 8, PLAY_AREA.bottom - 12))
    game.all_sprites.draw(screen)
    if game.player.invulnerable > 0:
        pygame.draw.circle(screen, MINT, game.player.rect.center, 33, width=2)
    if game.show_labels:
        for actor in game.all_sprites:
            color = MINT if actor is game.player else YELLOW if actor in game.bullets else CORAL
            pygame.draw.rect(screen, color, actor.rect.inflate(8, 8), width=1, border_radius=4)
            label = f"{actor.name} : {type(actor).__name__}"
            width = game.fonts["code"].size(label)[0]
            x = max(PLAY_AREA.left + 8, min(actor.rect.centerx - width // 2, PLAY_AREA.right - width - 8))
            text(game, label, (x, actor.rect.top - 27), color, "code")
            if actor in game.enemies:
                text(game, f"HP {actor.hp}  /  v {actor.velocity.y:.0f}", (actor.rect.centerx - 47, actor.rect.bottom + 7), MUTED, "small")
    screen.set_clip(old_clip)
    if game.state == "paused":
        card(game, (42, 666, 326, 38), "#203446")
        text(game, "已暫停  ·  P 繼續 / N 前進一影格", (56, 674), YELLOW, "small")
    if game.state in ("ready", "won", "lost"):
        draw_overlay(game)


def draw_overlay(game):
    layer = pygame.Surface(PLAY_AREA.size, pygame.SRCALPHA)
    layer.fill((7, 15, 27, 192))
    game.screen.blit(layer, PLAY_AREA.topleft)
    x, y = PLAY_AREA.left + 83, PLAY_AREA.top + 175
    card(game, (x, y, 574, 250), "#15283f", "#40617b")
    labels = {
        "ready": ("讓物件一起動起來", "玩家移動、子彈前進、敵人下降。"),
        "won": ("任務完成", f"已獲得 {game.score} 分，成功守住防線。"),
        "lost": ("這回合結束", f"獲得 {game.score} 分。每個物件都有自己的狀態。"),
    }
    title, subtitle = labels[game.state]
    text(game, "OOP STAR LAB", (x + 28, y + 24), MINT, "code")
    text(game, title, (x + 28, y + 62), WHITE, "title")
    text(game, subtitle, (x + 28, y + 116), MUTED)
    action = "Enter 開始  ·  Space 射擊  ·  方向鍵移動" if game.state == "ready" else "R 建立新的一局  ·  Esc 離開"
    text(game, action, (x + 28, y + 168), MINT)
    text(game, f"目標 {TARGET_SCORE} 分；撞擊或漏接敵人會失去生命。", (x + 28, y + 209), MUTED, "small")


def draw_inspector(game):
    card(game, (788, 112, 388, 612))
    text(game, "LIVE OBJECTS", (808, 130), MINT, "code")
    text(game, "把畫面對回物件", (953, 128), WHITE, "body")
    for i, (name, count, color) in enumerate([
        ("Player", 1, MINT), ("Enemy", len(game.enemies), CORAL), ("Bullet", len(game.bullets), YELLOW),
    ]):
        x = 808 + i * 117
        card(game, (x, 167, 108, 72), "#0d1b2c")
        text(game, count, (x + 12, 171), color, "number")
        text(game, name, (x + 12, 213), MUTED, "code")
    text(game, "類別關係：三種角色都是 Actor", (808, 255), WHITE, "small")
    # UML 泛化：空心三角形指向共同父類別。
    pygame.draw.lines(game.screen, MUTED, False, [(861, 340), (861, 326), (1103, 326), (1103, 340)], 1)
    pygame.draw.line(game.screen, MUTED, (982, 340), (982, 318))
    pygame.draw.polygon(game.screen, MUTED, [(982, 310), (976, 318), (988, 318)], 1)
    card(game, (928, 281, 108, 30), "#20334b")
    text(game, "Actor", (955, 285), WHITE, "code")
    for x, name, color in [(808, "Player", MINT), (929, "Enemy", CORAL), (1050, "Bullet", YELLOW)]:
        card(game, (x, 340, 106, 32), "#0d1b2c")
        text(game, name, (x + 20, 345), color, "code")
    text(game, "Game 管理群組，統一呼叫 update(dt)", (808, 387), MUTED, "small")
    pygame.draw.line(game.screen, LINE, (808, 418), (1156, 418))
    text(game, "目前物件與參考", (808, 432), WHITE, "body")
    names = ", ".join(enemy.name for enemy in list(game.enemies)[:4]) or translate("(空)", game.lang)
    if len(game.enemies) > 4:
        names += " ..."
    text(game, "game.player → player", (808, 467), MINT, "code")
    text(game, f"enemies → {names}", (808, 495), MUTED, "code")
    bullet = next(iter(game.bullets), None)
    reference = f"{bullet.name}.owner is player → True" if bullet else "shoot() → 建立新的 Bullet"
    text(game, reference, (808, 523), YELLOW, "small")
    text(game, f"player.hp = {game.player.hp}    score = {game.score}", (808, 553), WHITE, "code")
    text(game, f"pos = ({game.player.rect.centerx}, {game.player.rect.centery})", (808, 579), MUTED, "code")
    pygame.draw.line(game.screen, LINE, (808, 612), (1156, 612))
    text(game, "物件事件", (808, 625), WHITE, "small")
    for i, event in enumerate(game.events):
        text(game, event, (808, 651 + i * 21), MUTED, "small")


def draw(game):
    game.screen.fill(BG)
    text(game, "PYTHON  /  OBJECT-ORIENTED PROGRAMMING", (24, 18), MINT, "code")
    text(game, "星際物件實驗室", (24, 46), WHITE, "title")
    text(game, "一個類別，多個物件；每個物件，各自運作。", (350, 59), MUTED, "small")
    text(game, f"SCORE  {game.score:03} / {TARGET_SCORE}", (805, 25), WHITE, "code")
    text(game, "LIFE", (805, 62), MUTED, "code")
    for i in range(3):
        pygame.draw.rect(game.screen, MINT if i < game.player.hp else LINE, (867 + i * 24, 63, 17, 17), border_radius=4)
    state_name = {"ready": "READY", "playing": "PLAYING", "paused": "PAUSED", "won": "COMPLETE", "lost": "GAME OVER"}[game.state]
    text(game, state_name, (1018, 59), YELLOW, "code")
    draw_field(game)
    draw_inspector(game)
    text(game, "方向鍵 / WASD  移動     Space  射擊     P  暫停     N  單步", (26, 742), WHITE, "small")
    text(game, "Tab  物件標籤     R  重新開始     Esc  離開", (26, 768), MUTED, "small")
    text(game, "Player  ●  Enemy  ●  Bullet", (888, 750), MUTED, "code")
