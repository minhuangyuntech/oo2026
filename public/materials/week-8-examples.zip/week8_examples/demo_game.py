"""python demo_game.py --lang zh: original shooter with Week 8 enemies."""
import argparse
import os

os.environ.setdefault('PYGAME_HIDE_SUPPORT_PROMPT', '1')

import pygame
from actors import Enemy
from extension import StrategyEnemy, WeavingEnemy
from game import Game
from motion import Straight, Weave
from settings import PLAY_AREA


class Week8Game(Game):
    def spawn_enemy(self, position=None, speed=None, hp=None):
        if position is None:
            # Keep the weave's horizontal displacement within the playfield.
            position = (self.rng.randint(PLAY_AREA.left + 90,
                                        PLAY_AREA.right - 90), PLAY_AREA.top - 24)
        speed = 80 if speed is None else speed
        hp = 1 if hp is None else hp
        name = f'E{self.next_enemy:02}'
        kind = self.next_enemy % 3
        if kind == 1:
            enemy = Enemy(name, position, speed, hp)
        elif kind == 2:
            enemy = WeavingEnemy(name, position, speed, hp)
        else:
            enemy = StrategyEnemy(name, position, Weave())
        self.next_enemy += 1
        self.enemies.add(enemy)
        self.all_sprites.add(enemy)
        return enemy

    def handle_events(self, events):
        super().handle_events(events)
        for event in events:
            if event.type == pygame.KEYDOWN and event.key == pygame.K_c:
                for enemy in self.enemies:
                    if isinstance(enemy, StrategyEnemy):
                        enemy.motion = (Straight() if isinstance(enemy.motion, Weave)
                                        else Weave())


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lang', choices=('zh', 'en', 'ja'), default='zh')
    args = parser.parse_args()
    try:
        Week8Game(lang=args.lang).run()
    finally:
        pygame.quit()
