"""遊戲設定：座標與速度的單位分別是像素、像素／秒。"""

import pygame

WINDOW_SIZE = (1200, 800)
PLAY_AREA = pygame.Rect(24, 112, 740, 612)
FPS = 60
PLAYER_SPEED = 330
BULLET_SPEED = 620
SHOT_INTERVAL = 0.22
SPAWN_INTERVAL = 1.15
TARGET_SCORE = 200

BG = "#0b1422"
PANEL = "#132238"
LINE = "#283d55"
WHITE = "#edf4fb"
MUTED = "#91a9c2"
MINT = "#68edbe"
CORAL = "#ff8b81"
YELLOW = "#ffd67b"
PURPLE = "#bca2ff"
