# 第 8 週：多態性・抽象化・インターフェース

Python 3.12+。ZIP を展開し、`week8_examples` フォルダーでターミナルを開いて実行します。

```sh
python -m pip install -r requirements.txt
python demo_game.py --lang ja
```

Enter で開始、方向キー／WASD で移動、Space で発射。P で停止／再開、停止中の N で一フレーム進めます。Tab はオブジェクトラベル、C は既存の StrategyEnemy の直進／揺動の切替、R は再開始、Esc は終了です。`--lang zh` または `--lang en` で別の言語を選べます。

初期場面の E01 は Enemy、E02 は WeavingEnemy、E03 は StrategyEnemy です。開始後に P で止め、N で位置の変化を観察します。C で E03 の motion を替えても、同一性と HP は保たれます。新たに生成される StrategyEnemy は、それぞれ専用の Weave を持ちます。

| ファイル | 内容 |
| --- | --- |
| actors.py、game.py、settings.py、view.py、i18n.py | 元のモデル・調整処理・描画・翻訳 |
| contracts.py | ABC、Protocol、異なる実体を更新する tick_all |
| motion.py | Motion、Straight、Weave、Freeze |
| extension.py | WeavingEnemy のオーバーライド、StrategyEnemy の速度計算の委譲 |
| demo_game.py | 第 8 週版の起動と生成ルール |
| typing_error.py | 意図的に Updatable に適合しない BadClock |
| tests/test_week8.py | 契約・同一性・移動・停止・一歩実行の 7 テスト |

```sh
python contracts.py
python -m mypy --strict contracts.py motion.py
python -m mypy --strict typing_error.py
python -m unittest discover -s tests -v
```

`contracts.py` は `40.0 0.5` と `True` を出力します。三つ目のコマンドでは、BadClock.update に dt がないため assignment の型エラーが 1 件出ます。`typing_error.py` を直接実行すると TypeError になります。静的検査と実行時の振る舞いを比較するための例です。それ以外の型検査と 7 テストは成功します。

スライドのコードは抜粋です。完全なインポートと前後の定義は各ファイルを参照してください。`dt` は秒、戦略の戻り値はピクセル毎秒です。Actor.update が速度に dt を掛けます。

元のゲームのシステムフォント選択を使います。Windows／macOS は既存の CJK フォントを使い、Linux で中日文を表示するには Noto CJK フォントが必要です。ラベルのキーはダウンロード版では Tab、ブラウザー版では L です。

元の [ブラウザー版](https://minhuangyuntech.github.io/oo2026/ja/pygame/play/)。第 8 週の新しい敵と戦略はこのダウンロードに収録しています。オフライン教材は `docs/lesson-zh.html`、`lesson-en.html`、`lesson-ja.html` です。
