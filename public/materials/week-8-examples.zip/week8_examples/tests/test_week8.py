import os
os.environ['SDL_VIDEODRIVER'] = 'dummy'
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = '1'
import unittest
import pygame
from contracts import UpdateableABC, FallingTarget, Spark, BadClock, CanUpdate, tick_all
from extension import StrategyEnemy, WeavingEnemy
from motion import Straight, Weave, Freeze
from demo_game import Week8Game


class ContractTests(unittest.TestCase):
    def test_abstract_class_cannot_be_created(self):
        with self.assertRaises(TypeError):
            UpdateableABC()

    def test_structural_updates(self):
        target, spark = FallingTarget(), Spark()
        tick_all([target, spark], 0.5)
        self.assertEqual((target.y, spark.ttl), (40.0, 0.5))

    def test_runtime_protocol_is_not_signature_validation(self):
        bad = BadClock()
        self.assertIsInstance(bad, CanUpdate)
        with self.assertRaises(TypeError):
            bad.update(0.5)

    def test_strategy_swap_preserves_enemy_and_hp(self):
        enemy = StrategyEnemy('E01', (300, 200), Straight())
        old = enemy
        enemy.update(0.5)
        self.assertEqual(tuple(enemy.pos), (300.0, 240.0))
        enemy.motion = Freeze()
        enemy.update(0.5)
        self.assertIs(enemy, old)
        self.assertEqual(tuple(enemy.pos), (300.0, 240.0))
        self.assertEqual(enemy.hp, 1)

    def test_mutable_strategies_are_independent(self):
        a, b = Weave(), Weave()
        a.velocity(0.5)
        self.assertEqual(b.elapsed, 0.0)

    def test_new_enemy_uses_original_collision_contract(self):
        enemy = WeavingEnemy('E01', (300, 200), 80, 2)
        group = pygame.sprite.Group(enemy)
        group.update(0.5)
        self.assertEqual(enemy.rect.center, (round(enemy.pos.x), round(enemy.pos.y)))
        self.assertFalse(enemy.take_hit(1))
        self.assertTrue(enemy.take_hit(1))
        self.assertNotIn(enemy, group)

    def test_playable_game_pause_step_and_swap(self):
        game = Week8Game(seed=7)
        try:
            game.handle_events([pygame.event.Event(pygame.KEYDOWN, key=pygame.K_RETURN),
                                pygame.event.Event(pygame.KEYDOWN, key=pygame.K_p)])
            enemy = next(e for e in game.enemies if isinstance(e, StrategyEnemy))
            old_y = enemy.pos.y
            game.handle_events([pygame.event.Event(pygame.KEYDOWN, key=pygame.K_c)])
            self.assertIsInstance(enemy.motion, Straight)
            game.handle_events([pygame.event.Event(pygame.KEYDOWN, key=pygame.K_n)])
            self.assertGreater(enemy.pos.y, old_y)
            self.assertEqual(game.state, 'paused')
            self.assertIn(enemy, game.all_sprites)
        finally:
            pygame.quit()


if __name__ == '__main__':
    unittest.main()
