"""Game 協調輸入、物件群組、碰撞、分數及遊戲狀態。"""

from collections import deque
import random

import pygame

from actors import Bullet, Enemy, Player
from settings import FPS, PLAY_AREA, SPAWN_INTERVAL, TARGET_SCORE, WINDOW_SIZE
import view


class Game:
    def __init__(self, seed=None, lang="zh"):
        if lang not in ("zh", "en", "ja"):
            raise ValueError("lang must be zh, en, or ja")
        self.lang = lang
        # 測試可指定 seed；正常遊玩每次都有不同的敵人排列。
        pygame.display.init()
        pygame.font.init()
        self.screen = pygame.display.set_mode(WINDOW_SIZE)
        pygame.display.set_caption("OOP Star Lab | Pygame")
        self.clock = pygame.time.Clock()
        self.fonts = view.load_fonts(lang)
        self.rng = random.Random(seed)
        self.running = True
        self.show_labels = True
        self.reset()

    def reset(self):
        if hasattr(self, "all_sprites"):
            for actor in self.all_sprites.sprites():
                actor.kill()
        self.player = Player((PLAY_AREA.centerx, PLAY_AREA.bottom - 60))
        self.all_sprites = pygame.sprite.Group(self.player)
        self.enemies = pygame.sprite.Group()
        self.bullets = pygame.sprite.Group()
        self.score = 0
        self.state = "ready"
        self.spawn_timer = SPAWN_INTERVAL
        self.next_enemy = 1
        self.next_bullet = 1
        self.events = deque(maxlen=3)
        for x, y, speed, hp in [(180, 180, 65, 1), (395, 235, 85, 2), (620, 175, 100, 1)]:
            self.spawn_enemy((x, y), speed, hp)
        self.events.clear()
        self.events.append("Game 建立 1 個 Player、3 個 Enemy")

    def spawn_enemy(self, position=None, speed=None, hp=None):
        if position is None:
            position = (self.rng.randint(PLAY_AREA.left + 35, PLAY_AREA.right - 35), PLAY_AREA.top - 24)
        if speed is None:
            speed = self.rng.randint(65, 110)
        if hp is None:
            hp = self.rng.choice([1, 1, 2])
        enemy = Enemy(f"E{self.next_enemy:02}", position, speed, hp)
        self.next_enemy += 1
        # 同一個 enemy 加入兩個群組；並沒有複製出第二個敵人。
        self.enemies.add(enemy)
        self.all_sprites.add(enemy)
        return enemy

    def try_shoot(self):
        bullet = self.player.shoot(f"B{self.next_bullet:02}")
        if bullet is not None:
            self.next_bullet += 1
            self.bullets.add(bullet)
            self.all_sprites.add(bullet)
            self.events.append(f"建立 {bullet.name}；owner → player")
        return bullet

    def resolve_collisions(self):
        # 一顆子彈最多命中一個敵人，避免重疊時重複計分。
        for bullet in self.bullets.sprites():
            hits = pygame.sprite.spritecollide(bullet, self.enemies, False)
            if hits:
                enemy = hits[0]
                destroyed = enemy.take_hit(bullet.damage)
                bullet.kill()
                if destroyed:
                    self.score += 10
                self.events.append(
                    f"{bullet.name} → {enemy.name}：" + ("擊破 +10" if destroyed else f"HP={enemy.hp}")
                )
        # 撞到玩家或穿過防線都會扣血；短暫無敵避免連續扣光。
        for enemy in self.enemies.sprites():
            touching = enemy.rect.colliderect(self.player.rect)
            escaped = enemy.rect.top > PLAY_AREA.bottom
            if touching or escaped:
                enemy.kill()
                if self.player.take_damage():
                    reason = "碰撞" if touching else "漏接敵人"
                    self.events.append(f"{reason}；player.hp = {self.player.hp}")

    def update(self, dt):
        # 多型：相同呼叫，Player / Enemy / Bullet 各自處理更新。
        self.all_sprites.update(dt)
        self.spawn_timer -= dt
        if self.spawn_timer <= 0:
            self.spawn_enemy()
            self.spawn_timer += SPAWN_INTERVAL
        self.resolve_collisions()
        if self.player.hp == 0:
            self.state = "lost"
        elif self.score >= TARGET_SCORE:
            self.state = "won"

    def handle_events(self, events):
        for event in events:
            if event.type == pygame.QUIT:
                self.running = False
            if event.type != pygame.KEYDOWN:
                continue
            if event.key == pygame.K_ESCAPE:
                self.running = False
            elif event.key == pygame.K_RETURN and self.state == "ready":
                self.state = "playing"
            elif event.key == pygame.K_p and self.state in ("playing", "paused"):
                self.state = "paused" if self.state == "playing" else "playing"
            elif event.key == pygame.K_n and self.state == "paused":
                self.player.set_direction(0, 0)
                self.update(1 / FPS)
            elif event.key == pygame.K_TAB:
                self.show_labels = not self.show_labels
            elif event.key == pygame.K_r:
                self.reset()

    def tick(self, dt, direction=(0, 0), shooting=False):
        if self.state != "playing":
            return
        self.player.set_direction(*direction)
        self.update(dt)
        if shooting and self.state == "playing":
            self.try_shoot()

    def run(self):
        while self.running:
            # 限制最大步長，避免視窗被拖曳或暫停時物件一次跳太遠。
            dt = min(self.clock.tick(FPS) / 1000, 1 / 30)
            self.handle_events(pygame.event.get())
            keys = pygame.key.get_pressed()
            direction = (
                int(keys[pygame.K_d] or keys[pygame.K_RIGHT]) - int(keys[pygame.K_a] or keys[pygame.K_LEFT]),
                int(keys[pygame.K_s] or keys[pygame.K_DOWN]) - int(keys[pygame.K_w] or keys[pygame.K_UP]),
            )
            self.tick(dt, direction, bool(keys[pygame.K_SPACE]))
            view.draw(self)
            pygame.display.flip()

    def prepare_snapshot(self):
        """固定場景供畫面檢查；正常遊戲不會呼叫。"""
        self.state = "paused"
        for name, y in [("B01", 490), ("B02", 370)]:
            bullet = Bullet(name, self.player)
            bullet.pos.y = y
            bullet.rect.center = bullet.pos
            self.bullets.add(bullet)
            self.all_sprites.add(bullet)
        self.next_bullet = 3
        self.events.append("建立 B01、B02；兩者 owner 都是 player")
