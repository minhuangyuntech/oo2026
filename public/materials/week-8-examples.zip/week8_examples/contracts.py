"""Week 8: ABC, structural typing, and a non-Sprite updateable object."""
from abc import ABC, abstractmethod
from collections.abc import Iterable
from typing import Protocol, runtime_checkable


class UpdateableABC(ABC):
    @abstractmethod
    def update(self, dt: float) -> None:
        pass


class FallingTarget(UpdateableABC):
    def __init__(self) -> None:
        self.y = 0.0

    def update(self, dt: float) -> None:
        self.y += 80.0 * dt


class Updatable(Protocol):
    def update(self, dt: float) -> None: ...


def tick_all(items: Iterable[Updatable], dt: float) -> None:
    for item in items:
        item.update(dt)


class Spark:
    def __init__(self) -> None:
        self.ttl = 1.0

    def update(self, dt: float) -> None:
        self.ttl = max(0.0, self.ttl - dt)


class BadClock:
    def update(self) -> None:
        pass


@runtime_checkable
class CanUpdate(Protocol):
    def update(self, dt: float) -> None: ...


if __name__ == '__main__':
    target = FallingTarget()
    spark = Spark()
    tick_all([target, spark], 0.5)
    print(target.y, spark.ttl)  # 40.0 0.5
    print(isinstance(BadClock(), CanUpdate))  # True; signature not checked
