"""Week 8 extensions to the original Pygame shooter."""
from math import cos

from actors import Enemy
from motion import Motion


class WeavingEnemy(Enemy):
    def __init__(self, name, position, speed=80, hp=1):
        super().__init__(name, position, speed, hp)
        self.elapsed = 0.0

    def update(self, dt):
        self.elapsed += dt
        self.velocity.x = 100 * cos(3 * self.elapsed)
        super().update(dt)


class StrategyEnemy(Enemy):
    def __init__(self, name, position, motion: Motion):
        super().__init__(name, position)
        self.motion = motion

    def update(self, dt):
        vx, vy = self.motion.velocity(dt)
        self.velocity.update(vx, vy)
        super().update(dt)
