第7週繼承範例。Python 3.12。使用原射擊遊戲的 actors.py 與 settings.py。此範例在終端機輸出結果，不開啟視窗。

```
python -m pip install -r requirements.txt
python week7_demo.py
```

Enemy: (200,120)
FastEnemy: (200,140)
DiagonalEnemy: (215,120)
MRO: D, B, C, A, object
act: B, C, A

https://minhuangyuntech.github.io/oo2026/pygame/play/
