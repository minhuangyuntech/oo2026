Week 7 inheritance examples. Python 3.12. Uses actors.py and settings.py from the original shooter. This example prints results in the terminal and does not open a window.

```
python -m pip install -r requirements.txt
python week7_demo.py
```

Enemy: (200,120)
FastEnemy: (200,140)
DiagonalEnemy: (215,120)
MRO: D, B, C, A, object
act: B, C, A

https://minhuangyuntech.github.io/oo2026/pygame/play/
