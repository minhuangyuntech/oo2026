from actors import Actor, Enemy

class FastEnemy(Enemy):
    def __init__(self, name, position):
        super().__init__(name, position, speed=160)

class DiagonalEnemy(Enemy):
    def update(self, dt):
        self.velocity.x = 60
        super().update(dt)

enemies = [Enemy("E01", (200, 100)),
           FastEnemy("F01", (200, 100)),
           DiagonalEnemy("D01", (200, 100))]
for enemy, expected in zip(enemies, [(200, 120), (200, 140), (215, 120)]):
    enemy.update(0.25)
    print(type(enemy).__name__, tuple(enemy.pos))
    assert tuple(enemy.pos) == expected
    assert enemy.rect.center == expected
    assert isinstance(enemy, Actor)
assert Enemy.update is Actor.update
a = Enemy("A", (100, 100), hp=1)
b = Enemy("B", (200, 100), hp=3)
a.hp = 0
assert b.hp == 3 and a.velocity is not b.velocity

trace = []
class A:
    def act(self):
        trace.append("A")
class B(A):
    def act(self):
        trace.append("B")
        super().act()
class C(A):
    def act(self):
        trace.append("C")
        super().act()
class D(B, C): pass
print([cls.__name__ for cls in D.__mro__])
D().act()
assert trace == ["B", "C", "A"]
print(trace)
print("All checks passed.")
