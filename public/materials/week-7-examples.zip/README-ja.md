第7週の継承の例。Python 3.12。元のゲームの actors.py と settings.py を使用します。この例は端末に結果を表示し、ウィンドウは開きません。

```
python -m pip install -r requirements.txt
python week7_demo.py
```

Enemy: (200,120)
FastEnemy: (200,140)
DiagonalEnemy: (215,120)
MRO: D, B, C, A, object
act: B, C, A

https://minhuangyuntech.github.io/oo2026/pygame/play/
