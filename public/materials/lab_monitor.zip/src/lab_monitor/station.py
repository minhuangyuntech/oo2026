"""MonitorStation：協調一次取樣的流程。

它自己不判斷讀值、不決定怎麼通知、不決定怎麼存，
只負責「依序請對的物件做事」（控制者）。
所有合作物件都從建構子傳進來，所以測試時可以換成假的。
"""

from collections.abc import Callable, Iterable
from datetime import datetime

from .models import Alert, Reading
from .notifiers import Notifier
from .rules import AlertRule
from .sensors import Sensor
from .store import ReadingStore

Clock = Callable[[], datetime]


class MonitorStation:
    def __init__(
        self,
        sensors: Iterable[Sensor],
        rules: Iterable[AlertRule],
        notifiers: Iterable[Notifier],
        store: ReadingStore,
        clock: Clock = datetime.now,
    ) -> None:
        self._sensors = list(sensors)
        ids = [sensor.sensor_id for sensor in self._sensors]
        if len(ids) != len(set(ids)):
            raise ValueError("sensor_id 不可重複")
        self._rules = list(rules)
        self._notifiers = list(notifiers)
        self._store = store
        self._clock = clock

    def poll_once(self) -> list[Alert]:
        """讀取每個感測器一次：記錄 → 檢查規則 → 通知。回傳這一輪的告警。"""
        at = self._clock()
        alerts: list[Alert] = []
        for sensor in self._sensors:
            reading = sensor.read(at)
            self._store.add(reading)
            alerts.extend(self._check(reading))
        for alert in alerts:
            for notifier in self._notifiers:
                notifier.notify(alert)
        return alerts

    def latest(self, sensor_id: str, n: int = 1) -> list[Reading]:
        """查詢某個感測器最近 n 筆讀值（由舊到新）。"""
        return self._store.latest(sensor_id, n)

    def _check(self, reading: Reading) -> list[Alert]:
        alerts: list[Alert] = []
        for rule in self._rules:
            alert = rule.check(reading)
            if alert is not None:
                alerts.append(alert)
        return alerts
