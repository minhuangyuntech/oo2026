"""告警規則。

「這筆讀值有沒有問題」由規則物件自己判斷（資訊專家：
門檻資料在規則身上，所以判斷也放在規則身上）。
"""

from dataclasses import dataclass
from typing import Protocol

from .models import Alert, Level, Reading


class AlertRule(Protocol):
    """檢查一筆讀值；有問題時回傳 Alert，沒問題或不適用時回傳 None。"""

    def check(self, reading: Reading) -> Alert | None: ...


@dataclass(frozen=True)
class ThresholdRule:
    """讀值低於 low 或高於 high 時告警；剛好等於門檻不告警。"""

    sensor_id: str
    low: float | None = None
    high: float | None = None
    level: Level = Level.WARNING

    def __post_init__(self) -> None:
        if self.low is None and self.high is None:
            raise ValueError("至少要設定 low 或 high 其中一個")
        if self.low is not None and self.high is not None and self.low >= self.high:
            raise ValueError("low 必須小於 high")

    def check(self, reading: Reading) -> Alert | None:
        if reading.sensor_id != self.sensor_id:
            return None
        unit = reading.unit
        if self.high is not None and reading.value > self.high:
            return Alert(
                reading,
                self.level,
                f"{reading.sensor_id} 讀值 {reading.value}{unit} 高於上限 {self.high}{unit}",
            )
        if self.low is not None and reading.value < self.low:
            return Alert(
                reading,
                self.level,
                f"{reading.sensor_id} 讀值 {reading.value}{unit} 低於下限 {self.low}{unit}",
            )
        return None
