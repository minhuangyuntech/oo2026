"""感測器介面與兩種模擬感測器。

課堂上沒有真實硬體，所以用模擬感測器代替。
只要符合 Sensor 介面，之後換成真正的 USB / GPIO 感測器時，
MonitorStation 不需要修改。
"""

import random
from collections.abc import Iterable
from datetime import datetime
from typing import Protocol

from .models import Reading


class SensorError(Exception):
    """感測器無法提供讀值。"""


class Sensor(Protocol):
    """任何能在指定時間產生一筆 Reading 的物件。"""

    sensor_id: str

    def read(self, at: datetime) -> Reading: ...


class ScriptedSensor:
    """依序回傳預先給定的數值；用於測試與可重現的課堂示範。"""

    def __init__(
        self, sensor_id: str, quantity: str, unit: str, values: Iterable[float]
    ) -> None:
        self.sensor_id = sensor_id
        self.quantity = quantity
        self.unit = unit
        self._values = iter(values)

    def read(self, at: datetime) -> Reading:
        try:
            value = next(self._values)
        except StopIteration:
            raise SensorError(f"{self.sensor_id} 沒有更多資料") from None
        return Reading(self.sensor_id, self.quantity, value, self.unit, at)


class RandomWalkSensor:
    """每次讀取時在前一個值附近隨機變動；給定 seed 時結果可重現。"""

    def __init__(
        self,
        sensor_id: str,
        quantity: str,
        unit: str,
        start: float,
        step: float,
        seed: int | None = None,
    ) -> None:
        if step < 0:
            raise ValueError("step 不可為負數")
        self.sensor_id = sensor_id
        self.quantity = quantity
        self.unit = unit
        self._value = start
        self._step = step
        self._rng = random.Random(seed)

    def read(self, at: datetime) -> Reading:
        self._value += self._rng.uniform(-self._step, self._step)
        return Reading(
            self.sensor_id, self.quantity, round(self._value, 2), self.unit, at
        )
