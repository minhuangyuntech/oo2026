"""課堂示範：python -m lab_monitor

使用模擬時鐘（每輪前進 10 秒），所以每次執行的輸出都一樣。
"""

import argparse
from datetime import datetime, timedelta

from .models import Level
from .notifiers import ConsoleNotifier
from .rules import AlertRule, ThresholdRule
from .sensors import RandomWalkSensor, ScriptedSensor, Sensor
from .station import Clock, MonitorStation
from .store import MemoryStore

START = datetime(2026, 12, 1, 9, 0, 0)
VOLTAGES = [5.00, 5.02, 4.98, 5.31, 5.35, 5.01, 4.62, 5.00]


def simulated_clock(start: datetime, step: timedelta) -> Clock:
    """回傳一個每呼叫一次就前進 step 的時鐘。"""
    current = start - step

    def now() -> datetime:
        nonlocal current
        current += step
        return current

    return now


def build_demo_station(store: MemoryStore) -> MonitorStation:
    sensors: list[Sensor] = [
        RandomWalkSensor("T-01", "temperature", "°C", start=27.0, step=0.8, seed=27),
        RandomWalkSensor("H-01", "humidity", "%", start=55.0, step=4.0, seed=7),
        ScriptedSensor("V-01", "voltage", "V", VOLTAGES),
    ]
    rules: list[AlertRule] = [
        ThresholdRule("T-01", high=28.0),
        ThresholdRule("H-01", low=30.0, high=70.0),
        ThresholdRule("V-01", low=4.75, high=5.25, level=Level.CRITICAL),
    ]
    return MonitorStation(
        sensors,
        rules,
        [ConsoleNotifier()],
        store,
        clock=simulated_clock(START, timedelta(seconds=10)),
    )


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="實驗室環境監測站示範")
    parser.add_argument("--rounds", type=int, default=len(VOLTAGES))
    args = parser.parse_args(argv)
    if not 1 <= args.rounds <= len(VOLTAGES):
        parser.error(f"--rounds 必須介於 1 到 {len(VOLTAGES)}")

    store = MemoryStore()
    station = build_demo_station(store)
    for round_no in range(1, args.rounds + 1):
        print(f"--- 第 {round_no} 輪 ---")
        alerts = station.poll_once()
        if not alerts:
            print("正常")

    print("--- V-01 最近 3 筆 ---")
    for reading in station.latest("V-01", 3):
        print(f"{reading.at:%H:%M:%S} {reading.value} {reading.unit}")


if __name__ == "__main__":
    main()
