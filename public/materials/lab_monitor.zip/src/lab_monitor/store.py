"""讀值紀錄。

ReadingStore 是介面；MemoryStore 是目前的實作。
之後可以加一個 SQLiteStore（接資料庫單元），MonitorStation 不需要修改。
"""

from collections import deque
from typing import Protocol

from .models import Reading


class ReadingStore(Protocol):
    def add(self, reading: Reading) -> None: ...

    def latest(self, sensor_id: str, n: int = 1) -> list[Reading]: ...


class MemoryStore:
    """每個感測器最多保留 capacity 筆讀值，超過時丟掉最舊的。"""

    def __init__(self, capacity: int = 1000) -> None:
        if capacity < 1:
            raise ValueError("capacity 至少為 1")
        self._capacity = capacity
        self._data: dict[str, deque[Reading]] = {}

    def add(self, reading: Reading) -> None:
        history = self._data.setdefault(
            reading.sensor_id, deque(maxlen=self._capacity)
        )
        history.append(reading)

    def latest(self, sensor_id: str, n: int = 1) -> list[Reading]:
        """回傳最近 n 筆，由舊到新；沒有資料時回傳空 list。"""
        if n < 1:
            raise ValueError("n 至少為 1")
        history = self._data.get(sensor_id)
        if history is None:
            return []
        return list(history)[-n:]
