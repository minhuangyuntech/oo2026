"""領域中的資料物件：讀值與告警。

Reading 與 Alert 建立後就不應再改變，所以使用 frozen dataclass。
"""

from dataclasses import dataclass
from datetime import datetime
from enum import StrEnum


class Level(StrEnum):
    """告警等級。"""

    WARNING = "warning"
    CRITICAL = "critical"


@dataclass(frozen=True, slots=True)
class Reading:
    """某個感測器在某個時間點的一筆讀值。"""

    sensor_id: str
    quantity: str
    value: float
    unit: str
    at: datetime


@dataclass(frozen=True, slots=True)
class Alert:
    """一筆讀值違反規則時產生的告警。"""

    reading: Reading
    level: Level
    message: str

    @property
    def sensor_id(self) -> str:
        return self.reading.sensor_id
