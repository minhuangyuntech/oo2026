"""通知管道。

新增通知方式（LINE、Email、Discord……）時，只要新增一個有
notify(alert) 方法的類別，MonitorStation 不需要修改。
"""

from pathlib import Path
from typing import Protocol

from .models import Alert


class Notifier(Protocol):
    def notify(self, alert: Alert) -> None: ...


def format_alert(alert: Alert) -> str:
    """把告警轉成一行文字，例如 [2026-12-01 09:00:30] CRITICAL V-01 ..."""
    return f"[{alert.reading.at:%Y-%m-%d %H:%M:%S}] {alert.level.upper()} {alert.message}"


class ConsoleNotifier:
    """把告警印到終端機。"""

    def notify(self, alert: Alert) -> None:
        print(format_alert(alert))


class FileNotifier:
    """把告警附加到文字檔，每筆一行。"""

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)

    def notify(self, alert: Alert) -> None:
        with self.path.open("a", encoding="utf-8") as file:
            file.write(format_alert(alert) + "\n")


class MemoryNotifier:
    """把告警存在 list；測試時用來檢查「通知了什麼」。"""

    def __init__(self) -> None:
        self.alerts: list[Alert] = []

    def notify(self, alert: Alert) -> None:
        self.alerts.append(alert)
