# 給 AI 助理的專案說明

這是一門物件導向課程的範例專案：實驗室環境監測站。
需求在 `docs/requirements.md`，設計在 `docs/design.md`。修改前請先閱讀這兩份文件。

## 規則

- Python 3.12+，只使用標準函式庫
- 程式必須通過 `pytest` 與 `mypy --strict`
- **不可修改 `tests/` 與 `exercises/*/test_*.py` 中的測試**；測試失敗時修改實作
- 介面使用 `typing.Protocol`，不要新增 ABC 或繼承階層
- 不要在類別內部呼叫 `datetime.now()` 或 `time.sleep()`；時間由外部傳入
- 不要實作 `docs/requirements.md` 第 5 節「不做的事」
- 不要新增需求沒有要求的類別（Factory、Manager 等）
- 註解與訊息使用繁體中文

## 指令

```bash
pytest                          # 主程式測試
pytest exercises/a_rate_rule    # 練習 A
mypy src                        # 型別檢查
python -m lab_monitor           # 示範
```
