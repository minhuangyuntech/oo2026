# 實驗室環境監測站（第 12 週範例）

物件導向分析與設計 × AI 輔助開發。不需要硬體，用模擬感測器執行。

## 環境準備

```bash
python -m venv .venv
# Windows PowerShell
.venv\Scripts\Activate.ps1
# macOS / Linux
source .venv/bin/activate

pip install -e ".[dev]"
```

## 執行

```bash
python -m lab_monitor     # 示範 8 輪取樣
pytest                    # 主程式測試（應全部通過）
mypy src                  # 型別檢查
```

## 檔案導覽

| 路徑 | 內容 |
|---|---|
| `docs/requirements.md` | 需求、釐清問題、使用者故事、使用案例、不做的事 |
| `docs/design.md` | 領域模型、類別圖、循序圖、職責分配、設計決定 |
| `docs/crc-cards.md` | CRC 卡與情境演練 |
| `docs/prompts.md` | 各階段提示詞範本 |
| `docs/review-checklist.md` | AI 產出審查清單 |
| `docs/ai-log-template.md` | AI 使用紀錄（期末專題反思素材） |
| `AGENTS.md` | 給 AI 助理看的專案規則 |
| `src/lab_monitor/` | 主程式 |
| `tests/` | 主程式測試 |
| `exercises/a_rate_rule/` | 練習 A：變化率告警 |
| `exercises/b_cooldown/` | 練習 B：告警冷卻 |
| `exercises/flawed_design/` | AI 設計找碴 |

## 課堂練習

```bash
pytest exercises/a_rate_rule   # 一開始會全部失敗，完成後應全部通過
pytest exercises/b_cooldown
```

規則：**不可以修改測試檔**。測試是你和 AI 之間的合約。
