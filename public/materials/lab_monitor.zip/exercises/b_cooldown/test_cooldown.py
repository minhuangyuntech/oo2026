"""練習 B 的驗收測試：這是你和 AI 之間的合約，不要為了讓測試通過而修改它。"""

from datetime import datetime, timedelta

import pytest

from cooldown import CooldownNotifier
from lab_monitor import (
    Alert,
    Level,
    MemoryNotifier,
    MemoryStore,
    MonitorStation,
    Notifier,
    Reading,
    ScriptedSensor,
    ThresholdRule,
)

T0 = datetime(2026, 12, 1, 9, 0, 0)
FIVE_MIN = timedelta(minutes=5)


def a(seconds: float, sensor_id: str = "V-01", level: Level = Level.CRITICAL) -> Alert:
    reading = Reading(sensor_id, "voltage", 5.4, "V", T0 + timedelta(seconds=seconds))
    return Alert(reading, level, f"{sensor_id} test")


def make() -> tuple[CooldownNotifier, MemoryNotifier]:
    inner = MemoryNotifier()
    return CooldownNotifier(inner, FIVE_MIN), inner


def test_satisfies_notifier_protocol() -> None:
    notifier: Notifier = CooldownNotifier(MemoryNotifier(), FIVE_MIN)
    notifier.notify(a(0))


def test_first_alert_passes_through() -> None:
    cooldown, inner = make()
    cooldown.notify(a(0))
    assert len(inner.alerts) == 1


def test_repeat_within_cooldown_is_suppressed() -> None:
    cooldown, inner = make()
    cooldown.notify(a(0))
    cooldown.notify(a(60))
    cooldown.notify(a(299))
    assert len(inner.alerts) == 1
    assert cooldown.suppressed == 2


def test_alert_after_cooldown_passes_again() -> None:
    cooldown, inner = make()
    cooldown.notify(a(0))
    cooldown.notify(a(300))  # 剛好滿 5 分鐘
    assert len(inner.alerts) == 2


def test_cooldown_counts_from_last_sent_not_last_seen() -> None:
    cooldown, inner = make()
    cooldown.notify(a(0))  # 送出
    cooldown.notify(a(200))  # 擋下
    cooldown.notify(a(300))  # 距上次「送出」已 5 分鐘 → 送出
    assert [x.reading.at for x in inner.alerts] == [T0, T0 + timedelta(seconds=300)]


def test_different_sensor_is_not_suppressed() -> None:
    cooldown, inner = make()
    cooldown.notify(a(0, sensor_id="V-01"))
    cooldown.notify(a(10, sensor_id="T-01"))
    assert len(inner.alerts) == 2


def test_different_level_is_not_suppressed() -> None:
    cooldown, inner = make()
    cooldown.notify(a(0, level=Level.WARNING))
    cooldown.notify(a(10, level=Level.CRITICAL))
    assert len(inner.alerts) == 2


@pytest.mark.parametrize("bad", [timedelta(0), timedelta(seconds=-1)])
def test_cooldown_must_be_positive(bad: timedelta) -> None:
    with pytest.raises(ValueError):
        CooldownNotifier(MemoryNotifier(), bad)


def test_station_needs_no_change() -> None:
    """MonitorStation 不知道冷卻的存在，照樣運作。"""
    times = iter(T0 + timedelta(seconds=10 * i) for i in range(3))
    inner = MemoryNotifier()
    station = MonitorStation(
        sensors=[ScriptedSensor("V-01", "voltage", "V", [5.4, 5.5, 5.6])],
        rules=[ThresholdRule("V-01", high=5.25)],
        notifiers=[CooldownNotifier(inner, FIVE_MIN)],
        store=MemoryStore(),
        clock=lambda: next(times),
    )
    for _ in range(3):
        station.poll_once()
    assert len(inner.alerts) == 1
