"""練習 B：告警冷卻（學生起始檔）。

需求（US-5）：
    「管理員不希望被同一件事一直洗版。」
    同一個感測器、同一個等級的告警，在冷卻時間內只通知第一次。

設計決定（課堂討論後）：
    冷卻不放進 MonitorStation、也不放進每個規則，而是做成一個
    「包住另一個 Notifier 的 Notifier」。MonitorStation 完全不用修改。

規格：
    - CooldownNotifier(inner, cooldown) 本身也符合 Notifier 介面
    - 以 (sensor_id, level) 當作「同一件事」
    - 時間以 alert.reading.at 計算，不使用 datetime.now()
    - 距離「上一次真正送出」的時間 >= cooldown 時，再送一次
    - 被擋下的告警數量記在 suppressed 屬性
    - cooldown 必須大於 0，否則 ValueError

先讀 test_cooldown.py，再請 AI 協助實作。完成後執行：
    pytest exercises/b_cooldown
"""

from datetime import timedelta

from lab_monitor import Alert, Notifier


class CooldownNotifier:
    def __init__(self, inner: Notifier, cooldown: timedelta) -> None:
        raise NotImplementedError

    def notify(self, alert: Alert) -> None:
        raise NotImplementedError
