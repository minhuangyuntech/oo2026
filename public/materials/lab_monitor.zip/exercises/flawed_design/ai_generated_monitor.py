"""AI 設計找碴練習。

情境：有同學把原始需求丟給 AI，只說「幫我寫一個實驗室監測系統，要用好的設計」，
得到下面這份程式。它看起來很完整，但問題很多。

任務（10 分鐘，分組）：
    對照 docs/requirements.md 與 docs/review-checklist.md，
    找出至少 8 個問題，每個問題寫下：行號、違反哪一條、會造成什麼後果。

注意：這份程式不是拿來執行的。
"""

import csv
import smtplib
import time
from abc import ABC, abstractmethod
from datetime import datetime

from labsensor import read_channel


class AbstractSensorFactory(ABC):
    @abstractmethod
    def create_sensor(self, sensor_type):
        pass


class SensorFactoryImpl(AbstractSensorFactory):
    def create_sensor(self, sensor_type):
        if sensor_type == "temperature":
            return TemperatureSensor()
        elif sensor_type == "humidity":
            return HumiditySensor()
        elif sensor_type == "voltage":
            return VoltageSensor()


class TemperatureSensor:
    def __init__(self):
        self.channel = 0

    def get_value(self):
        return read_channel(self.channel)


class HumiditySensor:
    def __init__(self):
        self.channel = 1

    def get_value(self):
        return read_channel(self.channel)


class VoltageSensor:
    def __init__(self):
        self.channel = 2

    def get_value(self):
        return read_channel(self.channel)


class LabMonitorSystem:
    SMTP_PASSWORD = "lab12345"

    def __init__(self, sensors=[]):
        self.sensors = sensors
        self.records = []
        self.users = {"admin": "admin"}
        self.logged_in = False
        self.enable_dashboard = True

    def login(self, user, password):
        self.logged_in = self.users.get(user) == password

    def run_forever(self):
        while True:
            for sensor in self.sensors:
                try:
                    value = sensor.get_value()
                    record = {"type": type(sensor).__name__, "value": value,
                              "time": datetime.now()}
                    self.records.append(record)
                    self.check_and_alert(record)
                except:
                    pass
            self.save_csv()
            time.sleep(10)

    def check_and_alert(self, record):
        if record["type"] == "TemperatureSensor":
            if record["value"] >= 28:
                self.send_email(f"溫度過高 {record['value']}")
        elif record["type"] == "HumiditySensor":
            if record["value"] >= 70 or record["value"] <= 30:
                self.send_email(f"濕度異常 {record['value']}")
        elif record["type"] == "VoltageSensor":
            if record["value"] >= 5.25 or record["value"] <= 4.75:
                self.send_email(f"電壓異常 {record['value']}")

    def send_email(self, message):
        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.login("lab@example.com", self.SMTP_PASSWORD)
        server.sendmail("lab@example.com", "admin@example.com", message)

    def save_csv(self):
        with open("records.csv", "w") as f:
            writer = csv.writer(f)
            for r in self.records:
                writer.writerow([r["type"], r["value"], r["time"]])

    def get_latest(self, sensor_type):
        for r in reversed(self.records):
            if r["type"] == sensor_type:
                return r
