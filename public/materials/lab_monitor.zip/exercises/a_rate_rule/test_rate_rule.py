"""練習 A 的驗收測試：這是你和 AI 之間的合約，不要為了讓測試通過而修改它。"""

from datetime import datetime, timedelta

import pytest

from lab_monitor import AlertRule, Level, Reading
from rate_rule import RateOfChangeRule

T0 = datetime(2026, 12, 1, 9, 0, 0)


def r(value: float, seconds: float, sensor_id: str = "V-01") -> Reading:
    return Reading(sensor_id, "voltage", value, "V", T0 + timedelta(seconds=seconds))


def test_satisfies_alert_rule_protocol() -> None:
    rule: AlertRule = RateOfChangeRule("V-01", max_change_per_minute=1.0)
    assert rule.check(r(5.0, 0)) is None


def test_first_reading_gives_no_alert() -> None:
    rule = RateOfChangeRule("V-01", max_change_per_minute=1.0)
    assert rule.check(r(5.0, 0)) is None


def test_slow_change_gives_no_alert() -> None:
    rule = RateOfChangeRule("V-01", max_change_per_minute=1.0)
    rule.check(r(5.0, 0))
    # 60 秒變化 0.5 V → 0.5 V/min
    assert rule.check(r(5.5, 60)) is None


def test_fast_rise_gives_alert() -> None:
    rule = RateOfChangeRule("V-01", max_change_per_minute=1.0, level=Level.CRITICAL)
    rule.check(r(5.0, 0))
    # 10 秒上升 0.3 V → 1.8 V/min
    alert = rule.check(r(5.3, 10))
    assert alert is not None
    assert alert.level is Level.CRITICAL
    assert "V-01" in alert.message
    assert "變化過快" in alert.message


def test_fast_drop_also_gives_alert() -> None:
    rule = RateOfChangeRule("V-01", max_change_per_minute=1.0)
    rule.check(r(5.0, 0))
    assert rule.check(r(4.6, 10)) is not None


def test_rate_equal_to_limit_is_not_alert() -> None:
    rule = RateOfChangeRule("V-01", max_change_per_minute=1.0)
    rule.check(r(5.0, 0))
    # 30 秒變化 0.5 V → 剛好 1.0 V/min
    assert rule.check(r(5.5, 30)) is None


def test_compares_with_previous_reading_not_first() -> None:
    rule = RateOfChangeRule("V-01", max_change_per_minute=1.0)
    rule.check(r(5.0, 0))
    rule.check(r(6.0, 60))  # 1.0 V/min，不告警，但要被記住
    # 和上一筆 6.0 比：60 秒變化 0.2 V → 不告警
    # （如果錯誤地和第一筆 5.0 比：120 秒變化 1.2 V → 0.6 V/min，也不告警，所以再多一步）
    assert rule.check(r(6.2, 120)) is None
    # 和上一筆 6.2 比：6 秒變化 0.3 V → 3 V/min → 告警
    assert rule.check(r(6.5, 126)) is not None


def test_state_is_updated_even_after_alert() -> None:
    rule = RateOfChangeRule("V-01", max_change_per_minute=1.0)
    rule.check(r(5.0, 0))
    assert rule.check(r(6.0, 10)) is not None
    # 和上一筆 6.0 比：10 秒變化 0 → 不告警
    # （如果沒更新、仍和 5.0 比：20 秒變化 1.0 V → 3 V/min → 會誤報）
    assert rule.check(r(6.0, 20)) is None


def test_same_timestamp_does_not_divide_by_zero() -> None:
    rule = RateOfChangeRule("V-01", max_change_per_minute=1.0)
    rule.check(r(5.0, 0))
    assert rule.check(r(9.0, 0)) is None


def test_time_going_backwards_gives_no_alert() -> None:
    rule = RateOfChangeRule("V-01", max_change_per_minute=1.0)
    rule.check(r(5.0, 60))
    assert rule.check(r(9.0, 0)) is None


def test_other_sensor_is_ignored_and_does_not_change_state() -> None:
    rule = RateOfChangeRule("V-01", max_change_per_minute=1.0)
    rule.check(r(5.0, 0))
    assert rule.check(r(99.0, 5, sensor_id="T-01")) is None
    # 若 T-01 的讀值被誤記成上一筆，這裡會算成大幅下降而告警
    assert rule.check(r(5.1, 60)) is None


@pytest.mark.parametrize("bad", [0, -1.0])
def test_limit_must_be_positive(bad: float) -> None:
    with pytest.raises(ValueError):
        RateOfChangeRule("V-01", max_change_per_minute=bad)
