"""練習 A：變化率告警規則（學生起始檔）。

需求（US-4）：
    電源突然飆升或驟降常常比「超過門檻」更早透露問題。
    當同一個感測器「相鄰兩筆讀值」的變化速度超過 max_change_per_minute 時告警。

規格：
    - 變化速度 = |本次值 - 上次值| / 兩筆相隔的分鐘數
    - 變化速度「大於」max_change_per_minute 才告警（等於不告警）
    - 每個規則只負責一個 sensor_id，其他感測器的讀值一律回傳 None，也不影響內部狀態
    - 第一筆讀值沒有比較對象，回傳 None
    - 兩筆時間相同或時間倒退（相隔 <= 0）時，不告警，也不要發生除以零
    - 不論是否告警，都要記住本次讀值，作為下一次的比較對象
    - max_change_per_minute 必須大於 0，否則 ValueError
    - 告警訊息需包含 sensor_id 與「變化過快」四個字

先讀 test_rate_rule.py，再請 AI 協助實作。完成後執行：
    pytest exercises/a_rate_rule
"""

from lab_monitor import Alert, Level, Reading


class RateOfChangeRule:
    def __init__(
        self,
        sensor_id: str,
        max_change_per_minute: float,
        level: Level = Level.WARNING,
    ) -> None:
        raise NotImplementedError

    def check(self, reading: Reading) -> Alert | None:
        raise NotImplementedError
