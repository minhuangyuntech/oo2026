# CRC 卡

CRC = **C**lass（類別）、**R**esponsibilities（職責）、**C**ollaborators（合作者）。
每張卡只寫三件事。寫不下，通常代表這個類別做太多事。

課堂上請用 A6 紙或便利貼手寫，一張一個類別。

---

| **MonitorStation** | |
|---|---|
| **職責** | **合作者** |
| 依序讀取每個感測器 | Sensor |
| 把讀值交給儲存 | ReadingStore |
| 把讀值交給每條規則檢查 | AlertRule |
| 把告警交給每個通知管道 | Notifier |
| 提供查詢最近讀值 | ReadingStore |

---

| **Sensor** | |
|---|---|
| **職責** | **合作者** |
| 知道自己的編號、物理量、單位 | — |
| 在指定時間產生一筆讀值 | Reading |

---

| **ThresholdRule** | |
|---|---|
| **職責** | **合作者** |
| 知道要檢查哪個感測器、上下限、等級 | — |
| 判斷讀值是否超出範圍 | Reading |
| 超出時建立告警 | Alert |

---

| **Notifier** | |
|---|---|
| **職責** | **合作者** |
| 把告警送到某個地方（螢幕、檔案……） | Alert |

---

| **ReadingStore** | |
|---|---|
| **職責** | **合作者** |
| 保存讀值 | Reading |
| 回傳某感測器最近 n 筆 | Reading |

---

## 情境演練（Role-play）

每位組員拿一張卡扮演那個物件，照著情境「說話」：

> 09:00:30，V-01 讀到 5.31 V。

1. **MonitorStation**：「clock，現在幾點？」→ clock：「09:00:30」
2. **MonitorStation**：「V-01，請給我 09:00:30 的讀值。」→ Sensor：「這是 Reading(V-01, 5.31 V)」
3. **MonitorStation**：「Store，請記下這筆。」
4. **MonitorStation**：「ThresholdRule，這筆有問題嗎？」→ Rule：「高於上限，這是一張 CRITICAL 告警。」
5. **MonitorStation**：「ConsoleNotifier，請送出這張告警。」

演練時如果有人說「這不是我該知道的」或「我需要問別人才能回答」，就是調整職責的時機。
