# 設計文件：實驗室環境監測站

> 圖使用 Mermaid 撰寫。在 VS Code 安裝 Markdown 預覽的 Mermaid 擴充套件，或直接推到 GitHub，就能看到圖。
> 用文字寫圖的好處：可以放進 Git 比較差異，也可以請 AI 產生或修改。

## 1. 領域模型（分析階段：只有概念，沒有方法）

```mermaid
classDiagram
    direction LR
    class MonitorStation
    class Sensor {
        sensor_id
        quantity
        unit
    }
    class Reading {
        value
        at
    }
    class AlertRule
    class Alert {
        level
        message
    }
    class Notifier
    class ReadingStore

    MonitorStation "1" o-- "1..*" Sensor : 輪詢
    MonitorStation "1" o-- "0..*" AlertRule : 套用
    MonitorStation "1" o-- "0..*" Notifier : 通知
    MonitorStation "1" --> "1" ReadingStore : 記錄
    Sensor "1" ..> "0..*" Reading : 產生
    AlertRule ..> Alert : 產生
    Alert "1" --> "1" Reading : 根據
```

## 2. 設計類別圖（設計階段：加上介面與方法）

```mermaid
classDiagram
    direction TB
    class Sensor {
        <<Protocol>>
        +sensor_id: str
        +read(at) Reading
    }
    class AlertRule {
        <<Protocol>>
        +check(reading) Alert | None
    }
    class Notifier {
        <<Protocol>>
        +notify(alert) None
    }
    class ReadingStore {
        <<Protocol>>
        +add(reading) None
        +latest(sensor_id, n) list~Reading~
    }
    class MonitorStation {
        -_sensors: list~Sensor~
        -_rules: list~AlertRule~
        -_notifiers: list~Notifier~
        -_store: ReadingStore
        -_clock: Clock
        +poll_once() list~Alert~
        +latest(sensor_id, n) list~Reading~
    }
    class Reading {
        <<frozen dataclass>>
        +sensor_id: str
        +quantity: str
        +value: float
        +unit: str
        +at: datetime
    }
    class Alert {
        <<frozen dataclass>>
        +reading: Reading
        +level: Level
        +message: str
    }

    MonitorStation o-- Sensor
    MonitorStation o-- AlertRule
    MonitorStation o-- Notifier
    MonitorStation --> ReadingStore
    Sensor <|.. ScriptedSensor
    Sensor <|.. RandomWalkSensor
    AlertRule <|.. ThresholdRule
    Notifier <|.. ConsoleNotifier
    Notifier <|.. FileNotifier
    Notifier <|.. MemoryNotifier
    ReadingStore <|.. MemoryStore
    Alert --> Reading
```

## 3. 循序圖：UC-1 + UC-2 一輪取樣

```mermaid
sequenceDiagram
    participant C as 呼叫者（主程式／測試）
    participant S as MonitorStation
    participant K as clock
    participant Sen as Sensor
    participant St as ReadingStore
    participant R as AlertRule
    participant N as Notifier

    C->>S: poll_once()
    S->>K: clock()
    K-->>S: at
    loop 每個感測器
        S->>Sen: read(at)
        Sen-->>S: reading
        S->>St: add(reading)
        loop 每條規則
            S->>R: check(reading)
            R-->>S: Alert 或 None
        end
    end
    loop 每個告警 × 每個通知管道
        S->>N: notify(alert)
    end
    S-->>C: alerts
```

## 4. 職責分配表

| 職責 | 負責者 | 理由 |
|---|---|---|
| 產生讀值（含單位、編號） | Sensor | 只有感測器知道自己的編號與單位（資訊專家） |
| 判斷讀值是否異常 | AlertRule | 門檻資料在規則身上（資訊專家） |
| 建立 Alert | AlertRule | 規則擁有建立 Alert 所需的全部資訊（建立者） |
| 把告警送給人 | Notifier | 每種管道的細節不同，各自封裝 |
| 保存與查詢讀值 | ReadingStore | 儲存方式可能從記憶體換成資料庫 |
| 決定「現在幾點」 | clock（外部傳入） | 讓測試能控制時間 |
| 協調整個流程 | MonitorStation | 控制者：只分派工作，不自己判斷 |
| 冷卻（不洗版） | CooldownNotifier（練習 B） | 包住其他 Notifier，station 不必修改 |

## 5. 設計決定紀錄

### D1：Reading 與 Alert 使用 frozen dataclass
讀值一旦發生就是歷史事實，不應被修改。frozen 讓「意外修改」直接變成錯誤（第 4 週的不變條件）。

### D2：所有合作物件從建構子傳入（依賴注入）
MonitorStation 不自己建立感測器、規則、通知管道與儲存。好處：測試時可以換成 `ScriptedSensor`、`MemoryNotifier`，不需要硬體，也不需要等待。

### D3：時間也是一種依賴
`poll_once()` 不直接呼叫 `datetime.now()`，而是呼叫建構子傳入的 `clock`。測試可以傳入固定時間，讓結果可重現。

### D4：介面用 Protocol 而不是 ABC
新的感測器類別不需要繼承任何東西，只要有 `sensor_id` 和 `read(at)` 就能用（第 8 週的結構化型別）。由 mypy 在開發時檢查。

### D5：剛好等於門檻不告警
來自需求釐清 Q3。這類邊界最容易被 AI 寫錯，所以有專門的測試。
