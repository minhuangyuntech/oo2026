"""通知管道的測試。"""

from pathlib import Path

import pytest

from helpers import make_reading
from lab_monitor import Alert, ConsoleNotifier, FileNotifier, Level

ALERT = Alert(make_reading(5.31, seconds=30), Level.CRITICAL, "V-01 讀值 5.31V 高於上限 5.25V")
EXPECTED = "[2026-12-01 09:00:30] CRITICAL V-01 讀值 5.31V 高於上限 5.25V"


def test_console_notifier_prints_one_line(capsys: pytest.CaptureFixture[str]) -> None:
    ConsoleNotifier().notify(ALERT)
    assert capsys.readouterr().out == EXPECTED + "\n"


def test_file_notifier_appends(tmp_path: Path) -> None:
    path = tmp_path / "alerts.log"
    notifier = FileNotifier(path)
    notifier.notify(ALERT)
    notifier.notify(ALERT)
    assert path.read_text(encoding="utf-8").splitlines() == [EXPECTED, EXPECTED]
