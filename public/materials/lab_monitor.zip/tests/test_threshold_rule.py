"""ThresholdRule 的驗收測試（對應 requirements.md 的 US-2）。"""

import dataclasses

import pytest

from helpers import make_reading
from lab_monitor import Level, ThresholdRule

RULE = ThresholdRule("V-01", low=4.75, high=5.25, level=Level.CRITICAL)


def test_normal_value_gives_no_alert() -> None:
    assert RULE.check(make_reading(5.00)) is None


def test_value_above_high_gives_alert() -> None:
    alert = RULE.check(make_reading(5.31))
    assert alert is not None
    assert alert.level is Level.CRITICAL
    assert alert.sensor_id == "V-01"
    assert "高於上限" in alert.message


def test_value_below_low_gives_alert() -> None:
    alert = RULE.check(make_reading(4.62))
    assert alert is not None
    assert "低於下限" in alert.message


@pytest.mark.parametrize("value", [4.75, 5.25])
def test_value_equal_to_threshold_is_not_alert(value: float) -> None:
    # 需求寫的是「超出」範圍，剛好等於門檻視為正常
    assert RULE.check(make_reading(value)) is None


def test_rule_ignores_other_sensors() -> None:
    assert RULE.check(make_reading(99.0, sensor_id="T-01")) is None


def test_only_high_threshold() -> None:
    rule = ThresholdRule("T-01", high=28.0)
    assert rule.check(make_reading(-50.0, sensor_id="T-01")) is None
    assert rule.check(make_reading(28.1, sensor_id="T-01")) is not None


def test_default_level_is_warning() -> None:
    alert = ThresholdRule("T-01", high=28.0).check(make_reading(30.0, "T-01"))
    assert alert is not None
    assert alert.level is Level.WARNING


def test_rule_needs_at_least_one_threshold() -> None:
    with pytest.raises(ValueError):
        ThresholdRule("V-01")


def test_low_must_be_less_than_high() -> None:
    with pytest.raises(ValueError):
        ThresholdRule("V-01", low=5.0, high=5.0)


def test_rule_is_immutable() -> None:
    with pytest.raises(dataclasses.FrozenInstanceError):
        RULE.high = 10.0  # type: ignore[misc]
