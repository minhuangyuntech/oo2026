"""MonitorStation 的測試：全部使用假的合作物件，不需要硬體、不需要等待。"""

from datetime import datetime, timedelta

import pytest

from helpers import T0
from lab_monitor import (
    Level,
    MemoryNotifier,
    MemoryStore,
    MonitorStation,
    ScriptedSensor,
    SensorError,
    ThresholdRule,
)


def fixed_clock() -> datetime:
    return T0


def make_station(
    voltages: list[float], notifier: MemoryNotifier, store: MemoryStore
) -> MonitorStation:
    return MonitorStation(
        sensors=[ScriptedSensor("V-01", "voltage", "V", voltages)],
        rules=[ThresholdRule("V-01", low=4.75, high=5.25, level=Level.CRITICAL)],
        notifiers=[notifier],
        store=store,
        clock=fixed_clock,
    )


def test_normal_reading_is_stored_without_alert() -> None:
    notifier, store = MemoryNotifier(), MemoryStore()
    station = make_station([5.0], notifier, store)

    assert station.poll_once() == []
    assert notifier.alerts == []
    assert [r.value for r in station.latest("V-01")] == [5.0]


def test_abnormal_reading_is_stored_and_notified() -> None:
    notifier, store = MemoryNotifier(), MemoryStore()
    station = make_station([5.31], notifier, store)

    alerts = station.poll_once()

    assert len(alerts) == 1
    assert notifier.alerts == alerts
    assert store.latest("V-01")[0].value == 5.31


def test_reading_time_comes_from_clock() -> None:
    store = MemoryStore()
    make_station([5.0], MemoryNotifier(), store).poll_once()
    assert store.latest("V-01")[0].at == T0


def test_every_notifier_receives_every_alert() -> None:
    first, second = MemoryNotifier(), MemoryNotifier()
    station = MonitorStation(
        sensors=[ScriptedSensor("V-01", "voltage", "V", [6.0])],
        rules=[ThresholdRule("V-01", high=5.25)],
        notifiers=[first, second],
        store=MemoryStore(),
        clock=fixed_clock,
    )
    station.poll_once()
    assert len(first.alerts) == len(second.alerts) == 1


def test_multiple_polls_use_advancing_time() -> None:
    times = iter([T0, T0 + timedelta(seconds=10)])
    store = MemoryStore()
    station = MonitorStation(
        sensors=[ScriptedSensor("V-01", "voltage", "V", [5.0, 5.1])],
        rules=[],
        notifiers=[],
        store=store,
        clock=lambda: next(times),
    )
    station.poll_once()
    station.poll_once()
    assert [r.at for r in store.latest("V-01", 2)] == [T0, T0 + timedelta(seconds=10)]


def test_duplicate_sensor_ids_are_rejected() -> None:
    with pytest.raises(ValueError):
        MonitorStation(
            sensors=[
                ScriptedSensor("V-01", "voltage", "V", [5.0]),
                ScriptedSensor("V-01", "voltage", "V", [5.0]),
            ],
            rules=[],
            notifiers=[],
            store=MemoryStore(),
        )


def test_scripted_sensor_raises_when_exhausted() -> None:
    station = make_station([], MemoryNotifier(), MemoryStore())
    with pytest.raises(SensorError):
        station.poll_once()
