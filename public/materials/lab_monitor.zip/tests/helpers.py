"""測試共用的小工具。"""

from datetime import datetime, timedelta

from lab_monitor import Reading

T0 = datetime(2026, 12, 1, 9, 0, 0)


def make_reading(
    value: float,
    sensor_id: str = "V-01",
    seconds: float = 0,
    unit: str = "V",
    quantity: str = "voltage",
) -> Reading:
    """建立一筆讀值；seconds 是距離 T0 的秒數。"""
    return Reading(sensor_id, quantity, value, unit, T0 + timedelta(seconds=seconds))
