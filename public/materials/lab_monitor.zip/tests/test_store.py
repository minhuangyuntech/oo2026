"""MemoryStore 的測試（對應 US-3：查詢最近讀值）。"""

import pytest

from helpers import make_reading
from lab_monitor import MemoryStore


def test_latest_returns_oldest_to_newest() -> None:
    store = MemoryStore()
    for i, value in enumerate([5.0, 5.1, 5.2]):
        store.add(make_reading(value, seconds=i * 10))
    assert [r.value for r in store.latest("V-01", 2)] == [5.1, 5.2]


def test_latest_of_unknown_sensor_is_empty() -> None:
    assert MemoryStore().latest("NOPE", 5) == []


def test_asking_more_than_stored_returns_all() -> None:
    store = MemoryStore()
    store.add(make_reading(5.0))
    assert len(store.latest("V-01", 10)) == 1


def test_capacity_drops_oldest() -> None:
    store = MemoryStore(capacity=2)
    for i, value in enumerate([1.0, 2.0, 3.0]):
        store.add(make_reading(value, seconds=i))
    assert [r.value for r in store.latest("V-01", 10)] == [2.0, 3.0]


def test_sensors_are_kept_separately() -> None:
    store = MemoryStore()
    store.add(make_reading(5.0, sensor_id="V-01"))
    store.add(make_reading(25.0, sensor_id="T-01", unit="°C"))
    assert [r.value for r in store.latest("T-01", 5)] == [25.0]


@pytest.mark.parametrize("bad", [0, -1])
def test_invalid_arguments(bad: int) -> None:
    with pytest.raises(ValueError):
        MemoryStore(capacity=bad)
    with pytest.raises(ValueError):
        MemoryStore().latest("V-01", bad)
