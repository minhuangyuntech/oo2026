請先閱讀專案根目錄的 AGENTS.md，並遵守其中的規則。
重點：不可修改測試；只用標準函式庫；介面用 Protocol；時間由外部傳入；不要實作 docs/requirements.md 第 5 節「不做的事」。
