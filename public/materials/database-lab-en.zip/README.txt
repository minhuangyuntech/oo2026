Reading logs with Python, SQLite and MongoDB

Extract the archive into a folder named reading_lab, then open a terminal there. Create and activate the project's .venv as shown on slide 18.

SQL exercises (slides 20–32)
python run_sql_lab.py

Edit sql_basics.sql to experiment with the queries. End each statement with a semicolon and start the next statement on a new line. Each run uses a fresh in-memory SQLite database.

SQLite with Python (slides 33–40)
python sqlite_lab.py

This exercise uses Python's sqlite3 standard library. The program prints the location of its reading_01.db file.

MongoDB with Python (slides 41–51)
With Docker running on your own computer, create the local database service once:
docker run -d --name reading-mongo -p 127.0.0.1:27017:27017 -v reading-data:/data/db mongo:8.0
docker ps

Install the driver in the activated environment, then run the exercise:
python -m pip install "pymongo>=4,<5"
python -c "import pymongo; print(pymongo.version)"
python mongo_lab.py

Each database exercise starts with three records and finishes with two records totaling 75 minutes.
Before rerunning an entire exercise, choose an unused database filename in sqlite_lab.py or an unused collection name in mongo_lab.py. This keeps your earlier records and avoids duplicate IDs.
If the practice container already exists, use docker start reading-mongo. After class, stop it with docker stop reading-mongo.
To use a different MongoDB service, set the MONGODB_URI environment variable to its connection string.
