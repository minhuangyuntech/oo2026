"""Run the SQL lesson one section at a time and print the query results."""
from contextlib import closing
from pathlib import Path
import sqlite3


def run_lesson(con, source):
    pending = ""
    for line in source.splitlines():
        if not pending.strip() and line.startswith("-- Slide "):
            print("\n" + line[3:])
            continue
        pending += line + "\n"
        if sqlite3.complete_statement(pending):
            cursor = con.execute(pending)
            if cursor.description:
                print(" | ".join(col[0] for col in cursor.description))
                for row in cursor:
                    print(" | ".join(str(value) for value in row))
            pending = ""
    if pending.strip():
        raise ValueError("The last SQL statement is incomplete. Check its closing semicolon.")


if __name__ == "__main__":
    source = Path(__file__).with_name("sql_basics.sql").read_text(encoding="utf-8")
    with closing(sqlite3.connect(":memory:", isolation_level=None)) as con:
        run_lesson(con, source)
        print("\nSlide 32 — Bind a query parameter in Python")
        code = "R01"
        sql = "SELECT title, minutes FROM log WHERE code = ?"
        row = con.execute(sql, (code,)).fetchone()
        print(row)
