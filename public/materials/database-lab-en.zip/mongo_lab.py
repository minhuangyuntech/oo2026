import os
from pymongo import MongoClient

uri = os.getenv("MONGODB_URI", "mongodb://127.0.0.1:27017/")
client = MongoClient(uri, serverSelectionTimeoutMS=5000)
print(client.admin.command("ping")["ok"])
books = client["reading_lab"]["readings_01"]

docs = [
    {"_id": "R01", "title": "Seaside Walk", "minutes": 25, "tags": ["Essays"]},
    {"_id": "R02", "title": "City Atlas", "minutes": 40, "tags": ["Travel"]},
    {"_id": "R03", "title": "Forest Journal", "minutes": 15, "tags": ["Nature"]},
]
added = books.insert_many(docs)
print(added.inserted_ids)

condition = {"minutes": {"$gte": 25}}
fields = {"_id": 0, "title": 1, "minutes": 1}
matches = books.find(condition, fields)
for book in matches.sort([("minutes", -1), ("_id", 1)]):
    print(book["title"], book["minutes"])

one = books.find_one({"_id": "R01"})
print(one["title"], one["tags"])
print(books.find_one({"_id": "R99"}))
for book in books.find({"tags": "Essays"}):
    print(book["_id"])

change = {"$inc": {"minutes": 10}, "$set": {"checked": True}}
updated = books.update_one({"_id": "R01"}, change)
print(updated.matched_count, updated.modified_count)
one = books.find_one({"_id": "R01"})
print(one["minutes"], one["checked"])

again = books.update_one(
    {"_id": "R01"}, {"$set": {"checked": True}}
)
print(again.matched_count, again.modified_count)
missing = books.update_one({"_id": "R99"}, {"$set": {"checked": True}})
print(missing.matched_count, missing.modified_count)

target = {"_id": "R03"}
print(books.find_one(target)["title"])
deleted = books.delete_one(target)
print(deleted.deleted_count)
print(books.find_one(target))

group = {"_id": None,
         "count": {"$sum": 1},
         "total": {"$sum": "$minutes"}}
for item in books.aggregate([{"$group": group}]):
    print(item["count"], item["total"])
client.close()
