-- Slide 21 — Define the table with CREATE TABLE
CREATE TABLE log (
    code TEXT NOT NULL PRIMARY KEY,
    reader TEXT NOT NULL,
    title TEXT NOT NULL,
    minutes INTEGER NOT NULL CHECK (minutes >= 0)
);

-- Slide 22 — Add three reading sessions with INSERT INTO
INSERT INTO log (code, reader, title, minutes)
VALUES
    ('R01', 'U1', 'Seaside Walk', 25),
    ('R02', 'U2', 'City Atlas', 40),
    ('R03', 'U1', 'Forest Journal', 15);

-- Slide 23 — Choose columns with SELECT and a table with FROM
SELECT title, minutes
FROM log
ORDER BY code;

-- Slide 24 — Keep matching rows with WHERE
SELECT code, title
FROM log
WHERE reader = 'U1' AND minutes >= 25;

-- Slide 25 — Find the top two with ORDER BY and LIMIT
SELECT title, minutes
FROM log
ORDER BY minutes DESC, code ASC
LIMIT 2;

-- Slide 26 — Summarize rows with COUNT, SUM and AVG
SELECT COUNT(*) AS sessions,
       SUM(minutes) AS total,
       ROUND(AVG(minutes), 1) AS average
FROM log;

-- Slide 27 — Group readers with GROUP BY and filter groups with HAVING
SELECT reader, COUNT(*) AS sessions, SUM(minutes) AS total
FROM log
GROUP BY reader
HAVING COUNT(*) >= 2;

-- Slide 28 — Look up reader names with JOIN
CREATE TABLE readers (id TEXT NOT NULL PRIMARY KEY, name TEXT NOT NULL);
INSERT INTO readers VALUES ('U1', 'Ann'), ('U2', 'Kai');
SELECT r.name, l.title
FROM log AS l
JOIN readers AS r ON r.id = l.reader
ORDER BY l.code;

-- Slide 29 — Correct a reading record with UPDATE
SELECT code, minutes FROM log WHERE code = 'R01';
UPDATE log
SET minutes = minutes + 10
WHERE code = 'R01';
SELECT code, minutes FROM log WHERE code = 'R01';

-- Slide 30 — Try a deletion with BEGIN and undo it with ROLLBACK
BEGIN;
DELETE FROM log WHERE code = 'R03';
SELECT COUNT(*) FROM log;
ROLLBACK;
SELECT COUNT(*) FROM log;

-- Slide 31 — Keep a deletion with DELETE and COMMIT
SELECT title FROM log WHERE code = 'R03';
BEGIN;
DELETE FROM log WHERE code = 'R03';
COMMIT;
SELECT COUNT(*), SUM(minutes) FROM log;
