import sqlite3
from pathlib import Path

path = Path("reading_01.db")
con = sqlite3.connect(path)
print(path.resolve())

con.execute("""
    CREATE TABLE IF NOT EXISTS readings (
        code TEXT NOT NULL PRIMARY KEY,
        title TEXT NOT NULL,
        minutes INTEGER NOT NULL CHECK (minutes >= 0)
    )
""")

records = [
    ("R01", "Seaside Walk", 25),
    ("R02", "City Atlas", 40),
    ("R03", "Forest Journal", 15),
]
sql = "INSERT INTO readings (code, title, minutes) VALUES (?, ?, ?)"
with con:
    con.executemany(sql, records)

query = """
    SELECT title, minutes FROM readings
    WHERE minutes >= ? ORDER BY minutes DESC, code ASC
"""
cursor = con.execute(query, (25,))
for title, minutes in cursor:
    print(title, minutes)

by_code = "SELECT title, minutes FROM readings WHERE code = ?"
row = con.execute(by_code, ("R01",)).fetchone()
print(row)
missing = con.execute(by_code, ("R99",)).fetchone()
print(missing)

with con:
    changed = con.execute(
        "UPDATE readings SET minutes = minutes + ? WHERE code = ?",
        (10, "R01"),
    )
print(changed.rowcount)
print(con.execute(by_code, ("R01",)).fetchone())

try:
    with con:
        con.execute("UPDATE readings SET minutes=99 WHERE code='R01'")
        con.execute("UPDATE readings SET minutes=-1 WHERE code='R02'")
except sqlite3.IntegrityError:
    print("Invalid minutes; transaction rolled back")
print(con.execute(by_code, ("R01",)).fetchone())

with con:
    removed = con.execute("DELETE FROM readings WHERE code = ?", ("R03",))
print(removed.rowcount)
summary = "SELECT COUNT(*), SUM(minutes) FROM readings"
print(con.execute(summary).fetchone())
con.close()
