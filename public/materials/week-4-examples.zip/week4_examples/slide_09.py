# Week 4, slide 9: 繼承中的同名內部屬性
# Python 3.12+

class Base:
    def __init__(self):
        self.__value = "base"

class Child(Base):
    def __init__(self):
        super().__init__()
        self.__value = "child"

c = Child()
print(c._Base__value)
print(c._Child__value)
