# Week 4, slide 38: 浮點價格的額外邊界
# Python 3.12+

from math import isfinite

for value in [float("nan"), float("inf")]:
    print(value < 0, isfinite(value))

print(isinstance(True, int))
print(type(True) is int)
print(round(2.675, 2))
