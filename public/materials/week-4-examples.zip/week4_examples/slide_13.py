# Week 4, slide 13: 建立與修改共用同一個 setter
# Python 3.12+

class Product:
    def __init__(self, name: str, price: float):
        self.name = name
        self.price = price

    @property
    def price(self) -> float:
        return self._price

    @price.setter
    def price(self, value: float) -> None:
        if value < 0:
            raise ValueError("price must be nonnegative")
        self._price = round(value, 2)

book = Product("Book", 100)
print(book.price)

book.price = 120.456
print(book.price)

try:
    book.price = -5
except ValueError:
    print("rejected")
print(book.price)
