# Week 4, slide 36: 同名字典項目無法遮蔽 property
# Python 3.12+

class Item:
    def __init__(self):
        self._price = 100

    @property
    def price(self):
        return self._price

x = Item()
x.__dict__["price"] = 999
print(x.price)
print(vars(x)["price"])
