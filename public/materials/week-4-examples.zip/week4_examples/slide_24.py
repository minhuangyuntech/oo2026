# Week 4, slide 24: 提款先檢查可用餘額
# Python 3.12+

class BankAccount:
    def __init__(self, account_number, balance=0):
        if not isinstance(account_number, str):
            raise TypeError("account number must be str")
        if not account_number.strip():
            raise ValueError("account number required")
        if type(balance) is not int:
            raise TypeError("balance must be int")
        if balance < 0:
            raise ValueError("negative balance")
        self._account_number = account_number.strip()
        self._balance = balance
        self._transactions = []

    @property
    def account_number(self):
        return self._account_number

    @property
    def balance(self):
        return self._balance

    @property
    def transactions(self):
        return tuple(self._transactions)

    @staticmethod
    def _validate_amount(amount):
        if type(amount) is not int:
            raise TypeError("amount must be int")
        if amount <= 0:
            raise ValueError("amount must be positive")

    def deposit(self, amount):
        self._validate_amount(amount)
        self._balance += amount
        self._transactions.append(("deposit", amount))

    def withdraw(self, amount):
        self._validate_amount(amount)
        if amount > self._balance:
            raise ValueError("insufficient balance")
        self._balance -= amount
        self._transactions.append(("withdraw", amount))
a = BankAccount("A001", 100)
a.withdraw(30)
print(a.balance)

