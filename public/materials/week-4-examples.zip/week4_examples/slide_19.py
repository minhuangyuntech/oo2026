# Week 4, slide 19: 計算屬性由現有狀態推導
# Python 3.12+

class Rectangle:
    def __init__(self, width, height):
        self.width = width
        self.height = height

    @property
    def area(self):
        return self.width * self.height

r = Rectangle(3, 4)
print(r.area)
r.width = 5
print(r.area)
