# Week 4, slide 29: tuple 不會遞迴凍結元素
# Python 3.12+

internal = [{"amount": 100}]
snapshot = tuple(internal)

snapshot[0]["amount"] = -999
print(internal)
print(snapshot[0] is internal[0])
