# Week 4, slide 41: 公開語法與內部表示可以分離
# Python 3.12+

class Length:
    def __init__(self, meters):
        self._millimeters = round(meters * 1000)

    @property
    def meters(self):
        return self._millimeters / 1000

length = Length(1.25)
print(length.meters)
print(vars(length))
