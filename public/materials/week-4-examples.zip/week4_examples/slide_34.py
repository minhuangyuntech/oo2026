# Week 4, slide 34: property 的函式形式
# Python 3.12+

class Temperature:
    def get_celsius(self):
        return self._celsius

    def set_celsius(self, value):
        self._celsius = value

    celsius = property(get_celsius, set_celsius)

t = Temperature()
t.celsius = 25
print(t.celsius)
print(Temperature.celsius.fget.__name__)
