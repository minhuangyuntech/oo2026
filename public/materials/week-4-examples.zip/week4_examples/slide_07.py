# Week 4, slide 7: 單底線表示非公開慣例
# Python 3.12+

class Product:
    def __init__(self, price):
        self._price = price

p = Product(100)
print(p._price)
p._price = -1
print(p._price)
