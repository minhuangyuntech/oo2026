# Week 4, slide 8: 雙底線與名稱修飾
# Python 3.12+

class Vault:
    def __init__(self):
        self.__value = 7

v = Vault()
print(vars(v))
print(hasattr(v, "__value"))
print(v._Vault__value)
