# Week 4, slide 37: 刪除屬性的明確語意
# Python 3.12+

class Cache:
    @property
    def value(self):
        return self._value

    @value.setter
    def value(self, value):
        self._value = value

    @value.deleter
    def value(self):
        del self._value

c = Cache()
c.value = 10
del c.value
print(hasattr(c, "value"))
