# Week 4, slide 18: 唯讀屬性仍可能暴露可變資料
# Python 3.12+

class Notebook:
    def __init__(self):
        self._notes = []

    @property
    def notes(self):
        return self._notes

n = Notebook()
n.notes.append("external change")
print(n.notes)
