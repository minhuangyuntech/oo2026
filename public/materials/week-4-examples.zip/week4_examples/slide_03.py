# Week 4, slide 3: 第三週留下的問題：直接改寫狀態
# Python 3.12+

class Account:
    def __init__(self, balance):
        if balance < 0:
            raise ValueError("negative balance")
        self.balance = balance

account = Account(100)
account.balance = -999
print(account.balance)
