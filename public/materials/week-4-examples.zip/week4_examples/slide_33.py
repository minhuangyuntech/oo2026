# Week 4, slide 33: 區間以單一操作更新邊界
# Python 3.12+

class Interval:
    def __init__(self, start, end):
        self.set_bounds(start, end)

    def set_bounds(self, start, end):
        if type(start) is not int or type(end) is not int:
            raise TypeError("integer bounds required")
        if start > end:
            raise ValueError("invalid interval")
        self._start, self._end = start, end

    @property
    def bounds(self):
        return self._start, self._end

r = Interval(0, 10)
r.set_bounds(20, 30)
print(r.bounds)
