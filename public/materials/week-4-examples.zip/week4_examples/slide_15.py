# Week 4, slide 15: 先修改再驗證會留下非法狀態
# Python 3.12+

class BadProduct:
    def __init__(self):
        self._price = 100

    def set_price(self, value):
        self._price = value
        if value < 0:
            raise ValueError("negative price")

p = BadProduct()
try:
    p.set_price(-5)
except ValueError:
    print("rejected")
print(p._price)
