# Week 4, slide 31: 傳入資料也可能形成共享
# Python 3.12+

class Tags:
    def __init__(self, values):
        self._values = list(values)

    @property
    def values(self):
        return tuple(self._values)

source = ["python"]
t = Tags(source)
source.append("oop")
print(t.values)
