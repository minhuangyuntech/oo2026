# Week 4, slide 17: 只有 getter 的唯讀屬性
# Python 3.12+

class Account:
    def __init__(self, number):
        self._number = number

    @property
    def account_number(self):
        return self._number

a = Account("A001")
print(a.account_number)
try:
    a.account_number = "A002"
except AttributeError:
    print("read-only")
