from math import isfinite
class StrictProduct:
    def __init__(self, price):
        self.price = price
    @property
    def price(self):
        return self._price
    @price.setter
    def price(self, value):
        if type(value) not in (int, float):
            raise TypeError("numeric price required")
        value = float(value)
        if not isfinite(value) or value < 0:
            raise ValueError("invalid price")
        self._price = round(value, 2)
