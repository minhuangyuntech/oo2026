# Week 4, slide 27: 回傳內部 list 會洩漏修改入口
# Python 3.12+

class Ledger:
    def __init__(self):
        self._entries = [100, -20]

    @property
    def entries(self):
        return self._entries

ledger = Ledger()
external = ledger.entries
external.clear()
print(ledger.entries)
