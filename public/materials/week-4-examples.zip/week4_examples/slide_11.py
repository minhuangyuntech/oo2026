# Week 4, slide 11: 課程網站的 Product.price
# Python 3.12+

class Product:
    def __init__(self, name: str, price: float):
        self.name = name
        self.price = price

    @property
    def price(self) -> float:
        return self._price

    @price.setter
    def price(self, value: float) -> None:
        if value < 0:
            raise ValueError("price must be nonnegative")
        self._price = round(value, 2)

book = Product("Python OOP", 580.126)
print(book.price)
