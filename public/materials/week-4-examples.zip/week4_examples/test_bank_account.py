import unittest

from bank_account import BankAccount


class BankAccountContractTests(unittest.TestCase):
    def setUp(self):
        self.account = BankAccount('A001', 100)

    def test_initial_state(self):
        self.assertEqual(self.account.account_number, 'A001')
        self.assertEqual(self.account.balance, 100)
        self.assertEqual(self.account.transactions, ())

    def test_account_number_validation(self):
        with self.assertRaises(TypeError):
            BankAccount(1)
        with self.assertRaises(ValueError):
            BankAccount('   ')
        self.assertEqual(BankAccount(' A001 ').account_number, 'A001')

    def test_initial_balance_validation(self):
        for value in (True, '100', 1.5):
            with self.subTest(value=value), self.assertRaises(TypeError):
                BankAccount('A001', value)
        with self.assertRaises(ValueError):
            BankAccount('A001', -1)

    def test_deposit_updates_balance_and_history(self):
        self.account.deposit(20)
        self.assertEqual(self.account.balance, 120)
        self.assertEqual(self.account.transactions, (('deposit', 20),))

    def test_withdraw_updates_balance_and_history(self):
        self.account.withdraw(30)
        self.assertEqual(self.account.balance, 70)
        self.assertEqual(self.account.transactions, (('withdraw', 30),))

    def test_withdraw_exact_balance(self):
        self.account.withdraw(100)
        self.assertEqual(self.account.balance, 0)

    def test_invalid_values_leave_state_unchanged(self):
        self.account.deposit(10)
        before = (self.account.balance, self.account.transactions)
        for method in (self.account.deposit, self.account.withdraw):
            for amount in (0, -1):
                with self.subTest(method=method.__name__, amount=amount):
                    with self.assertRaises(ValueError):
                        method(amount)
                    self.assertEqual((self.account.balance, self.account.transactions), before)

    def test_invalid_types_leave_state_unchanged(self):
        before = (self.account.balance, self.account.transactions)
        for method in (self.account.deposit, self.account.withdraw):
            for amount in (True, '20', 20.0, None):
                with self.subTest(method=method.__name__, amount=amount):
                    with self.assertRaises(TypeError):
                        method(amount)
                    self.assertEqual((self.account.balance, self.account.transactions), before)

    def test_overdraft_leaves_state_unchanged(self):
        self.account.deposit(10)
        before = (self.account.balance, self.account.transactions)
        with self.assertRaises(ValueError):
            self.account.withdraw(111)
        self.assertEqual((self.account.balance, self.account.transactions), before)

    def test_public_properties_reject_assignment(self):
        for name, value in [('account_number', 'A002'), ('balance', -999), ('transactions', [])]:
            with self.subTest(name=name), self.assertRaises(AttributeError):
                setattr(self.account, name, value)

    def test_snapshot_does_not_follow_future_changes(self):
        self.account.deposit(20)
        snapshot = self.account.transactions
        self.account.withdraw(10)
        self.assertEqual(snapshot, (('deposit', 20),))
        self.assertEqual(len(self.account.transactions), 2)

    def test_snapshot_records_cannot_be_mutated(self):
        self.account.deposit(20)
        snapshot = self.account.transactions
        with self.assertRaises(TypeError):
            snapshot[0][1] = 999
        self.assertEqual(self.account.transactions, (('deposit', 20),))

    def test_separate_accounts_have_separate_history(self):
        other = BankAccount('A002', 50)
        self.account.deposit(20)
        self.assertEqual(other.balance, 50)
        self.assertEqual(other.transactions, ())


if __name__ == '__main__':
    unittest.main()
