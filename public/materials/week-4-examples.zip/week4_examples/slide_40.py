# Week 4, slide 40: Decimal 與明確的捨入政策
# Python 3.12+

from decimal import Decimal, ROUND_HALF_UP

price = Decimal("2.675")
rounded = price.quantize(
    Decimal("0.01"),
    rounding=ROUND_HALF_UP,
)
print(rounded)
print(Decimal("0.1") + Decimal("0.2"))
