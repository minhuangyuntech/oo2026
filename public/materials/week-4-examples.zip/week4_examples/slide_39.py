# Week 4, slide 39: 較完整的價格 setter
# Python 3.12+

from math import isfinite
class StrictProduct:
    def __init__(self, price):
        self.price = price
    @property
    def price(self):
        return self._price
    @price.setter
    def price(self, value):
        if type(value) not in (int, float):
            raise TypeError("numeric price required")
        value = float(value)
        if not isfinite(value) or value < 0:
            raise ValueError("invalid price")
        self._price = round(value, 2)
p=StrictProduct(100)
print(p.price)
for x in [True, float("nan")]:
    try:
        p.price=x
    except (TypeError, ValueError) as e:
        print(type(e).__name__)

