# Week 4, slide 14: setter 的遞迴陷阱
# Python 3.12+

class BadProduct:
    @property
    def price(self):
        return self._price

    @price.setter
    def price(self, value):
        self.price = value

try:
    BadProduct().price = 10
except RecursionError:
    print("recursive setter")
