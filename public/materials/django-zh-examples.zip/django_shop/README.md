# Django 網站入門：商品目錄

配合「Django_從零建立網站與檔案解析-v3.pptx」。Python 3.12、Django 5.2 系列。

## 啟動完成版範例（Windows PowerShell）

在這個含 manage.py 的目錄執行：

```powershell
python -m venv .venv
.\.venv\Scripts\python -m pip install -r requirements.txt
.\.venv\Scripts\python manage.py migrate
.\.venv\Scripts\python manage.py runserver
```

瀏覽器開啟 http://127.0.0.1:8000/products/ 。停止伺服器時按 Ctrl+C。

這是完成版專案，不用再次執行 startproject 或 startapp。已附 migration，第一次使用僅需 migrate。
不附資料庫、虛擬環境、共用帳密或使用者資料。列表一開始沒有商品，可直接在 `/products/new/` 新增。

macOS / Linux：以 `python3 -m venv .venv` 建立環境，再使用 `.venv/bin/python` 執行上述命令。

## 管理後台與測試

```powershell
.\.venv\Scripts\python manage.py createsuperuser
.\.venv\Scripts\python manage.py test catalog
.\.venv\Scripts\python manage.py check
```

管理後台網址：`http://127.0.0.1:8000/admin/`。由使用者自行建立管理員密碼。

## 路由

| 網址 | 功能 |
|---|---|
| `/products/hello/` | 最基本的文字回應 |
| `/products/` | 商品列表 |
| `/products/new/` | 新增商品表單 |
| `/products/1/` | 主鍵為 1 的商品詳細頁；不存在時顯示 404 |
| `/admin/` | Django 管理後台 |

根路徑 `/` 未定義，因此回傳 404。

## 每個檔案的用途

| 位置 | 來源 | 用途 |
|---|---|---|
| `manage.py` | startproject | 執行管理命令並選擇 Django 設定 |
| `config/__init__.py` | startproject | 專案設定套件標記 |
| `config/settings.py` | startproject 後修改 | app、資料庫、模板、中介軟體、語言、時區等設定 |
| `config/urls.py` | startproject 後修改 | 網站總路由，接入 catalog 與 admin |
| `config/wsgi.py` | startproject | WSGI 伺服器入口 |
| `config/asgi.py` | startproject | ASGI 伺服器入口 |
| `catalog/__init__.py` | startapp | app 套件標記 |
| `catalog/apps.py` | startapp | CatalogConfig 設定類別 |
| `catalog/models.py` | startapp 後修改 | Product 資料欄位、in_stock 屬性與文字表示 |
| `catalog/views.py` | startapp 後修改 | 文字回應、列表、詳細頁與新增商品處理 |
| `catalog/admin.py` | startapp 後修改 | Product 後台註冊、顯示欄位與搜尋 |
| `catalog/tests.py` | startapp 後修改 | 八項行為測試 |
| `catalog/migrations/__init__.py` | startapp | migration 套件標記 |
| `catalog/migrations/0001_initial.py` | makemigrations | 建立 Product 資料表的變更描述 |
| `catalog/urls.py` | 自行新增 | catalog app 的路由與命名空間 |
| `catalog/forms.py` | 自行新增 | ProductForm 的欄位選擇、標籤與驗證 |
| `catalog/templates/catalog/base.html` | 自行新增 | 共用 HTML 骨架、CSS、導覽與頁尾 |
| `catalog/templates/catalog/product_list.html` | 自行新增 | 顯示商品列表與庫存狀態 |
| `catalog/templates/catalog/product_detail.html` | 自行新增 | 顯示單筆商品內容 |
| `catalog/templates/catalog/product_form.html` | 自行新增 | POST 表單、CSRF token 與驗證訊息 |
| `catalog/static/catalog/site.css` | 自行新增 | 網站版面、字型與顏色 |
| `requirements.txt` | 自行新增 | Django 版本範圍 |
| `.gitignore` | 自行新增 | 忽略本機環境、快取、資料庫等檔案 |
| `README.md` | 自行新增 | 本檔，記錄執行方式與檔案索引 |

執行時另產生 `.venv/`、`__pycache__/` 與 `db.sqlite3`，不包含在範例包中。

## 範例範圍

本例為本機教學網站。`DEBUG=True` 與固定教學用 SECRET_KEY 不適合正式部署。
新增商品頁尚未限制登入權限，部署前須安排使用者驗證與授權。
ModelForm 會檢查價格，但直接使用 ORM 儲存時仍須安排驗證與必要的資料庫約束。
本例沒有上傳功能、`.env` 載入器或正式部署組態。
