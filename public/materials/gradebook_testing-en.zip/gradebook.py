"""Grade book: the sample class for the Python testing lesson.

GradeBook keeps one score per student. It checks that scores are valid, computes the average,
lists students who passed, and saves to or loads from CSV.
"""

import csv
from pathlib import Path

PASSING_SCORE = 60


def letter_grade(score: int) -> str:
    """Convert a score from 0 to 100 to a letter grade: 90+ A, 80+ B, 70+ C, 60+ D, otherwise F."""
    if not 0 <= score <= 100:
        raise ValueError(f"score must be between 0 and 100: {score}")
    if score >= 90:
        return "A"
    if score >= 80:
        return "B"
    if score >= 70:
        return "C"
    if score >= 60:
        return "D"
    return "F"


class GradeBook:
    def __init__(self) -> None:
        self._scores: dict[str, int] = {}

    def add(self, student_id: str, score: int) -> None:
        if not student_id:
            raise ValueError("student ID must not be empty")
        if not 0 <= score <= 100:
            raise ValueError(f"score must be between 0 and 100: {score}")
        if student_id in self._scores:
            raise ValueError(f"{student_id} already has a score")
        self._scores[student_id] = score

    def score_of(self, student_id: str) -> int:
        return self._scores[student_id]

    def __len__(self) -> int:
        return len(self._scores)

    def average(self) -> float:
        if not self._scores:
            raise ValueError("the grade book has no scores")
        return sum(self._scores.values()) / len(self._scores)

    def passed(self) -> list[str]:
        """Return the IDs of students who passed (60 or more), sorted by ID."""
        return sorted(sid for sid, score in self._scores.items() if score >= PASSING_SCORE)

    def save_csv(self, path: Path) -> None:
        with path.open("w", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)
            writer.writerow(["student_id", "score"])
            for sid, score in sorted(self._scores.items()):
                writer.writerow([sid, score])

    @classmethod
    def load_csv(cls, path: Path) -> "GradeBook":
        book = cls()
        with path.open(newline="", encoding="utf-8") as file:
            for row in csv.DictReader(file):
                book.add(row["student_id"], int(row["score"]))
        return book
