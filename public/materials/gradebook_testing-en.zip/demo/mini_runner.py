"""Mini test runner: the three things a test framework does: collect, run, report.

Run in the project folder: python -m demo.mini_runner
"""

import inspect

from demo import sample_tests


def collect(module):
    """Collect: find functions whose names start with test_."""
    return [(name, func) for name, func in inspect.getmembers(module, inspect.isfunction)
            if name.startswith("test_")]


def run(tests):
    """Run and report: each test runs on its own; one failure does not stop the next."""
    results = {"passed": 0, "failed": 0, "error": 0}
    for name, func in tests:
        try:
            func()
        except AssertionError as exc:
            results["failed"] += 1
            print(f"FAIL  {name}: {exc}")
        except Exception as exc:
            results["error"] += 1
            print(f"ERROR {name}: {type(exc).__name__} {exc}")
        else:
            results["passed"] += 1
            print(f"PASS  {name}")
    print(", ".join(f"{count} {kind}" for kind, count in results.items()))


if __name__ == "__main__":
    run(collect(sample_tests))
