"""Tests for the mini runner: one passes, one fails, one errors."""

from gradebook import GradeBook


def test_average_of_two_scores():
    book = GradeBook()                 # Arrange
    book.add("A001", 80)
    book.add("A002", 90)
    result = book.average()            # Act
    assert result == 85                # Assert


def test_passed_list():
    book = GradeBook()
    book.add("A001", 59)
    book.add("A002", 60)
    assert book.passed() == ["A001", "A002"], "expected 59 to pass too"


def test_score_of_unknown_student():
    book = GradeBook()
    assert book.score_of("Z999") == 0
