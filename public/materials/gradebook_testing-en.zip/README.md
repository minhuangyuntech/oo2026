# Grade book testing example (Python testing: principles and methods)

Practice unittest and pytest with a grade book class, `GradeBook`. The program uses only the standard library; the tests need pytest.

## Setup

```bash
python -m venv .venv
# Windows PowerShell
.venv\Scripts\Activate.ps1
# macOS / Linux
source .venv/bin/activate

pip install -r requirements.txt
```

## Run

Run every command in this folder.

```bash
python -m demo.mini_runner                          # mini test runner: 1 passed, 1 failed, 1 error
python -m unittest discover -s tests_unittest -v    # unittest version: 6 tests
pytest -v                                           # pytest version: 21 tests
pytest tests_unittest                               # pytest can also run unittest tests
```

## Files

| Path | Contents |
|---|---|
| `gradebook.py` | The `GradeBook` class and `letter_grade()` |
| `demo/mini_runner.py` | A mini test runner: collect, run, report |
| `demo/sample_tests.py` | Tests for the mini runner (one fails and one errors on purpose) |
| `tests_unittest/` | unittest style: `TestCase`, `setUp`, `assertRaises`, `subTest` |
| `tests/conftest.py` | The shared pytest fixture `book` |
| `tests/test_gradebook.py` | pytest style: fixtures, `pytest.raises`, `pytest.approx`, `tmp_path` |
| `tests/test_letter_grade.py` | `@pytest.mark.parametrize` for every boundary |
| `exercises/boundaries/` | Class exercise: find the bug in `grading.py` with boundary values |
| `pyproject.toml` | pytest settings: `pythonpath`, `testpaths` |

## Class exercise

```bash
pytest exercises/boundaries -v   # everything passes at first, but grading.py hides a bug
```

Add boundary-value tests to `test_grading.py`. When you see red, fix `grading.py`. Do not change the spec or delete tests to make them pass.
