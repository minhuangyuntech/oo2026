"""Shared fixtures in tests/; every test file can use them directly."""

import pytest

from gradebook import GradeBook


@pytest.fixture
def book() -> GradeBook:
    """A grade book with two students; each test gets a new one."""
    gradebook = GradeBook()
    gradebook.add("A001", 80)
    gradebook.add("A002", 90)
    return gradebook
