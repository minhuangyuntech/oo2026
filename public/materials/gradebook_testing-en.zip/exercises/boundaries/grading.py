"""Exercise: this letter_grade hides a boundary bug.

Spec: 90+ A, 80+ B, 70+ C, 60+ D, otherwise F;
scores outside 0 to 100 raise ValueError.
"""


def letter_grade(score: int) -> str:
    if not 0 <= score <= 100:
        raise ValueError(f"score must be between 0 and 100: {score}")
    if score >= 90:
        return "A"
    if score > 80:
        return "B"
    if score >= 70:
        return "C"
    if score >= 60:
        return "D"
    return "F"
