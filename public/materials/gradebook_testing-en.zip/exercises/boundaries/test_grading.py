"""Exercise: add boundary-value tests with parametrize and find the bug in grading.py.

1. Run pytest exercises/boundaries -v. The current tests all pass.
2. Complete the data for test_boundaries: the upper and lower bound of each grade, and -1 and 101.
3. When you see red, fix grading.py so that every test passes.
"""

import pytest

from grading import letter_grade


def test_typical_scores() -> None:
    assert letter_grade(95) == "A"
    assert letter_grade(85) == "B"
    assert letter_grade(75) == "C"
    assert letter_grade(65) == "D"
    assert letter_grade(30) == "F"


@pytest.mark.parametrize(
    "score, expected",
    [
        (100, "A"),
        # TODO: add the other boundary values
    ],
)
def test_boundaries(score: int, expected: str) -> None:
    assert letter_grade(score) == expected
