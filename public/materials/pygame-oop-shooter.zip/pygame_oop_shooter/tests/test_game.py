"""驗證可觀察的遊戲行為；使用 SDL dummy 驅動，不開啟視窗。"""

import os
import sys
from pathlib import Path
import unittest

os.environ["SDL_VIDEODRIVER"] = "dummy"
os.environ["PYGAME_HIDE_SUPPORT_PROMPT"] = "1"
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pygame
from actors import Actor, Bullet, Enemy, Player
from game import Game
from settings import PLAY_AREA, TARGET_SCORE
import view


class GameTests(unittest.TestCase):
    def setUp(self):
        self.game = Game(seed=12)

    def tearDown(self):
        pygame.quit()

    def empty_enemies(self):
        for enemy in self.game.enemies.sprites():
            enemy.kill()

    def bullet_on(self, enemy):
        bullet = Bullet("test", self.game.player)
        bullet.rect.center = enemy.rect.center
        bullet.pos.update(enemy.pos)
        self.game.bullets.add(bullet)
        self.game.all_sprites.add(bullet)
        return bullet

    def test_instances_share_class_but_keep_independent_state(self):
        a, b = list(self.game.enemies)[:2]
        self.assertIs(type(a), type(b))
        a.take_hit(1)
        self.assertEqual(b.hp, 2)
        self.assertNotEqual(a.velocity.y, b.velocity.y)

    def test_group_references_the_same_object(self):
        enemy = next(iter(self.game.enemies))
        self.assertIn(enemy, self.game.all_sprites)
        self.assertEqual(len(self.game.all_sprites), 4)
        self.assertTrue(all(isinstance(actor, Actor) for actor in self.game.all_sprites))

    def test_bullet_owner_identity_and_fire_cooldown(self):
        bullet = self.game.try_shoot()
        self.assertIs(bullet.owner, self.game.player)
        self.assertIsNone(self.game.try_shoot())
        self.game.player.update(0.3)
        second = self.game.try_shoot()
        self.assertIsNot(bullet, second)
        self.assertEqual(len(self.game.bullets), 2)

    def test_movement_is_independent_of_frame_rate(self):
        players = [Player((200, 300)), Player((200, 300))]
        for player, fps in zip(players, (30, 60)):
            player.set_direction(1, 0)
            for _ in range(fps):
                player.update(1 / fps)
        self.assertAlmostEqual(players[0].pos.x, players[1].pos.x)
        self.assertAlmostEqual(players[0].pos.x, 530)
        players[0].set_direction(1, -1)
        players[0].update(10)
        self.assertTrue(PLAY_AREA.contains(players[0].rect))

    def test_polymorphic_update_moves_each_actor_differently(self):
        player = self.game.player
        player.set_direction(1, 0)
        enemy = next(iter(self.game.enemies))
        bullet = self.game.try_shoot()
        px, ey, by = player.pos.x, enemy.pos.y, bullet.pos.y
        self.game.all_sprites.update(0.01)
        self.assertGreater(player.pos.x, px)
        self.assertGreater(enemy.pos.y, ey)
        self.assertLess(bullet.pos.y, by)

    def test_collision_awards_score_once_and_removes_both(self):
        self.empty_enemies()
        enemy = self.game.spawn_enemy((300, 300), speed=0, hp=1)
        bullet = self.bullet_on(enemy)
        self.game.resolve_collisions()
        self.game.resolve_collisions()
        self.assertEqual(self.game.score, 10)
        self.assertFalse(enemy.alive())
        self.assertFalse(bullet.alive())
        self.assertIs(bullet.owner, self.game.player)  # kill() 後參考仍可使用。

    def test_armored_enemy_takes_two_hits(self):
        self.empty_enemies()
        enemy = self.game.spawn_enemy((300, 300), speed=0, hp=2)
        self.bullet_on(enemy)
        self.game.resolve_collisions()
        self.assertEqual(enemy.hp, 1)
        self.assertEqual(self.game.score, 0)
        self.bullet_on(enemy)
        self.game.resolve_collisions()
        self.assertEqual(self.game.score, 10)

    def test_one_bullet_cannot_destroy_two_overlapping_enemies(self):
        self.empty_enemies()
        a = self.game.spawn_enemy((300, 300), 0, 1)
        self.game.spawn_enemy((300, 300), 0, 1)
        self.bullet_on(a)
        self.game.resolve_collisions()
        self.assertEqual(len(self.game.enemies), 1)
        self.assertEqual(self.game.score, 10)

    def test_collision_and_escape_damage_have_short_invulnerability(self):
        self.empty_enemies()
        self.game.spawn_enemy(self.game.player.rect.center, 0, 1)
        self.game.spawn_enemy((200, PLAY_AREA.bottom + 50), 0, 1)
        self.game.resolve_collisions()
        self.assertEqual(self.game.player.hp, 2)
        self.assertFalse(self.game.enemies)
        self.game.player.update(1)
        self.game.spawn_enemy((200, PLAY_AREA.bottom + 50), 0, 1)
        self.game.resolve_collisions()
        self.assertEqual(self.game.player.hp, 1)

    def test_bullet_expires_from_all_groups(self):
        bullet = self.game.try_shoot()
        bullet.update(2)
        self.assertNotIn(bullet, self.game.bullets)
        self.assertNotIn(bullet, self.game.all_sprites)

    def test_pause_single_step_resume_and_restart(self):
        key = lambda value: pygame.event.Event(pygame.KEYDOWN, key=value)
        self.game.handle_events([key(pygame.K_RETURN), key(pygame.K_p)])
        self.assertEqual(self.game.state, "paused")
        enemy = next(iter(self.game.enemies))
        before = enemy.pos.y
        self.game.tick(0.5, (1, 0), True)
        self.assertEqual(enemy.pos.y, before)
        self.assertEqual(len(self.game.bullets), 0)
        self.game.handle_events([key(pygame.K_n)])
        self.assertGreater(enemy.pos.y, before)
        self.assertEqual(self.game.state, "paused")
        self.game.handle_events([key(pygame.K_p)])
        self.assertEqual(self.game.state, "playing")
        old_sprites = self.game.all_sprites.sprites()
        self.game.handle_events([key(pygame.K_r)])
        self.assertEqual(self.game.state, "ready")
        self.assertEqual(len(self.game.all_sprites), 4)
        self.assertTrue(all(not sprite.alive() for sprite in old_sprites))

    def test_win_loss_stop_simulation(self):
        self.game.score = TARGET_SCORE
        self.game.state = "playing"
        self.game.tick(0.01)
        self.assertEqual(self.game.state, "won")
        self.game.tick(0.5, (1, 0), True)
        self.assertFalse(self.game.bullets)
        self.game.reset()
        self.game.player.hp = 0
        self.game.state = "playing"
        self.game.tick(0.01)
        self.assertEqual(self.game.state, "lost")

    def test_all_display_states_can_render(self):
        for lang in ("zh", "en", "ja"):
            self.game = Game(seed=12, lang=lang)
            for state in ("ready", "playing", "paused", "won", "lost"):
                self.game.state = state
                view.draw(self.game)

    def test_complete_event_loop_handles_quit(self):
        pygame.event.post(pygame.event.Event(pygame.QUIT))
        self.game.run()
        self.assertFalse(self.game.running)


if __name__ == "__main__":
    unittest.main()
