# 星際物件實驗室｜Pygame 物件導向射擊遊戲

用玩家、敵人、子彈與遊戲控制器，理解類別、物件、繼承、多型、參考及生命週期。

**先開啟 [圖解講義](docs/index.html)**，再執行遊戲。講義可離線閱讀與列印為 PDF。程式中的繁體中文註解與畫面標籤可直接對照。

## 安裝與執行

建議使用 **Python 3.12（64 位元）**，已測試 Python 3.12.14、Pygame 2.6.1。解壓縮後，在 `pygame_oop_shooter` 資料夾開啟終端機：

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe main.py
```

不必啟用虛擬環境或修改 PowerShell 執行原則。如果系統的 Python 指向其他版本，可以將第一行改為 `py -3.12 -m venv .venv`。

macOS / Linux：

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python main.py
```

所有遊戲圖形由 Pygame 畫出，不需要圖片素材、音效、帳號或 API 金鑰。安裝套件需連線，遊戲可離線執行。視窗為 1200 × 800。

中文優先使用 Windows 微軟正黑體、macOS PingFang 或 Linux Noto Sans CJK。Linux 若出現方框字，請先安裝 Noto CJK 字型；字型選擇在 `view.py` 的 `load_fonts()`。

## 操作與規則

| 操作 | 按鍵 |
|---|---|
| 開始 | Enter |
| 移動 | 方向鍵或 WASD |
| 射擊 | 按住 Space |
| 暫停／繼續 | P |
| 暫停時前進一影格 | N |
| 顯示／隱藏物件名稱與碰撞框 | Tab |
| 重建一局，回到開始畫面 | R |
| 離開 | Esc |

每擊破一個敵人得 10 分，200 分過關。紅色敵人 HP=1，紫色敵人 HP=2；兩者都是 `Enemy` 的實例。玩家有 3 點生命；撞到敵人或讓敵人穿過底部防線會扣血，扣血後短暫無敵 0.8 秒。勝利或生命歸零後停止模擬。

按 P 後可看清物件參考、生命與數量，再按 N 觀察一次 `update(dt)`。標籤中的 `E01`、`B01` 是物件的 `name` 屬性，並不是程式中的變數名稱。

## 五個自訂類別

| 類別 | 責任 | 畫面對應 |
|---|---|---|
| `Actor` | 共用位置、圖片、碰撞矩形、速度與移動 | 不直接建立實例，是角色共同父類別 |
| `Player` | 移動、射擊、生命與射擊間隔 | 綠色玩家 |
| `Enemy` | 自己的生命、下降速度與受擊行為 | 多個紅色／紫色敵人 |
| `Bullet` | 往上移動、傷害與發射者參考 | 多個黃色子彈 |
| `Game` | 管理群組、處理碰撞、分數與狀態 | 整局遊戲的協調者 |

`Actor` 繼承 Pygame 提供的 `Sprite`，`Player`、`Enemy`、`Bullet` 再繼承 `Actor`。`Game` 使用這些物件，不繼承它們。`Sprite` 和 `Group` 是套件類別，不算在五個自訂類別內。

```mermaid
classDiagram
    Sprite <|-- Actor
    Actor <|-- Player
    Actor <|-- Enemy
    Actor <|-- Bullet
    Game "1" --> "1" Player : player
    Game "1" --> "0..*" Enemy : enemies 群組
    Game "1" --> "0..*" Bullet : bullets 群組
    Player ..> Bullet : shoot 建立
    Bullet "0..*" --> "1" Player : owner
```

實線箭頭是使用／參考關係；空心三角形是繼承；虛線箭頭是建立時的依賴。群組關係簡化顯示；實際 `Game.enemies` 與 `Game.bullets` 都是 `pygame.sprite.Group`。這裡不用菱形宣稱 Python 會自動銷毀其他物件。

## 程式閱讀順序

1. `settings.py`：視窗、速度與目標分數。
2. `actors.py`：共同父類別與三種角色。
3. `game.py`：建立物件 → 加入群組 → 更新 → 碰撞 → 移除。
4. `main.py`：程式入口與結束時的清理。
5. `view.py`：繪製畫面、物件標籤、類別關係及即時資訊。

HUD、分數文字與背景是資料的呈現，沒有另建類別。畫面繪製集中在 `view.py`；改顏色不會改動碰撞或計分規則。

## 幾個容易混淆的地方

- **同一個類別，不同的狀態**：每個 `Enemy` 都有獨立的 `hp`、`pos`、`velocity`。
- **多型**：`all_sprites.update(dt)` 逐一呼叫角色的 `update`。玩家與子彈覆寫方法，敵人沿用 `Actor.update`。
- **群組存放參考**：同一個敵人同時屬於 `enemies` 與 `all_sprites`，不會多生一隻。
- **發射者不是副本**：`bullet.owner is game.player` 為 `True`。
- **移出遊戲不等於銷毀物件**：`kill()` 將角色移出所有群組。如果其他變數仍參考它，仍可讀取它的屬性；記憶體回收時間由 Python 實作決定。
- **生命值與 `alive()` 不同**：`hp` 是遊戲規則；`Sprite.alive()` 表示它是否仍屬於至少一個群組。
- **碰撞採矩形判定**：Tab 顯示的是 `rect`，不是每個有顏色的像素。高速物件採離散時間更新；大幅提高速度時需另考慮掃掠碰撞。

## 驗證

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

14 個行為測試涵蓋移動、射擊間隔、物件參考、多型、碰撞與計分、扣血、越界、暫停／單步、重開、勝敗，以及主迴圈結束。使用 SDL dummy 驅動，不會開啟測試視窗。

固定場景預覽可重建：

```powershell
.\.venv\Scripts\python.exe main.py --snapshot docs/game-preview.png
```

## 官方資料

- [Pygame Sprite 與 Group](https://www.pygame.org/docs/ref/sprite.html)
- [Pygame Clock 與時間](https://www.pygame.org/docs/ref/time.html)
- [Pygame 2.6.1 套件](https://pypi.org/project/pygame/2.6.1/)


## 三語教材

遊戲介面：`python main.py --lang zh`、`--lang en`、`--lang ja`。

- [繁體中文：30 個主題](docs/lesson-zh.html)
- [English: 30 topics](docs/lesson-en.html) · [Quick start](README.en.md)
- [日本語：30 トピック](docs/lesson-ja.html) · [入門](README.ja.md)
- [課程網站與三語投影片](https://minhuangyuntech.github.io/oo2026/pygame/)

畫面文字可切換語言；程式識別字共用，原有程式註解保留中文。
