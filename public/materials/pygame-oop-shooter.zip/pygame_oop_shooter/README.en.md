# OOP Star Lab — Pygame shooter

Five classes: Actor, Player, Enemy, Bullet, and Game.
Use Python 3.12 and Pygame 2.6.1. No image or audio assets are required to play.

## Install and run

Open a terminal in this extracted project folder.

Windows PowerShell:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe main.py --lang en
```

macOS / Linux:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python main.py --lang en
```

Change `--lang en` to `zh` or `ja` to switch the UI. CJK text needs a system CJK font (for example Noto Sans CJK).
Enter starts; arrows/WASD move; Space fires; P pauses; N advances one paused frame; Tab toggles labels; R resets to ready; Esc quits.
Defeat an enemy for 10 points; win at 200. Contact or missed enemies cause damage, with 0.8 seconds of invulnerability after a hit.

## Read and explore

Open [the 33-topic English lesson](docs/lesson-en.html), including editable source code excerpts, class diagrams and an object snapshot.
The [course website](https://minhuangyuntech.github.io/oo2026/en/pygame/) provides the English PowerPoint.
`actors.py` defines the four actor classes; `game.py` contains Game; `view.py` draws the screen; `i18n.py` translates UI text; `settings.py` contains parameters.
Source identifiers are shared across languages. Original source comments are in Chinese.

## Tests

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

On macOS/Linux use `.venv/bin/python` instead. Tests use the dummy SDL video driver.
`kill()` removes group membership; existing Python references can still access the object.
