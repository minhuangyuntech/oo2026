"""執行：python main.py"""

import argparse
import os
from pathlib import Path

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")


def main():
    parser = argparse.ArgumentParser(description="Pygame 物件導向射擊遊戲")
    parser.add_argument("--snapshot", type=Path, help="輸出固定場景 PNG 後結束")
    parser.add_argument("--lang", choices=("zh", "en", "ja"), default="zh", help="UI language")
    args = parser.parse_args()
    if args.snapshot:
        os.environ["SDL_VIDEODRIVER"] = "dummy"
    import pygame
    from game import Game
    import view

    try:
        game = Game(seed=7 if args.snapshot else None, lang=args.lang)
        if args.snapshot:
            game.prepare_snapshot()
            view.draw(game)
            args.snapshot.parent.mkdir(parents=True, exist_ok=True)
            pygame.image.save(game.screen, str(args.snapshot))
        else:
            game.run()
    finally:
        pygame.quit()


if __name__ == "__main__":
    main()
