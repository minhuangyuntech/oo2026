# OOP Star Lab — Pygame シューティング

主要クラスは Actor・Player・Enemy・Bullet・Game の五つです。
Python 3.12 と Pygame 2.6.1 を使用します。ゲームの実行に画像・音声ファイルは不要です。

## インストールと起動

展開したプロジェクト内でターミナルを開きます。

Windows PowerShell:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe main.py --lang ja
```

macOS / Linux:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python main.py --lang ja
```

`--lang` は zh・en・ja を指定できます。日本語の表示には Noto Sans CJK などの CJK フォントが必要です。
Enter で開始、矢印/WASD で移動、Space で発射、P で一時停止、N で停止中に 1 フレーム進めます。
Tab でラベル切替、R で待機状態にリセット、Esc で終了します。
敵の撃破は 10 点、200 点でクリア。接触や敵の通過で被弾し、その後 0.8 秒間は無敵になります。

## 教材とファイル

[33 トピックの日本語教材](docs/lesson-ja.html) に、コード・クラス図・オブジェクト図を収録しています。
[コースサイト](https://minhuangyuntech.github.io/oo2026/ja/pygame/) では日本語の PowerPoint をダウンロードできます。
`actors.py` は四つの役者クラス、`game.py` は Game、`view.py` は描画、`i18n.py` は表示言語、`settings.py` は設定を担当します。
識別子は三言語で共通です。元のソースコメントは中国語です。

## テスト

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

macOS/Linux では `.venv/bin/python` を使います。テストは SDL の dummy ビデオドライバーで動作します。
`kill()` はグループからの除去です。他の Python 参照があれば、実体には引き続きアクセスできます。
