-- スライド 21　CREATE TABLE で表を定義する
CREATE TABLE log (
    code TEXT NOT NULL PRIMARY KEY,
    reader TEXT NOT NULL,
    title TEXT NOT NULL,
    minutes INTEGER NOT NULL CHECK (minutes >= 0)
);

-- スライド 22　INSERT INTO で3件の読書記録を追加する
INSERT INTO log (code, reader, title, minutes)
VALUES
    ('R01', 'U1', '海辺の散歩', 25),
    ('R02', 'U2', '街の地図', 40),
    ('R03', 'U1', '森の日記', 15);

-- スライド 23　SELECT で列、FROM で表を指定する
SELECT title, minutes
FROM log
ORDER BY code;

-- スライド 24　WHERE で条件に合う行を選ぶ
SELECT code, title
FROM log
WHERE reader = 'U1' AND minutes >= 25;

-- スライド 25　ORDER BY と LIMIT で上位2件を取得する
SELECT title, minutes
FROM log
ORDER BY minutes DESC, code ASC
LIMIT 2;

-- スライド 26　COUNT、SUM、AVG で件数・合計・平均を求める
SELECT COUNT(*) AS sessions,
       SUM(minutes) AS total,
       ROUND(AVG(minutes), 1) AS average
FROM log;

-- スライド 27　GROUP BY でグループを作り、HAVING で絞り込む
SELECT reader, COUNT(*) AS sessions, SUM(minutes) AS total
FROM log
GROUP BY reader
HAVING COUNT(*) >= 2;

-- スライド 28　JOIN で読者IDに対応する氏名を取得する
CREATE TABLE readers (id TEXT NOT NULL PRIMARY KEY, name TEXT NOT NULL);
INSERT INTO readers VALUES ('U1', 'アン'), ('U2', 'カイ');
SELECT r.name, l.title
FROM log AS l
JOIN readers AS r ON r.id = l.reader
ORDER BY l.code;

-- スライド 29　UPDATE で読書記録を修正する
SELECT code, minutes FROM log WHERE code = 'R01';
UPDATE log
SET minutes = minutes + 10
WHERE code = 'R01';
SELECT code, minutes FROM log WHERE code = 'R01';

-- スライド 30　BEGIN の後で削除し、ROLLBACK で元に戻す
BEGIN;
DELETE FROM log WHERE code = 'R03';
SELECT COUNT(*) FROM log;
ROLLBACK;
SELECT COUNT(*) FROM log;

-- スライド 31　DELETE と COMMIT で削除を確定する
SELECT title FROM log WHERE code = 'R03';
BEGIN;
DELETE FROM log WHERE code = 'R03';
COMMIT;
SELECT COUNT(*), SUM(minutes) FROM log;
