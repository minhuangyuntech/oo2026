"""SQL の演習を順に実行し、検索結果を表示する。"""
from contextlib import closing
from pathlib import Path
import sqlite3


def run_lesson(con, source):
    pending = ""
    for line in source.splitlines():
        if not pending.strip() and line.startswith("-- スライド "):
            print("\n" + line[3:])
            continue
        pending += line + "\n"
        if sqlite3.complete_statement(pending):
            cursor = con.execute(pending)
            if cursor.description:
                print(" | ".join(col[0] for col in cursor.description))
                for row in cursor:
                    print(" | ".join(str(value) for value in row))
            pending = ""
    if pending.strip():
        raise ValueError("最後の SQL 文が完結していません。末尾のセミコロンを確認してください。")


if __name__ == "__main__":
    source = Path(__file__).with_name("sql_basics.sql").read_text(encoding="utf-8")
    with closing(sqlite3.connect(":memory:", isolation_level=None)) as con:
        run_lesson(con, source)
        print("\nスライド 32　Python から検索値をパラメーターとして渡す")
        code = "R01"
        sql = "SELECT title, minutes FROM log WHERE code = ?"
        row = con.execute(sql, (code,)).fetchone()
        print(row)
