Python・SQLite・MongoDB による読書記録の演習

アーカイブを reading_lab フォルダーに展開し、そのフォルダーでターミナルを開きます。スライド18に従い、プロジェクトの .venv を作成して有効化してください。

SQL 演習（スライド20～32）
python run_sql_lab.py

sql_basics.sql の検索条件を変更して試せます。各 SQL 文の末尾にセミコロンを置き、次の文は新しい行から書きます。実行するたびに新しいインメモリーデータベースから始まります。

Python から SQLite を操作する（スライド33～40）
python sqlite_lab.py

Python 標準ライブラリの sqlite3 を使用します。実行すると reading_01.db の保存先が表示されます。

Python から MongoDB を操作する（スライド41～51）
自分のコンピューターで Docker を起動し、初回のみ次のコマンドでローカルサービスを作成します。
docker run -d --name reading-mongo -p 127.0.0.1:27017:27017 -v reading-data:/data/db mongo:8.0
docker ps

有効化した仮想環境にドライバーをインストールし、演習を実行します。
python -m pip install "pymongo>=4,<5"
python -c "import pymongo; print(pymongo.version)"
python mongo_lab.py

どちらのデータベース演習も3件の記録から始まり、最後には2件、合計75分になります。
演習を最初からやり直す場合は、sqlite_lab.py のデータベースファイル名、または mongo_lab.py のコレクション名を未使用の名前に変更します。以前の記録を残したまま、ID の重複を避けられます。
練習用コンテナーを作成済みの場合は docker start reading-mongo で再開し、授業後は docker stop reading-mongo で停止します。
別の MongoDB サービスを使用する場合は、接続文字列を環境変数 MONGODB_URI に設定してください。
